# CS ChemScript is a chemical programming environment that extends the Python 
# scripting language.  ChemScript takes many of the CambridgeSoft "chemical 
# intelligence" algorithms, that are available throughout our products, and 
# makes them available to users through an object model in an easy to use 
# scripting language.  This allows users to create their own chemistry business
# rules and execute those rules on their data in a batch mode.



from sys import version_info
if version_info >= (2,6,0):
    def swig_import_helper26():
        from os.path import dirname
        import imp
        fp = None
        try:
            fp, pathname, description = imp.find_module('_ChemScript14forPy26', [dirname(__file__)])
        except ImportError:
            import _ChemScript14forPy26
            return _ChemScript14forPy26
        if fp is not None:
            try:
                _mod = imp.load_module('_ChemScript14forPy26', fp, pathname, description)
            finally:
                fp.close()
            return _mod
    def swig_import_helper31():
        from os.path import dirname
        import imp
        fp = None
        try:
            fp, pathname, description = imp.find_module('_ChemScript14forPy31', [dirname(__file__)])
        except ImportError:
            import _ChemScript14forPy31
            return _ChemScript14forPy31
        if fp is not None:
            try:
                _mod = imp.load_module('_ChemScript14forPy31', fp, pathname, description)
            finally:
                fp.close()
            return _mod
    def swig_import_helper32():
        from os.path import dirname
        import imp
        fp = None
        try:
            fp, pathname, description = imp.find_module('_ChemScript14forPy32', [dirname(__file__)])
        except ImportError:
            import _ChemScript14forPy32
            return _ChemScript14forPy32
        if fp is not None:
            try:
                _mod = imp.load_module('_ChemScript14forPy32', fp, pathname, description)
            finally:
                fp.close()
            return _mod
    if version_info[0] == 2 and version_info[1] == 6:
        _ChemScript14 = swig_import_helper26()
    elif version_info[0] == 3 and version_info[1] == 1:
        _ChemScript14 = swig_import_helper31()
    elif version_info[0] == 3 and version_info[1] == 2:
        _ChemScript14 = swig_import_helper32()
    else:
        print ('This version of ChemScript only supports Python 2.5, 2.6, 3.1 and 3.2')
    del swig_import_helper26
    del swig_import_helper31
    del swig_import_helper32
else:
    if version_info[0] == 2 and version_info[1] == 5:
        import _ChemScript14forPy25
        _ChemScript14 = _ChemScript14forPy25
    else:
        print ('This version of ChemScript only supports Python 2.5, 2.6, 3.1 and 3.2')

del version_info
try:
    _swig_property = property
except NameError:
    pass # Python < 2.2 doesn't have 'property'.
def _swig_setattr_nondynamic(self,class_type,name,value,static=1):
    if (name == "thisown"): return self.this.own(value)
    if (name == "this"):
        if type(value).__name__ == 'SwigPyObject':
            self.__dict__[name] = value
            return
    method = class_type.__swig_setmethods__.get(name,None)
    if method: return method(self,value)
    if (not static):
        self.__dict__[name] = value
    else:
        raise AttributeError("You cannot add attributes to %s" % self)

def _swig_setattr(self,class_type,name,value):
    return _swig_setattr_nondynamic(self,class_type,name,value,0)

def _swig_getattr(self,class_type,name):
    if (name == "thisown"): return self.this.own()
    method = class_type.__swig_getmethods__.get(name,None)
    if method: return method(self)
    raise AttributeError(name)

def _swig_repr(self):
    try: strthis = "proxy of " + self.this.__repr__()
    except: strthis = ""
    return "<%s.%s; %s >" % (self.__class__.__module__, self.__class__.__name__, strthis,)

try:
    _object = object
    _newclass = 1
except AttributeError:
    class _object : pass
    _newclass = 0


class SwigPyIterator(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, SwigPyIterator, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, SwigPyIterator, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined - class is abstract")
    __repr__ = _swig_repr
    __swig_destroy__ = _ChemScript14.delete_SwigPyIterator
    __del__ = lambda self : None;
    def value(self): return _ChemScript14.SwigPyIterator_value(self)
    def incr(self, n = 1): return _ChemScript14.SwigPyIterator_incr(self, n)
    def decr(self, n = 1): return _ChemScript14.SwigPyIterator_decr(self, n)
    def distance(self, *args): return _ChemScript14.SwigPyIterator_distance(self, *args)
    def equal(self, *args): return _ChemScript14.SwigPyIterator_equal(self, *args)
    def copy(self): return _ChemScript14.SwigPyIterator_copy(self)
    def next(self): return _ChemScript14.SwigPyIterator_next(self)
    def __next__(self): return _ChemScript14.SwigPyIterator___next__(self)
    def previous(self): return _ChemScript14.SwigPyIterator_previous(self)
    def advance(self, *args): return _ChemScript14.SwigPyIterator_advance(self, *args)
    def __eq__(self, *args):
        if not isinstance(args[0], type(self)):
            return False


        return _ChemScript14.SwigPyIterator___eq__(self, *args)

    def __ne__(self, *args):
        if not isinstance(args[0], type(self)):
            return True


        return _ChemScript14.SwigPyIterator___ne__(self, *args)

    def __iadd__(self, *args): return _ChemScript14.SwigPyIterator___iadd__(self, *args)
    def __isub__(self, *args): return _ChemScript14.SwigPyIterator___isub__(self, *args)
    def __add__(self, *args): return _ChemScript14.SwigPyIterator___add__(self, *args)
    def __sub__(self, *args): return _ChemScript14.SwigPyIterator___sub__(self, *args)
    def __iter__(self): return self
SwigPyIterator_swigregister = _ChemScript14.SwigPyIterator_swigregister
SwigPyIterator_swigregister(SwigPyIterator)

class ChemScriptBaseList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, ChemScriptBaseList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, ChemScriptBaseList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.ChemScriptBaseList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.ChemScriptBaseList___nonzero__(self)
    def __bool__(self): return _ChemScript14.ChemScriptBaseList___bool__(self)
    def __len__(self): return _ChemScript14.ChemScriptBaseList___len__(self)
    def pop(self): return _ChemScript14.ChemScriptBaseList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.ChemScriptBaseList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.ChemScriptBaseList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.ChemScriptBaseList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.ChemScriptBaseList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.ChemScriptBaseList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.ChemScriptBaseList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.ChemScriptBaseList_append(self, *args)
    def empty(self): return _ChemScript14.ChemScriptBaseList_empty(self)
    def size(self): return _ChemScript14.ChemScriptBaseList_size(self)
    def clear(self): return _ChemScript14.ChemScriptBaseList_clear(self)
    def swap(self, *args): return _ChemScript14.ChemScriptBaseList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.ChemScriptBaseList_get_allocator(self)
    def begin(self): return _ChemScript14.ChemScriptBaseList_begin(self)
    def end(self): return _ChemScript14.ChemScriptBaseList_end(self)
    def rbegin(self): return _ChemScript14.ChemScriptBaseList_rbegin(self)
    def rend(self): return _ChemScript14.ChemScriptBaseList_rend(self)
    def pop_back(self): return _ChemScript14.ChemScriptBaseList_pop_back(self)
    def erase(self, *args): return _ChemScript14.ChemScriptBaseList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_ChemScriptBaseList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.ChemScriptBaseList_push_back(self, *args)
    def front(self): return _ChemScript14.ChemScriptBaseList_front(self)
    def back(self): return _ChemScript14.ChemScriptBaseList_back(self)
    def assign(self, *args): return _ChemScript14.ChemScriptBaseList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.ChemScriptBaseList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.ChemScriptBaseList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.ChemScriptBaseList_reserve(self, *args)
    def capacity(self): return _ChemScript14.ChemScriptBaseList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_ChemScriptBaseList
    __del__ = lambda self : None;
ChemScriptBaseList_swigregister = _ChemScript14.ChemScriptBaseList_swigregister
ChemScriptBaseList_swigregister(ChemScriptBaseList)

CHEMSCRIPT_REF_MUTEX = _ChemScript14.CHEMSCRIPT_REF_MUTEX
CHEMSCRIPT_OBJHELPER_MUTEX = _ChemScript14.CHEMSCRIPT_OBJHELPER_MUTEX
class CMutexLock(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CMutexLock, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CMutexLock, name)
    __repr__ = _swig_repr
    def __init__(self, name, location = ""): 
        this = _ChemScript14.new_CMutexLock(name, location)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _ChemScript14.delete_CMutexLock
    __del__ = lambda self : None;
CMutexLock_swigregister = _ChemScript14.CMutexLock_swigregister
CMutexLock_swigregister(CMutexLock)

Create = _ChemScript14.Create
Append = _ChemScript14.Append
OverWrite = _ChemScript14.OverWrite
class ChemScriptBase(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, ChemScriptBase, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, ChemScriptBase, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _ChemScript14.new_ChemScriptBase(*args)
        try: self.this.append(this)
        except: self.this = this
    def __eq__(self, *args):
        if not isinstance(args[0], type(self)):
            return False
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.ToString())




        return _ChemScript14.ChemScriptBase___eq__(self, *args)

    def __ne__(self, *args):
        if not isinstance(args[0], type(self)):
            return True


        return _ChemScript14.ChemScriptBase___ne__(self, *args)

    def __hash__(self): return _ChemScript14.ChemScriptBase___hash__(self)
    def AddReference(self): return _ChemScript14.ChemScriptBase_AddReference(self)
    def RemoveReference(self, lockMem = True): return _ChemScript14.ChemScriptBase_RemoveReference(self, lockMem)
    def RefCount(self): return _ChemScript14.ChemScriptBase_RefCount(self)
    def Invalidate(self): return _ChemScript14.ChemScriptBase_Invalidate(self)
    __swig_getmethods__["PrintMessage"] = lambda x: _ChemScript14.ChemScriptBase_PrintMessage
    
    @staticmethod
    def PrintMessage(*args): return _ChemScript14.ChemScriptBase_PrintMessage(*args)
            
    def GetReferenceCount(self): return _ChemScript14.ChemScriptBase_GetReferenceCount(self)
    def GetExHandle(self): return _ChemScript14.ChemScriptBase_GetExHandle(self)
    def GetPyProxy(self): return _ChemScript14.ChemScriptBase_GetPyProxy(self)
    def SetExObj(self, *args): return _ChemScript14.ChemScriptBase_SetExObj(self, *args)
    def FreePyObject(self): return _ChemScript14.ChemScriptBase_FreePyObject(self)
    __swig_destroy__ = _ChemScript14.delete_ChemScriptBase
    __del__ = lambda self : None;
ChemScriptBase_swigregister = _ChemScript14.ChemScriptBase_swigregister
ChemScriptBase_swigregister(ChemScriptBase)


ChemScriptBase_PrintMessage = _ChemScript14.ChemScriptBase_PrintMessage

class XYZList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, XYZList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, XYZList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.XYZList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.XYZList___nonzero__(self)
    def __bool__(self): return _ChemScript14.XYZList___bool__(self)
    def __len__(self): return _ChemScript14.XYZList___len__(self)
    def pop(self): return _ChemScript14.XYZList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.XYZList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.XYZList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.XYZList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.XYZList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.XYZList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.XYZList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.XYZList_append(self, *args)
    def empty(self): return _ChemScript14.XYZList_empty(self)
    def size(self): return _ChemScript14.XYZList_size(self)
    def clear(self): return _ChemScript14.XYZList_clear(self)
    def swap(self, *args): return _ChemScript14.XYZList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.XYZList_get_allocator(self)
    def begin(self): return _ChemScript14.XYZList_begin(self)
    def end(self): return _ChemScript14.XYZList_end(self)
    def rbegin(self): return _ChemScript14.XYZList_rbegin(self)
    def rend(self): return _ChemScript14.XYZList_rend(self)
    def pop_back(self): return _ChemScript14.XYZList_pop_back(self)
    def erase(self, *args): return _ChemScript14.XYZList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_XYZList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.XYZList_push_back(self, *args)
    def front(self): return _ChemScript14.XYZList_front(self)
    def back(self): return _ChemScript14.XYZList_back(self)
    def assign(self, *args): return _ChemScript14.XYZList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.XYZList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.XYZList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.XYZList_reserve(self, *args)
    def capacity(self): return _ChemScript14.XYZList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_XYZList
    __del__ = lambda self : None;
XYZList_swigregister = _ChemScript14.XYZList_swigregister
XYZList_swigregister(XYZList)

class XYZ(ChemScriptBase):
    """
Class of points in 3D space (x, y, z)
    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, XYZ, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, XYZ, name)
    __repr__ = _swig_repr
    __swig_setmethods__["x"] = _ChemScript14.XYZ_x_set
    __swig_getmethods__["x"] = _ChemScript14.XYZ_x_get
    if _newclass:x = _swig_property(_ChemScript14.XYZ_x_get, _ChemScript14.XYZ_x_set)
    __swig_setmethods__["y"] = _ChemScript14.XYZ_y_set
    __swig_getmethods__["y"] = _ChemScript14.XYZ_y_get
    if _newclass:y = _swig_property(_ChemScript14.XYZ_y_get, _ChemScript14.XYZ_y_set)
    __swig_setmethods__["z"] = _ChemScript14.XYZ_z_set
    __swig_getmethods__["z"] = _ChemScript14.XYZ_z_get
    if _newclass:z = _swig_property(_ChemScript14.XYZ_z_get, _ChemScript14.XYZ_z_set)
    def __init__(self, _x = 0, _y = 0, _z = 0): 
        this = _ChemScript14.new_XYZ(_x, _y, _z)
        try: self.this.append(this)
        except: self.this = this
    def __mul__(self, s):
        """
Multiply x, y and z by scale factor s


        """
        return _ChemScript14.XYZ___mul__(self, s)
    def __div__(self, s):
        """
Divide x, y and z by scale factor s


        """
        return _ChemScript14.XYZ___div__(self, s)
    def __add__(self, offset):
        """
Translate by an offset: (x + offset.x, y + offset.y, z + offset.z)


        """
        return _ChemScript14.XYZ___add__(self, offset)
    def __sub__(self, offset):
        """
Translate by an offset: (x - offset.x, y - offset.y, z - offset.z)


        """
        return _ChemScript14.XYZ___sub__(self, offset)
    def __eq__(self, other):
        """
Check for equality with other (x == other.x && y == other.y && z == other.z)


        """
        if not isinstance(other, type(self)):
            return False


        return _ChemScript14.XYZ___eq__(self, other)

    def __ne__(self, other):
        """
Check for equality with other (x != other.x || y != other.y || z != other.z)


        """
        if not isinstance(other, type(self)):
            return True


        return _ChemScript14.XYZ___ne__(self, other)

    def __neg__(self):
        """
Invert x, y, z (x = -x, y = -y, z = -z)


        """
        return _ChemScript14.XYZ___neg__(self)
    def ToString(self): return _ChemScript14.XYZ_ToString(self)
    __swig_destroy__ = _ChemScript14.delete_XYZ
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


XYZ_swigregister = _ChemScript14.XYZ_swigregister
XYZ_swigregister(XYZ)

class PointList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, PointList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, PointList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.PointList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.PointList___nonzero__(self)
    def __bool__(self): return _ChemScript14.PointList___bool__(self)
    def __len__(self): return _ChemScript14.PointList___len__(self)
    def pop(self): return _ChemScript14.PointList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.PointList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.PointList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.PointList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.PointList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.PointList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.PointList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.PointList_append(self, *args)
    def empty(self): return _ChemScript14.PointList_empty(self)
    def size(self): return _ChemScript14.PointList_size(self)
    def clear(self): return _ChemScript14.PointList_clear(self)
    def swap(self, *args): return _ChemScript14.PointList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.PointList_get_allocator(self)
    def begin(self): return _ChemScript14.PointList_begin(self)
    def end(self): return _ChemScript14.PointList_end(self)
    def rbegin(self): return _ChemScript14.PointList_rbegin(self)
    def rend(self): return _ChemScript14.PointList_rend(self)
    def pop_back(self): return _ChemScript14.PointList_pop_back(self)
    def erase(self, *args): return _ChemScript14.PointList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_PointList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.PointList_push_back(self, *args)
    def front(self): return _ChemScript14.PointList_front(self)
    def back(self): return _ChemScript14.PointList_back(self)
    def assign(self, *args): return _ChemScript14.PointList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.PointList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.PointList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.PointList_reserve(self, *args)
    def capacity(self): return _ChemScript14.PointList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_PointList
    __del__ = lambda self : None;
PointList_swigregister = _ChemScript14.PointList_swigregister
PointList_swigregister(PointList)

class Point(XYZ):
    """
Class of points in 3D space (x, y, z)
    """
    __swig_setmethods__ = {}
    for _s in [XYZ]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, Point, name, value)
    __swig_getmethods__ = {}
    for _s in [XYZ]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, Point, name)
    __repr__ = _swig_repr
    def __init__(self, p): 
        """
Copy constructor


        """
        this = _ChemScript14.new_Point(p)
        try: self.this.append(this)
        except: self.this = this
    def __init__(self, x = 0, y = 0, z = 0): 
        """
Constructor.  Arguments x, y and z are optional, and the default of values are 0


        """
        this = _ChemScript14.new_Point(x, y, z)
        try: self.this.append(this)
        except: self.this = this
    def DistanceTo(self, p):
        """
Compute the distance from this point to another point "p"


        """
        return _ChemScript14.Point_DistanceTo(self, p)
    def DistanceToLine(self, point1, point2):
        """
Compute the perpendicular distance to a line.  The line is defined by two endpoints.


        """
        return _ChemScript14.Point_DistanceToLine(self, point1, point2)
    def DistanceToPlane(self, point1, point2, point3):
        """
Compute the perpendicular distance to a plane.  The plane is defined by three points.


        """
        return _ChemScript14.Point_DistanceToPlane(self, point1, point2, point3)
    __swig_getmethods__["Angle"] = lambda x: _ChemScript14.Point_Angle
    
    @staticmethod
    def Angle(p1, p0, p2):
        """
Compute the angle defined by three points (in degrees)


        """
        return _ChemScript14.Point_Angle(p1, p0, p2)
            
    __swig_getmethods__["DihedralAngle"] = lambda x: _ChemScript14.Point_DihedralAngle
    
    @staticmethod
    def DihedralAngle(p1, axis1, axis2, p2):
        """
Compute the dihedral angle between two planes.  The two planes are: p1--axis1--axis2, axis1--axis2--p2.


        """
        return _ChemScript14.Point_DihedralAngle(p1, axis1, axis2, p2)
            
    def ToVector(self):
        """
Create a Vector


        """
        return _ChemScript14.Point_ToVector(self)
    def __mul__(self, s):
        """
Multiply x, y and z by scale factor s


        """
        return _ChemScript14.Point___mul__(self, s)
    def __div__(self, s):
        """
Divide x, y and z by scale factor s


        """
        return _ChemScript14.Point___div__(self, s)
    def __add__(self, offset):
        """
Translate by an offset: (x + offset.x, y + offset.y, z + offset.z)


        """
        return _ChemScript14.Point___add__(self, offset)
    def __sub__(self, offset):
        """
Translate by an offset: (x - offset.x, y - offset.y, z - offset.z)


        """
        return _ChemScript14.Point___sub__(self, offset)
    def __neg__(self):
        """
Invert x, y, z (x = -x, y = -y, z = -z)

        """
        return _ChemScript14.Point___neg__(self)
    def ToString(self): return _ChemScript14.Point_ToString(self)
    __swig_destroy__ = _ChemScript14.delete_Point
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


Point_swigregister = _ChemScript14.Point_swigregister
Point_swigregister(Point)


Point_Angle = _ChemScript14.Point_Angle


Point_DihedralAngle = _ChemScript14.Point_DihedralAngle

class AtomList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, AtomList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, AtomList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.AtomList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.AtomList___nonzero__(self)
    def __bool__(self): return _ChemScript14.AtomList___bool__(self)
    def __len__(self): return _ChemScript14.AtomList___len__(self)
    def pop(self): return _ChemScript14.AtomList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.AtomList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.AtomList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.AtomList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.AtomList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.AtomList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.AtomList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.AtomList_append(self, *args)
    def empty(self): return _ChemScript14.AtomList_empty(self)
    def size(self): return _ChemScript14.AtomList_size(self)
    def clear(self): return _ChemScript14.AtomList_clear(self)
    def swap(self, *args): return _ChemScript14.AtomList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.AtomList_get_allocator(self)
    def begin(self): return _ChemScript14.AtomList_begin(self)
    def end(self): return _ChemScript14.AtomList_end(self)
    def rbegin(self): return _ChemScript14.AtomList_rbegin(self)
    def rend(self): return _ChemScript14.AtomList_rend(self)
    def pop_back(self): return _ChemScript14.AtomList_pop_back(self)
    def erase(self, *args): return _ChemScript14.AtomList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_AtomList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.AtomList_push_back(self, *args)
    def front(self): return _ChemScript14.AtomList_front(self)
    def back(self): return _ChemScript14.AtomList_back(self)
    def assign(self, *args): return _ChemScript14.AtomList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.AtomList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.AtomList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.AtomList_reserve(self, *args)
    def capacity(self): return _ChemScript14.AtomList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_AtomList
    __del__ = lambda self : None;
AtomList_swigregister = _ChemScript14.AtomList_swigregister
AtomList_swigregister(AtomList)

class Atom(ChemScriptBase):
    """
class of Atom


Users cannot create Atom objects directly.  Use StructureData.CreateAtom()
to create an Atom.


    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, Atom, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, Atom, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    NONE = _ChemScript14.Atom_NONE
    SINGLET = _ChemScript14.Atom_SINGLET
    DOUBLET = _ChemScript14.Atom_DOUBLET
    TRIPLET = _ChemScript14.Atom_TRIPLET
    def GetCartesian(self):
        """
Get the Cartesian coordinates of the atom.
Python Example:
>>> s = StructureData.LoadData('CCCC')
>>> a = s.Atoms[0]
>>> p = a.GetCartesian()
>>> print(p)


        """
        return _ChemScript14.Atom_GetCartesian(self)
    def SetCartesian(self, x, y, z):
        """
Sets the Cartesian coordinates for the atom


        """
        return _ChemScript14.Atom_SetCartesian(self, x, y, z)
    def SetCartesianPoint(self, p):
        """
Sets the Cartesian coordinates for the atom to a Point value.


        """
        return _ChemScript14.Atom_SetCartesianPoint(self, p)
    def ToString(self): return _ChemScript14.Atom_ToString(self)
    __swig_getmethods__["ID"] = _ChemScript14.Atom_ID_get
    if _newclass:ID = _swig_property(_ChemScript14.Atom_ID_get, doc=
        """
Get the atom ID.  
NOTE: the ID is not necessarily the index in the StructureData
ID is READONLY.


        """
    )
    __swig_getmethods__["Name"] = _ChemScript14.Atom_Name_get
    if _newclass:Name = _swig_property(_ChemScript14.Atom_Name_get, doc=
        """
Get the atom Name.  
Name is READONLY.


        """
    )
    __swig_setmethods__["Element"] = _ChemScript14.Atom_Element_set
    __swig_getmethods__["Element"] = _ChemScript14.Atom_Element_get
    if _newclass:Element = _swig_property(_ChemScript14.Atom_Element_get, _ChemScript14.Atom_Element_set, doc=
        """
Get/Set the element symbol of the atom
Python Example:
>>> s = StructureData.LoadData('CCCC')
>>> a = s.atoms[0]
>>> print(a.Element)
>>> s = StructureData.LoadData('CCCC')
>>> a = s.atoms[0]
>>> a.Element = 'O'
>>> print(s.Formula())


        """
    )
    __swig_setmethods__["FormalCharge"] = _ChemScript14.Atom_FormalCharge_set
    __swig_getmethods__["FormalCharge"] = _ChemScript14.Atom_FormalCharge_get
    if _newclass:FormalCharge = _swig_property(_ChemScript14.Atom_FormalCharge_get, _ChemScript14.Atom_FormalCharge_set, doc=
        """
Get/Set the atom's formal charge


        """
    )
    __swig_setmethods__["RadicalCode"] = _ChemScript14.Atom_RadicalCode_set
    __swig_getmethods__["RadicalCode"] = _ChemScript14.Atom_RadicalCode_get
    if _newclass:RadicalCode = _swig_property(_ChemScript14.Atom_RadicalCode_get, _ChemScript14.Atom_RadicalCode_set, doc=
        """
Get/Set the atom's radical code:
0 - NONE
1 - SINGLET
2 - DOUBLET
3 - TRIPLET


        """
    )
    __swig_getmethods__["CdxIdAsReadFromFile"] = _ChemScript14.Atom_CdxIdAsReadFromFile_get
    if _newclass:CdxIdAsReadFromFile = _swig_property(_ChemScript14.Atom_CdxIdAsReadFromFile_get, doc=
        """
The field CdxIdAsRead corresponds to the ID number of the atom in the CDX
or CDXML file that was read.  This field is undefined if the structure was
not read from a CDX(ML) file, or if the structure has been changed since
it was read from the file.


        """
    )
    __swig_getmethods__["CdxIdAsWrittenToFile"] = _ChemScript14.Atom_CdxIdAsWrittenToFile_get
    if _newclass:CdxIdAsWrittenToFile = _swig_property(_ChemScript14.Atom_CdxIdAsWrittenToFile_get, doc=
        """
The field CdxIdAsWrite corresponds to the ID number of the atom in the CDX
or CDXML file that was written.  This field is undefined if the structure
was not written to a CDX(ML) file, or if the structure has been changed
since it was written to the file.


        """
    )
    __swig_destroy__ = _ChemScript14.delete_Atom
    __del__ = lambda self : None;
    def __del__(self): _ChemScript14.ChemScriptBase_FreePyObject(self);
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString())



Atom_swigregister = _ChemScript14.Atom_swigregister
Atom_swigregister(Atom)

class BondList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, BondList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, BondList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.BondList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.BondList___nonzero__(self)
    def __bool__(self): return _ChemScript14.BondList___bool__(self)
    def __len__(self): return _ChemScript14.BondList___len__(self)
    def pop(self): return _ChemScript14.BondList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.BondList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.BondList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.BondList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.BondList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.BondList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.BondList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.BondList_append(self, *args)
    def empty(self): return _ChemScript14.BondList_empty(self)
    def size(self): return _ChemScript14.BondList_size(self)
    def clear(self): return _ChemScript14.BondList_clear(self)
    def swap(self, *args): return _ChemScript14.BondList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.BondList_get_allocator(self)
    def begin(self): return _ChemScript14.BondList_begin(self)
    def end(self): return _ChemScript14.BondList_end(self)
    def rbegin(self): return _ChemScript14.BondList_rbegin(self)
    def rend(self): return _ChemScript14.BondList_rend(self)
    def pop_back(self): return _ChemScript14.BondList_pop_back(self)
    def erase(self, *args): return _ChemScript14.BondList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_BondList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.BondList_push_back(self, *args)
    def front(self): return _ChemScript14.BondList_front(self)
    def back(self): return _ChemScript14.BondList_back(self)
    def assign(self, *args): return _ChemScript14.BondList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.BondList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.BondList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.BondList_reserve(self, *args)
    def capacity(self): return _ChemScript14.BondList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_BondList
    __del__ = lambda self : None;
BondList_swigregister = _ChemScript14.BondList_swigregister
BondList_swigregister(BondList)

BOND_WILD = _ChemScript14.BOND_WILD
BOND_SINGLE = _ChemScript14.BOND_SINGLE
BOND_DOUBLE = _ChemScript14.BOND_DOUBLE
BOND_TRIPLE = _ChemScript14.BOND_TRIPLE
BOND_QUADRUPLE = _ChemScript14.BOND_QUADRUPLE
BOND_DATIVE = _ChemScript14.BOND_DATIVE
BOND_DELOC = _ChemScript14.BOND_DELOC
BOND_FLEX = _ChemScript14.BOND_FLEX
BOND_TOTAL = _ChemScript14.BOND_TOTAL
GSTER_NONE = _ChemScript14.GSTER_NONE
GSTER_UP = _ChemScript14.GSTER_UP
GSTER_DOWN = _ChemScript14.GSTER_DOWN
GSTER_EITHER = _ChemScript14.GSTER_EITHER
GSTER_RECTANGHASH = _ChemScript14.GSTER_RECTANGHASH
GSTER_RECTANGSOLID = _ChemScript14.GSTER_RECTANGSOLID
GSTER_WEDGEHOLLOW = _ChemScript14.GSTER_WEDGEHOLLOW
GSTER_LINEDASH = _ChemScript14.GSTER_LINEDASH
GSTER_SCHEMATICDASH = _ChemScript14.GSTER_SCHEMATICDASH
GSTER_WAVYCUT = _ChemScript14.GSTER_WAVYCUT
GSTER_LINEWAVY = _ChemScript14.GSTER_LINEWAVY
GSTER_WEDGESOLID = _ChemScript14.GSTER_WEDGESOLID
GSTER_WEDGEHASH = _ChemScript14.GSTER_WEDGEHASH
GSTER_TOTAL = _ChemScript14.GSTER_TOTAL
class BondOrder(_object):
    """
struct of BondOrder. 
structure to hold bond order information.
    """
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, BondOrder, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, BondOrder, name)
    __repr__ = _swig_repr
    __swig_setmethods__["Name"] = _ChemScript14.BondOrder_Name_set
    __swig_getmethods__["Name"] = _ChemScript14.BondOrder_Name_get
    if _newclass:Name = _swig_property(_ChemScript14.BondOrder_Name_get, _ChemScript14.BondOrder_Name_set)
    __swig_setmethods__["BondSymbol"] = _ChemScript14.BondOrder_BondSymbol_set
    __swig_getmethods__["BondSymbol"] = _ChemScript14.BondOrder_BondSymbol_get
    if _newclass:BondSymbol = _swig_property(_ChemScript14.BondOrder_BondSymbol_get, _ChemScript14.BondOrder_BondSymbol_set)
    __swig_setmethods__["BondCode"] = _ChemScript14.BondOrder_BondCode_set
    __swig_getmethods__["BondCode"] = _ChemScript14.BondOrder_BondCode_get
    if _newclass:BondCode = _swig_property(_ChemScript14.BondOrder_BondCode_get, _ChemScript14.BondOrder_BondCode_set)
    def __init__(self): 
        this = _ChemScript14.new_BondOrder()
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _ChemScript14.delete_BondOrder
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


BondOrder_swigregister = _ChemScript14.BondOrder_swigregister
BondOrder_swigregister(BondOrder)

class BondGStereo(_object):
    """
class of BondGStereo. 
structure to hold GStereoCode information.
    """
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, BondGStereo, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, BondGStereo, name)
    __repr__ = _swig_repr
    __swig_setmethods__["Name"] = _ChemScript14.BondGStereo_Name_set
    __swig_getmethods__["Name"] = _ChemScript14.BondGStereo_Name_get
    if _newclass:Name = _swig_property(_ChemScript14.BondGStereo_Name_get, _ChemScript14.BondGStereo_Name_set)
    __swig_setmethods__["GStereoCode"] = _ChemScript14.BondGStereo_GStereoCode_set
    __swig_getmethods__["GStereoCode"] = _ChemScript14.BondGStereo_GStereoCode_get
    if _newclass:GStereoCode = _swig_property(_ChemScript14.BondGStereo_GStereoCode_get, _ChemScript14.BondGStereo_GStereoCode_set)
    def __eq__(self, other):
        """
this is override operation ==.


        """
        if not isinstance(other, type(self)):
            return False


        return _ChemScript14.BondGStereo___eq__(self, other)

    def __init__(self): 
        this = _ChemScript14.new_BondGStereo()
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _ChemScript14.delete_BondGStereo
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


BondGStereo_swigregister = _ChemScript14.BondGStereo_swigregister
BondGStereo_swigregister(BondGStereo)

class Bond(ChemScriptBase):
    """
Class of Bond. 
Users cannot create Bond object directly.  Use StructureData.CreateBond()
to create Bond
    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, Bond, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, Bond, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    def OtherAtom(self, a):
        """
From one atom, get the other atom
Python Example:
>>> m = Structure.LoadData('CC=C')
>>> b = m.Bonds[0]
>>> print(b.OtherAtom(b.Atom1) == b.Atom2)


        """
        return _ChemScript14.Bond_OtherAtom(self, a)
    def ExchangeAtoms(self):
        """
Exchange the identities of atom 1 and atom 2 in the bond.


        """
        return _ChemScript14.Bond_ExchangeAtoms(self)
    def ToString(self): return _ChemScript14.Bond_ToString(self)
    __swig_getmethods__["Atom1"] = _ChemScript14.Bond_Atom1_get
    if _newclass:Atom1 = _swig_property(_ChemScript14.Bond_Atom1_get, doc=
        """
Get the first atom of this bond
Atom1 is READONLY.


        """
    )
    __swig_getmethods__["Atom2"] = _ChemScript14.Bond_Atom2_get
    if _newclass:Atom2 = _swig_property(_ChemScript14.Bond_Atom2_get, doc=
        """
Get the second atom of this bond
Atom2 is READONLY.


        """
    )
    __swig_getmethods__["Length"] = _ChemScript14.Bond_Length_get
    if _newclass:Length = _swig_property(_ChemScript14.Bond_Length_get, doc=
        """
Get the Length of the bond


        """
    )
    __swig_getmethods__["Name"] = _ChemScript14.Bond_Name_get
    if _newclass:Name = _swig_property(_ChemScript14.Bond_Name_get, doc=
        """
Get the bond display name, for example C(1)-N(12)
Name is READONLY.


        """
    )
    __swig_setmethods__["Order"] = _ChemScript14.Bond_Order_set
    __swig_getmethods__["Order"] = _ChemScript14.Bond_Order_get
    if _newclass:Order = _swig_property(_ChemScript14.Bond_Order_get, _ChemScript14.Bond_Order_set, doc=
        """
Get/Set the order of the bond
Order is READWRITE.


        """
    )
    __swig_setmethods__["GStereo"] = _ChemScript14.Bond_GStereo_set
    __swig_getmethods__["GStereo"] = _ChemScript14.Bond_GStereo_get
    if _newclass:GStereo = _swig_property(_ChemScript14.Bond_GStereo_get, _ChemScript14.Bond_GStereo_set, doc=
        """
Get/Set the value of the graphical stereochemistry of the bond


        """
    )
    __swig_getmethods__["ReactionStatus"] = _ChemScript14.Bond_ReactionStatus_get
    if _newclass:ReactionStatus = _swig_property(_ChemScript14.Bond_ReactionStatus_get, doc=
        """
Get reaction status.
Returned values explained as below:
None
Involved            - Involved in reaction center, but not made/broken nor order changed.
MadeOrBroken        - Made or broken
Changed             - Order changed
NotInCenter         - Not in reaction center
MadeBrokenOrChanged - Made or broken or changed
NotModified         - Not modified
Unmapped            - Not mapped
Check ReactionData::PerceiveReactionCenters() for example usage.
ReactionStatus is READONLY.
Check ReactionData::PerceiveReactionCenters() for example usage.


        """
    )
    __swig_getmethods__["OrderName"] = _ChemScript14.Bond_OrderName_get
    if _newclass:OrderName = _swig_property(_ChemScript14.Bond_OrderName_get, doc=
        """
Get order name of the bond
OrderName is READONLY.


        """
    )
    __swig_getmethods__["OrderSymbol"] = _ChemScript14.Bond_OrderSymbol_get
    if _newclass:OrderSymbol = _swig_property(_ChemScript14.Bond_OrderSymbol_get, doc=
        """
Get order symbol of the bond
OrderSymbol is READONLY.


        """
    )
    __swig_getmethods__["GStereoName"] = _ChemScript14.Bond_GStereoName_get
    if _newclass:GStereoName = _swig_property(_ChemScript14.Bond_GStereoName_get, doc=
        """
Get GStereoName of the bond
GStereoName is READONLY.


        """
    )
    __swig_getmethods__["CdxIdAsReadFromFile"] = _ChemScript14.Bond_CdxIdAsReadFromFile_get
    if _newclass:CdxIdAsReadFromFile = _swig_property(_ChemScript14.Bond_CdxIdAsReadFromFile_get, doc=
        """
The field CdxIdAsRead corresponds to the ID number of the atom in the CDX
or CDXML file that was read.  This field is undefined if the structure was
not read from a CDX(ML) file, or if the structure has been changed since
it was read from the file.


        """
    )
    __swig_getmethods__["CdxIdAsWrittenToFile"] = _ChemScript14.Bond_CdxIdAsWrittenToFile_get
    if _newclass:CdxIdAsWrittenToFile = _swig_property(_ChemScript14.Bond_CdxIdAsWrittenToFile_get, doc=
        """
The field CdxIdAsWrite corresponds to the ID number of the atom in the CDX
or CDXML file that was written.  This field is undefined if the structure
was not written to a CDX(ML) file, or if the structure has been changed
since it was written to the file.


        """
    )
    __swig_destroy__ = _ChemScript14.delete_Bond
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString())
    BondWild = None
    BondSingle = None
    BondDouble = None
    BondTriple = None
    BondQuadruple = None
    BondDative = None
    BondDelocalized = None
    BondFlex = None
    GStereo_None = None
    GStereo_Up = None
    GStereo_Down = None
    GStereo_Either = None
    GStereo_RectangHash = None
    GStereo_RectangSolid = None
    GStereo_WedgeHollow = None
    GStereo_LineDash = None
    GStereo_SchematicDash = None
    GStereo_WavyCut = None


Bond_swigregister = _ChemScript14.Bond_swigregister
Bond_swigregister(Bond)
cvar = _ChemScript14.cvar
Bond.BondWild = _ChemScript14.cvar.Bond_BondWild
Bond.BondSingle = _ChemScript14.cvar.Bond_BondSingle
Bond.BondDouble = _ChemScript14.cvar.Bond_BondDouble
Bond.BondTriple = _ChemScript14.cvar.Bond_BondTriple
Bond.BondQuadruple = _ChemScript14.cvar.Bond_BondQuadruple
Bond.BondDative = _ChemScript14.cvar.Bond_BondDative
Bond.BondDelocalized = _ChemScript14.cvar.Bond_BondDelocalized
Bond.BondFlex = _ChemScript14.cvar.Bond_BondFlex
Bond.GStereo_None = _ChemScript14.cvar.Bond_GStereo_None
Bond.GStereo_Up = _ChemScript14.cvar.Bond_GStereo_Up
Bond.GStereo_Down = _ChemScript14.cvar.Bond_GStereo_Down
Bond.GStereo_Either = _ChemScript14.cvar.Bond_GStereo_Either
Bond.GStereo_RectangHash = _ChemScript14.cvar.Bond_GStereo_RectangHash
Bond.GStereo_RectangSolid = _ChemScript14.cvar.Bond_GStereo_RectangSolid
Bond.GStereo_WedgeHollow = _ChemScript14.cvar.Bond_GStereo_WedgeHollow
Bond.GStereo_LineDash = _ChemScript14.cvar.Bond_GStereo_LineDash
Bond.GStereo_SchematicDash = _ChemScript14.cvar.Bond_GStereo_SchematicDash
Bond.GStereo_WavyCut = _ChemScript14.cvar.Bond_GStereo_WavyCut

class ChemicalDataList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, ChemicalDataList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, ChemicalDataList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.ChemicalDataList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.ChemicalDataList___nonzero__(self)
    def __bool__(self): return _ChemScript14.ChemicalDataList___bool__(self)
    def __len__(self): return _ChemScript14.ChemicalDataList___len__(self)
    def pop(self): return _ChemScript14.ChemicalDataList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.ChemicalDataList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.ChemicalDataList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.ChemicalDataList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.ChemicalDataList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.ChemicalDataList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.ChemicalDataList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.ChemicalDataList_append(self, *args)
    def empty(self): return _ChemScript14.ChemicalDataList_empty(self)
    def size(self): return _ChemScript14.ChemicalDataList_size(self)
    def clear(self): return _ChemScript14.ChemicalDataList_clear(self)
    def swap(self, *args): return _ChemScript14.ChemicalDataList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.ChemicalDataList_get_allocator(self)
    def begin(self): return _ChemScript14.ChemicalDataList_begin(self)
    def end(self): return _ChemScript14.ChemicalDataList_end(self)
    def rbegin(self): return _ChemScript14.ChemicalDataList_rbegin(self)
    def rend(self): return _ChemScript14.ChemicalDataList_rend(self)
    def pop_back(self): return _ChemScript14.ChemicalDataList_pop_back(self)
    def erase(self, *args): return _ChemScript14.ChemicalDataList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_ChemicalDataList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.ChemicalDataList_push_back(self, *args)
    def front(self): return _ChemScript14.ChemicalDataList_front(self)
    def back(self): return _ChemScript14.ChemicalDataList_back(self)
    def assign(self, *args): return _ChemScript14.ChemicalDataList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.ChemicalDataList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.ChemicalDataList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.ChemicalDataList_reserve(self, *args)
    def capacity(self): return _ChemScript14.ChemicalDataList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_ChemicalDataList
    __del__ = lambda self : None;
ChemicalDataList_swigregister = _ChemScript14.ChemicalDataList_swigregister
ChemicalDataList_swigregister(ChemicalDataList)

class ChemicalData(ChemScriptBase):
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, ChemicalData, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, ChemicalData, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined - class is abstract")
    __repr__ = _swig_repr
    __swig_getmethods__["LoadFile"] = lambda x: _ChemScript14.ChemicalData_LoadFile
    
    @staticmethod
    def LoadFile(filePath, mimeType =""):
        return _ChemScript14.ChemicalData_LoadFile(filePath, mimeType)
            
    __swig_getmethods__["LoadData"] = lambda x: _ChemScript14.ChemicalData_LoadData
    
    @staticmethod
    def LoadData(data, mimeType =""):
        return _ChemScript14.ChemicalData_LoadData(data, mimeType)
            
    def WriteData(self, mimeType, base64encode = False):
        """
Write StructureData into a string with file format indicated by *format*.
*format* can be a full mime type, or the second part of a mime type (e.g. "cdx" short for "chemical/x-cdx").
Call StructureData.MimeTypes() to list all supported file formats
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> m.WriteData('cdx', True)
>>> m.WriteData('name')
>>> m.WriteData('smiles')
>>> m.WriteData('mol')
>>> m.WriteData('inchi')


        """
        return _ChemScript14.ChemicalData_WriteData(self, mimeType, base64encode)
    def WriteFile(self, file, format = ""):
        """
Write StructureData or Reaction into a file with file format indicated by *format*.
If *format* is not specified, the file extension is used.
*format* can be a full mime type, or the second part of a mime type (e.g. "cdx" short for "chemical/x-cdx").
Call StructureData.MimeTypes() to list all supported file formats.
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> m.WriteFile('output.cdx')
>>> m.ReadFile('output.cdx', 'cdx')


        """
        return _ChemScript14.ChemicalData_WriteFile(self, file, format)
    def Formula(self, balanceReaction = True):
        """
Return the mol's formula
Python Example:
>>> m = StructureData.LoadData('benzene')
>>> print(m.Formula())
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> print(r.Formula())
>>> print(r.Formula(False))


        """
        return _ChemScript14.ChemicalData_Formula(self, balanceReaction)
    def CanonicalCode(self, version = 0, mode = 0):
        """
Return the canonical code
NOTE: currently we only support version = 0 and mode = 0
Python Example:
>>> m = StructureData.LoadFile('benzene.cdx')
>>> print(m.CanonicalCode())


        """
        return _ChemScript14.ChemicalData_CanonicalCode(self, version, mode)
    def Clear(self):
        return _ChemScript14.ChemicalData_Clear(self)
    def NormalizeStructure(self, opts = None, version = 0):
        """
Convert differently drawn representations of the same structure into
a single normalized form.
Python Example:
>>> m = StructureData.LoadFile(r'structures.cdx')
>>> op = NormOptions()
>>> op.RemoveLabel = True
>>> m.NormalizeStructure(op)


        """
        return _ChemScript14.ChemicalData_NormalizeStructure(self, opts, version)
    __swig_getmethods__["MimeTypes"] = lambda x: _ChemScript14.ChemicalData_MimeTypes
    
    @staticmethod
    def MimeTypes():
        """
Get MimeTypes


        """
        return _ChemScript14.ChemicalData_MimeTypes()
            
    def ContainsSubstructure(self, dest, timeout = 0):
        """
Test whether "dest" is a substructure of this StructureData.
If you want atom-by-atom map, you should use SearchQuery.AtomByAtomSearch(...)
NOTE: in most cases one should call NormalizeStructure() prior to
calling ContainsSubstructure().  Not doing this may result in cases where
substructure searches do not match expected results.
Arguments: dest - destination StructureData
timeout - total timeout, in milliseconds; "0" means no timeout
Python Example:
>>> large = StructureData.LoadData('C1CCCCC1C')
>>> small = StructureData.LoadData('C1CCCCC1')
>>> large.ContainsSubstructure(small)


        """
        return _ChemScript14.ChemicalData_ContainsSubstructure(self, dest, timeout)
    def CreateSearchQuery(self, options = None):
        """
create a SearchQuery object.  When searching a large database, you'd better create a SearchQuery 
then use the SearchQuery to search the database.  AtomByAtomSearch() has lower efficiency.


        """
        return _ChemScript14.ChemicalData_CreateSearchQuery(self, options)
    def Tanimoto(self, target):
        """
Find the Tanimoto coefficient between two molecules.
Arguments: target - target StructureData
Python Example:
>>> large = StructureData.LoadData('C1CCCCC1C')
>>> small = StructureData.LoadData('C1CCCCC1')
>>> tanimoto = large.Tanimoto(small)
>>> if tanimoto > 0.9:
...    print("The two molecules have a Tanimoto similarity greater than 90%")


        """
        return _ChemScript14.ChemicalData_Tanimoto(self, target)
    def __setitem__(self, *args): return _ChemScript14.ChemicalData___setitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.ChemicalData___getitem__(self, *args)
    def GetDataItems(self):
        """
Get all customized string properties as a Dict
Python Example:
>>> m = StructureData()
>>> m.SetDataItem('id', '99')
>>> m.SetDataItem('name', 'my name')
>>> dict = m.GetDataItems()
>>> print(dict)


        """
        return _ChemScript14.ChemicalData_GetDataItems(self)
    def RemoveDataItem(self, propertyName):
        """
Delete a customized property
Python Example:
>>> m = StructureData()
>>> m.SetDataItem('id', '99')
>>> m.SetDataItem('name', 'my name')
>>> print(m.GetDataItem('name'))
>>> m.RemoveDataItem('name')
>>> print(m.GetDataItem('name'))


        """
        return _ChemScript14.ChemicalData_RemoveDataItem(self, propertyName)
    def ClearDataItems(self):
        """
Delete all the customized properties
Python Example:
>>> m = StructureData()
>>> m.SetDataItem('id', '99')
>>> m.SetDataItem('name', 'my name')
>>> print(m.GetDataItem('id'))
>>> m.ClearDataItems()
>>> dict = m.GetDataItems()
>>> print(dict)


        """
        return _ChemScript14.ChemicalData_ClearDataItems(self)
    def AtomByAtomSearch(self, target, options = None):
        """
List all atom-by-atom dict from this StructureData to "target" StructureData.
If no dict found, None is returned, else a list of all maps is returned.
Arguments: target - target StructureData
options.maxHitCount - the maximum hit count.  "0" means returns all hits
options.timeout - total timeout, in milliseconds; "0" means no timeout
Python Example:
>>> large = StructureData.LoadData('C1CCCCC1C')
>>> small = StructureData.LoadData('C1CCCCC1')
>>> maps = small.AtomByAtomSearch(large)
>>> for dict in maps:
...    print("one dict:")
...    for aa in dict.keys():
...       r = aa.Name + ' -> ' + dict[aa].Name
...       print(r)


        """
        return _ChemScript14.ChemicalData_AtomByAtomSearch(self, target, options)
    __swig_getmethods__["Name"] = _ChemScript14.ChemicalData_Name_get
    if _newclass:Name = _swig_property(_ChemScript14.ChemicalData_Name_get)
    __swig_getmethods__["FormulaHTML"] = _ChemScript14.ChemicalData_FormulaHTML_get
    if _newclass:FormulaHTML = _swig_property(_ChemScript14.ChemicalData_FormulaHTML_get, doc=
        """
Return the mol's HTML formula
Python Example:
>>> m = StructureData.LoadData('benzene')
>>> print(m.Formula())
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> print(r.FormulaHTML)


        """
    )
    __swig_getmethods__["IsEmpty"] = _ChemScript14.ChemicalData_IsEmpty_get
    if _newclass:IsEmpty = _swig_property(_ChemScript14.ChemicalData_IsEmpty_get, doc=
        """
Get IsEmpty


        """
    )
    __swig_setmethods__["ID"] = _ChemScript14.ChemicalData_ID_set
    __swig_getmethods__["ID"] = _ChemScript14.ChemicalData_ID_get
    if _newclass:ID = _swig_property(_ChemScript14.ChemicalData_ID_get, _ChemScript14.ChemicalData_ID_set, doc=
        """
Get/Set ID


        """
    )
    __swig_getmethods__["Smiles"] = _ChemScript14.ChemicalData_Smiles_get
    if _newclass:Smiles = _swig_property(_ChemScript14.ChemicalData_Smiles_get, doc=
        """
Get Smiles


        """
    )
    __swig_getmethods__["CDXBase64"] = _ChemScript14.ChemicalData_CDXBase64_get
    if _newclass:CDXBase64 = _swig_property(_ChemScript14.ChemicalData_CDXBase64_get, doc=
        """
Return CDXBase64


        """
    )
    __swig_destroy__ = _ChemScript14.delete_ChemicalData
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s (%s)>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(), self.Name)
    def SetDataItem(self, *args):
        """
Set a customized property
Python Example:
>>> m = StructureData()
>>> m.SetDataItem('id', '99')
>>> m.SetDataItem('name', 'my name')
>>> print(m.GetDataItem('name'))
We also can use operator [].
Python Example:
>>> m = StructureData()
>>> m['id'] = '99'
>>> m['name'] = 'my name'
>>> print(m['name'])
        """ 
        return _ChemScript14.ChemicalData___setitem__(self, *args)
    def GetDataItem(self, *args): 
        """
Get a customized property by its name
Python Example:
>>> m = StructureData()
>>> m.SetDataItem('id', '99')
>>> m.SetDataItem('name', 'my name')
>>> print(m.GetDataItem('id'))
>>> print(m.GetDataItem('name'))
We also can use operator [].
Python Example:
>>> m = StructureData()
>>> m['id'] = '99'
>>> m['name'] = 'my name'
>>> print(m['id'])
>>> print(m['name'])
        """
        return _ChemScript14.ChemicalData___getitem__(self, *args)


ChemicalData_swigregister = _ChemScript14.ChemicalData_swigregister
ChemicalData_swigregister(ChemicalData)


ChemicalData_LoadFile = _ChemScript14.ChemicalData_LoadFile


ChemicalData_LoadData = _ChemScript14.ChemicalData_LoadData


ChemicalData_MimeTypes = _ChemScript14.ChemicalData_MimeTypes

class TopologyList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, TopologyList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, TopologyList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.TopologyList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.TopologyList___nonzero__(self)
    def __bool__(self): return _ChemScript14.TopologyList___bool__(self)
    def __len__(self): return _ChemScript14.TopologyList___len__(self)
    def pop(self): return _ChemScript14.TopologyList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.TopologyList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.TopologyList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.TopologyList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.TopologyList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.TopologyList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.TopologyList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.TopologyList_append(self, *args)
    def empty(self): return _ChemScript14.TopologyList_empty(self)
    def size(self): return _ChemScript14.TopologyList_size(self)
    def clear(self): return _ChemScript14.TopologyList_clear(self)
    def swap(self, *args): return _ChemScript14.TopologyList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.TopologyList_get_allocator(self)
    def begin(self): return _ChemScript14.TopologyList_begin(self)
    def end(self): return _ChemScript14.TopologyList_end(self)
    def rbegin(self): return _ChemScript14.TopologyList_rbegin(self)
    def rend(self): return _ChemScript14.TopologyList_rend(self)
    def pop_back(self): return _ChemScript14.TopologyList_pop_back(self)
    def erase(self, *args): return _ChemScript14.TopologyList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_TopologyList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.TopologyList_push_back(self, *args)
    def front(self): return _ChemScript14.TopologyList_front(self)
    def back(self): return _ChemScript14.TopologyList_back(self)
    def assign(self, *args): return _ChemScript14.TopologyList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.TopologyList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.TopologyList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.TopologyList_reserve(self, *args)
    def capacity(self): return _ChemScript14.TopologyList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_TopologyList
    __del__ = lambda self : None;
TopologyList_swigregister = _ChemScript14.TopologyList_swigregister
TopologyList_swigregister(TopologyList)

class Topology(ChemScriptBase):
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, Topology, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, Topology, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    def ClusterCount(self, order):
        """
Get ClusterCount.


        """
        return _ChemScript14.Topology_ClusterCount(self, order)
    def ShapeAttribute(self, order):
        """
Get ShapeAttribute.


        """
        return _ChemScript14.Topology_ShapeAttribute(self, order)
    def ValenceConnectivityIndex(self, degree):
        """
Get ValenceConnectivityIndex.


        """
        return _ChemScript14.Topology_ValenceConnectivityIndex(self, degree)
    def NumOfValenceElectrons(self, atomicNumber):
        """
Get NumOfValenceElectrons.


        """
        return _ChemScript14.Topology_NumOfValenceElectrons(self, atomicNumber)
    def ValenceDegree(self, a):
        """
Get ValenceDegree.


        """
        return _ChemScript14.Topology_ValenceDegree(self, a)
    def Eccentricity(self, a):
        """
Get Eccentricity.


        """
        return _ChemScript14.Topology_Eccentricity(self, a)
    def Degree(self, a):
        """
Get Degree.


        """
        return _ChemScript14.Topology_Degree(self, a)
    def Valence(self, a):
        """
Get Valence.


        """
        return _ChemScript14.Topology_Valence(self, a)
    def NumOfHydrogens(self, a):
        """
Get NumOfHydrogens.


        """
        return _ChemScript14.Topology_NumOfHydrogens(self, a)
    def Distance(self, start, end):
        """
Get Distance.


        """
        return _ChemScript14.Topology_Distance(self, start, end)
    def DistanceMatrix(self):
        return _ChemScript14.Topology_DistanceMatrix(self)
    def DistanceMatrix(self):
        """
Get DistanceMatrix.


        """
        return _ChemScript14.Topology_DistanceMatrix(self)
    __swig_getmethods__["WienerIndex"] = _ChemScript14.Topology_WienerIndex_get
    if _newclass:WienerIndex = _swig_property(_ChemScript14.Topology_WienerIndex_get, doc=
        """
WienerIndex is READONLY.


        """
    )
    __swig_getmethods__["BalabanIndex"] = _ChemScript14.Topology_BalabanIndex_get
    if _newclass:BalabanIndex = _swig_property(_ChemScript14.Topology_BalabanIndex_get, doc=
        """
BalabanIndex is READONLY.


        """
    )
    __swig_getmethods__["TopologicalIndex"] = _ChemScript14.Topology_TopologicalIndex_get
    if _newclass:TopologicalIndex = _swig_property(_ChemScript14.Topology_TopologicalIndex_get, doc=
        """
TopologicalIndex is READONLY.


        """
    )
    __swig_getmethods__["Diameter"] = _ChemScript14.Topology_Diameter_get
    if _newclass:Diameter = _swig_property(_ChemScript14.Topology_Diameter_get, doc=
        """
Diameter is READONLY.


        """
    )
    __swig_getmethods__["Radius"] = _ChemScript14.Topology_Radius_get
    if _newclass:Radius = _swig_property(_ChemScript14.Topology_Radius_get, doc=
        """
Radius is READONLY.


        """
    )
    __swig_getmethods__["ShapeCoefficient"] = _ChemScript14.Topology_ShapeCoefficient_get
    if _newclass:ShapeCoefficient = _swig_property(_ChemScript14.Topology_ShapeCoefficient_get, doc=
        """
ShapeCoefficient is READONLY.


        """
    )
    __swig_getmethods__["SumOfDegrees"] = _ChemScript14.Topology_SumOfDegrees_get
    if _newclass:SumOfDegrees = _swig_property(_ChemScript14.Topology_SumOfDegrees_get, doc=
        """
SumOfDegrees is READONLY.


        """
    )
    __swig_getmethods__["SumOfValenceDegrees"] = _ChemScript14.Topology_SumOfValenceDegrees_get
    if _newclass:SumOfValenceDegrees = _swig_property(_ChemScript14.Topology_SumOfValenceDegrees_get, doc=
        """
SumOfValenceDegrees is READONLY.


        """
    )
    __swig_getmethods__["TotalConnectivity"] = _ChemScript14.Topology_TotalConnectivity_get
    if _newclass:TotalConnectivity = _swig_property(_ChemScript14.Topology_TotalConnectivity_get, doc=
        """
TotalConnectivity is READONLY.


        """
    )
    __swig_getmethods__["TotalValenceConnectivity"] = _ChemScript14.Topology_TotalValenceConnectivity_get
    if _newclass:TotalValenceConnectivity = _swig_property(_ChemScript14.Topology_TotalValenceConnectivity_get, doc=
        """
TotalValenceConnectivity is READONLY.


        """
    )
    __swig_getmethods__["PolarSurfaceArea"] = _ChemScript14.Topology_PolarSurfaceArea_get
    if _newclass:PolarSurfaceArea = _swig_property(_ChemScript14.Topology_PolarSurfaceArea_get, doc=
        """
PolarSurfaceArea is READONLY.


        """
    )
    __swig_getmethods__["NumOfRotatableBonds"] = _ChemScript14.Topology_NumOfRotatableBonds_get
    if _newclass:NumOfRotatableBonds = _swig_property(_ChemScript14.Topology_NumOfRotatableBonds_get, doc=
        """
NumOfRotatableBonds is READONLY.


        """
    )
    __swig_getmethods__["NumOfTerminalBonds"] = _ChemScript14.Topology_NumOfTerminalBonds_get
    if _newclass:NumOfTerminalBonds = _swig_property(_ChemScript14.Topology_NumOfTerminalBonds_get, doc=
        """
NumOfTerminalBonds is READONLY.


        """
    )
    __swig_getmethods__["NumOfRingBonds"] = _ChemScript14.Topology_NumOfRingBonds_get
    if _newclass:NumOfRingBonds = _swig_property(_ChemScript14.Topology_NumOfRingBonds_get, doc=
        """
NumOfRingBonds is READONLY.


        """
    )
    __swig_getmethods__["NumOfChainBonds"] = _ChemScript14.Topology_NumOfChainBonds_get
    if _newclass:NumOfChainBonds = _swig_property(_ChemScript14.Topology_NumOfChainBonds_get, doc=
        """
NumOfChainBonds is READONLY.


        """
    )
    __swig_getmethods__["NumOfLinkingChainBonds"] = _ChemScript14.Topology_NumOfLinkingChainBonds_get
    if _newclass:NumOfLinkingChainBonds = _swig_property(_ChemScript14.Topology_NumOfLinkingChainBonds_get, doc=
        """
NumOfLinkingChainBonds is READONLY.


        """
    )
    __swig_getmethods__["CyclomaticNumber"] = _ChemScript14.Topology_CyclomaticNumber_get
    if _newclass:CyclomaticNumber = _swig_property(_ChemScript14.Topology_CyclomaticNumber_get, doc=
        """
CyclomaticNumber is READONLY.


        """
    )
    __swig_destroy__ = _ChemScript14.delete_Topology
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__)


Topology_swigregister = _ChemScript14.Topology_swigregister
Topology_swigregister(Topology)

class StructureDataList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, StructureDataList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, StructureDataList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.StructureDataList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.StructureDataList___nonzero__(self)
    def __bool__(self): return _ChemScript14.StructureDataList___bool__(self)
    def __len__(self): return _ChemScript14.StructureDataList___len__(self)
    def pop(self): return _ChemScript14.StructureDataList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.StructureDataList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.StructureDataList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.StructureDataList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.StructureDataList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.StructureDataList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.StructureDataList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.StructureDataList_append(self, *args)
    def empty(self): return _ChemScript14.StructureDataList_empty(self)
    def size(self): return _ChemScript14.StructureDataList_size(self)
    def clear(self): return _ChemScript14.StructureDataList_clear(self)
    def swap(self, *args): return _ChemScript14.StructureDataList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.StructureDataList_get_allocator(self)
    def begin(self): return _ChemScript14.StructureDataList_begin(self)
    def end(self): return _ChemScript14.StructureDataList_end(self)
    def rbegin(self): return _ChemScript14.StructureDataList_rbegin(self)
    def rend(self): return _ChemScript14.StructureDataList_rend(self)
    def pop_back(self): return _ChemScript14.StructureDataList_pop_back(self)
    def erase(self, *args): return _ChemScript14.StructureDataList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_StructureDataList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.StructureDataList_push_back(self, *args)
    def front(self): return _ChemScript14.StructureDataList_front(self)
    def back(self): return _ChemScript14.StructureDataList_back(self)
    def assign(self, *args): return _ChemScript14.StructureDataList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.StructureDataList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.StructureDataList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.StructureDataList_reserve(self, *args)
    def capacity(self): return _ChemScript14.StructureDataList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_StructureDataList
    __del__ = lambda self : None;
StructureDataList_swigregister = _ChemScript14.StructureDataList_swigregister
StructureDataList_swigregister(StructureDataList)

class StructureData(ChemicalData):
    """
Class of StructureData. 


If more than one fragments needs to be added to the StructureData,
use JoinFragments() method to add extra structures/fragments.


    """
    __swig_setmethods__ = {}
    for _s in [ChemicalData]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, StructureData, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemicalData]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, StructureData, name)
    __repr__ = _swig_repr
    Salts_SeparateCounterions = _ChemScript14.StructureData_Salts_SeparateCounterions
    Salts_NeutralizePrincipal = _ChemScript14.StructureData_Salts_NeutralizePrincipal
    Salts_NeutralizeCounterion = _ChemScript14.StructureData_Salts_NeutralizeCounterion
    Salts_SpareRedundants = _ChemScript14.StructureData_Salts_SpareRedundants
    Salts_Default = _ChemScript14.StructureData_Salts_Default
    DekekMode_FailWithOne_FailWithAll = _ChemScript14.StructureData_DekekMode_FailWithOne_FailWithAll
    DekekMode_RemoveMuBondingDelreps = _ChemScript14.StructureData_DekekMode_RemoveMuBondingDelreps
    DekekMode_DoNotCreateCharges = _ChemScript14.StructureData_DekekMode_DoNotCreateCharges
    DekekMode_DoNotCreateRadicals = _ChemScript14.StructureData_DekekMode_DoNotCreateRadicals
    DekekMode_ConfineChargesToHeteroatoms = _ChemScript14.StructureData_DekekMode_ConfineChargesToHeteroatoms
    DekekMode_ConfineRadicalsToHeteroatoms = _ChemScript14.StructureData_DekekMode_ConfineRadicalsToHeteroatoms
    DekekMode_FavorMultiplyBondedHetero = _ChemScript14.StructureData_DekekMode_FavorMultiplyBondedHetero
    DekekMode_DontDisfavorAntiaromatic = _ChemScript14.StructureData_DekekMode_DontDisfavorAntiaromatic
    DekekMode_MustBeFullyAlternating = _ChemScript14.StructureData_DekekMode_MustBeFullyAlternating
    DekekMode_UseIncomingLabelH = _ChemScript14.StructureData_DekekMode_UseIncomingLabelH
    DekekMode_SpecifyHCount = _ChemScript14.StructureData_DekekMode_SpecifyHCount
    DekekMode_Default = _ChemScript14.StructureData_DekekMode_Default
    DekekMode_OkToCreateCharges = _ChemScript14.StructureData_DekekMode_OkToCreateCharges
    DekekMode_OkToCreateRadicals = _ChemScript14.StructureData_DekekMode_OkToCreateRadicals
    DekekMode_DisfavorAntiaromaticSystems = _ChemScript14.StructureData_DekekMode_DisfavorAntiaromaticSystems
    DekekMode_SpareMuBondingDelreps = _ChemScript14.StructureData_DekekMode_SpareMuBondingDelreps
    DekekMode_IgnoreIncomingLabelH = _ChemScript14.StructureData_DekekMode_IgnoreIncomingLabelH
    def FindBond(self, atom1, atom2):
        """
Find the bond between a1 and a2
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> a1 = m.Atoms[0]
>>> a2 = m.Atoms[1]
>>> b = m.FindBond(a1, a2)


        """
        return _ChemScript14.StructureData_FindBond(self, atom1, atom2)
    def FindBond(self, id1, id2):
        """
Find the bond between two atoms whose atom IDs are id1 and id2
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> b = m.FindBond(1, 2)


        """
        return _ChemScript14.StructureData_FindBond(self, id1, id2)
    __swig_getmethods__["LoadFile"] = lambda x: _ChemScript14.StructureData_LoadFile
    
    @staticmethod
    def LoadFile(filePath, mimeType =""):
        """
Load a structure data from a file.
Python Example:
structure = StructureData.LoadFile("1.cdxml")


        """
        return _ChemScript14.StructureData_LoadFile(filePath, mimeType)
            
    __swig_getmethods__["LoadData"] = lambda x: _ChemScript14.StructureData_LoadData
    
    @staticmethod
    def LoadData(data, mimeType = ""):
        """
Load a structure data from a string.
Python Example:
structure1 = StructureData.LoadData('C1CCCCC1C')
structure2 = StructureData.LoadData('C1C(C)CCCC1CC')


        """
        return _ChemScript14.StructureData_LoadData(data, mimeType)
            
    __swig_getmethods__["MostCommonStructure"] = lambda x: _ChemScript14.StructureData_MostCommonStructure
    
    @staticmethod
    def MostCommonStructure(structure1, structure2, timeout = 0):
        """
Find the most common part of two given StructureData.
This method returns the common part as a new StructureData without atom maps.
If you want to get maps, you have to create a LargestCommonSubstructure object.
Python Example:
>>> structure1 = StructureData.LoadData('C1CCCCC1C')
>>> structure2 = StructureData.LoadData('C1C(C)CCCC1CC')
>>> common = StructureData.MostCommonStructure(structure1, structure2)


        """
        return _ChemScript14.StructureData_MostCommonStructure(structure1, structure2, timeout)
            
    def ReadFile(self, filePath, mimeType =""):
        """
Loads a file into this StructureData or ReactionData object.
If *format* parameter is set, the load will be faster.  Otherwise, it will guess the type and a result mime type will be returned.
*format* can be a full mime type, or the second part of a mime type (e.g. "cdx" short for "chemical/x-cdx").
Call StructureData.MimeTypes() to list all supported file formats.
Python Example:
>>> m = StructureData()
>>> m.ReadFile('benzene.cdx')
>>> m.ReadFile('benzene.cdx', 'cdx')


        """
        return _ChemScript14.StructureData_ReadFile(self, filePath, mimeType)
    def ReadData(self, data, mimeType =""):
        """
Reads string data into this StructureData or ReactionData object.
If *format* parameter is set, the load will be faster.  Otherwise, it will guess the type and a result mime type will be returned.
*format* can be a full mime type, or the second part of a mime type (e.g. "cdx" short for "chemical/x-cdx").
Call StructureData.MimeTypes() to list all supported file formats.
Python Example:
>>> m = StructureData()
>>> m.ReadData('CCCC')
>>> m.ReadData('CCCC', 'smiles')
>>> m.ReadData('benzene', 'name')


        """
        return _ChemScript14.StructureData_ReadData(self, data, mimeType)
    def __init__(self): 
        this = _ChemScript14.new_StructureData()
        try: self.this.append(this)
        except: self.this = this
    def ContainsAtom(self, atom):
        """
Test if this StructureData/ReactionData contains Atom "a"
>>> m = StructureData.LoadData('CCCC')
>>> m.ContainsAtom(m.Atoms[2])


        """
        return _ChemScript14.StructureData_ContainsAtom(self, atom)
    def CreateAtom(self, symbol, point = None, charge = 0):
        """
Create an atom
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> a = m.CreateAtom('N')
>>> b = m.CreateBond(m.Atoms[2], a)


        """
        return _ChemScript14.StructureData_CreateAtom(self, symbol, point, charge)
    def RemoveAtom(self, atom):
        """
Remove an atom
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> m.RemoveAtom(m.Atoms[0])


        """
        return _ChemScript14.StructureData_RemoveAtom(self, atom)
    def ResetAtomIDs(self):
        """
Reset atom ID.  When some atoms are removed, the atom IDs are not continuous,
this method must be called to reassign a continuous IDs.


        """
        return _ChemScript14.StructureData_ResetAtomIDs(self)
    def ContainsBond(self, bond):
        """
Test if this StructureData/ReactionData contains Bond "b"
Python Example:
>>> m = StructureData.LoadData('CCCC')
>>> m.ContainsBond(m.bonds[2])


        """
        return _ChemScript14.StructureData_ContainsBond(self, bond)
    def CreateBond(self, atom1, atom2, bondOrder =None):
        """
Create an Bond
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> a = m.CreateAtom('N')
>>> b = m.CreateBond(m.Atoms[2], a)


        """
        return _ChemScript14.StructureData_CreateBond(self, atom1, atom2, bondOrder)
    def RemoveBond(self, bond, removeBondAtoms = False):
        """
Remove a bond
Python Example:
>>> m = StructureData.LoadData('CCCCCC')
>>> m.RemoveBond(m.bonds[0])
>>> m.RemoveBond(m.bonds[0], True)


        """
        return _ChemScript14.StructureData_RemoveBond(self, bond, removeBondAtoms)
    def Clear(self):
        """
Remove everything from this object
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> m.Clear()
>>> print(m.IsEmpty)


        """
        return _ChemScript14.StructureData_Clear(self)
    def Clone(self):
        """
Get a clone of this mol
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> m1 = m.Clone()
>>> print(m.CanonicalCode() == m1.CanonicalCode())


        """
        return _ChemScript14.StructureData_Clone(self)
    def ClearZCoordinates(self):
        """
Set all Z coordinates to 0


        """
        return _ChemScript14.StructureData_ClearZCoordinates(self)
    def GetBound(self):
        """
Get the bound of this StructureData.
Python Example:
>>> bound = m.GetBound()
>>> print("Lower point:", bound[0], bound[1], bound[2])
>>> print("Upper point:", bound[3], bound[4], bound[5])


        """
        return _ChemScript14.StructureData_GetBound(self)
    def TranslateCoordinates(self, offset):
        """
Translate all atom positions by offset
Python Example:
>>> offset = Point(0, 1, 0)
>>> m = StructureData.LoadData('CCC')
>>> m.TranslateCoordinates(offset)


        """
        return _ChemScript14.StructureData_TranslateCoordinates(self, offset)
    def Mm2Energy(self):
        """
MM2 steric energy
Python Example:
>>> m = StructureData.LoadData('CCCCC')
>>> m.Mm2OptimizeGeometry()
>>> m.Mm2Energy()


        """
        return _ChemScript14.StructureData_Mm2Energy(self)
    def Mm2OptimizeGeometry(self, rmsGradient = 0.1, maxIterations = 1000, timeout_ms = 0, showIteration = False):
        """
MM2 Minimization
Python Example:
>>> m = StructureData.LoadData('CCCCC')
>>> dict = m.Mm2OptimizeGeometry()
>>> print(dict['Total'])


        """
        return _ChemScript14.StructureData_Mm2OptimizeGeometry(self, rmsGradient, maxIterations, timeout_ms, showIteration)
    def CountAtoms(self, atomType):
        return _ChemScript14.StructureData_CountAtoms(self, atomType)
    def CountAtoms(self, atomType = 0):
        """
Count the number of atoms with a given atomic number (element)
If no atomic number is specified, then the total number of all atoms is returned.
Python Example:
>>> m = StructureData.LoadData('C(N)CC=O')
>>> nCarbon = m.CountAtoms(6)
>>> nOxygen = m.CountAtoms('O')
>>> nAllAtoms = m.CountAtoms()


        """
        return _ChemScript14.StructureData_CountAtoms(self, atomType)
    def List(self, atom = True, bond = True, coordinates = False):
        """
list atoms and/or bonds in this StructureData
Because ChemScript.dll is native code, if you want to print messages out while debugging .NET code, 
you need to check "Enable unmanaged code debugging" in the Debug tab of the project properties.
Python Example:
>>> m = StructureData.LoadData('CC=CO')
>>> m.List()


        """
        return _ChemScript14.StructureData_List(self, atom, bond, coordinates)
    def IsPlanarStructure(self, fast = True, tolerance = 0.01):
        """
Test whether this is a 2D structure.  
If "fast" is set to True, check if the atoms have Z coordinate.
If "fast" is set to False, check if the atoms lie in a plane.


        """
        return _ChemScript14.StructureData_IsPlanarStructure(self, fast, tolerance)
    def CleanupStructure(self, deNovo = True):
        """
Convert this structure to a 2D representation.


        """
        return _ChemScript14.StructureData_CleanupStructure(self, deNovo)
    def CleanupStructureWithAtoms(self, fixedAtoms, deNovo = True):
        """
Convert this structure to a 2D representation using the specified atoms.


        """
        return _ChemScript14.StructureData_CleanupStructureWithAtoms(self, fixedAtoms, deNovo)
    def ScaffoldCleanup(self, scaffold):
        """
This method can be used to exert precise control over the atom
positioning within a scaffold subset of a chemical structure.
The ScaffoldCleanup is a three-step procedure:
1. An overlay of the structure is performed onto the scaffold.
2. Atoms in the structure are given the coordinates of the corresponding
atoms in the scaffold structure.
3. A structure-cleanup algorithm is applied to the remaining atoms in the
structure which do not correspond to atoms in the scaffold.
Python Example:
>>> m = StructureData.LoadFile('m.cdx')
>>> scaffold = StructureData.LoadFile('scaffold.cdx')
>>> m.ScaffoldCleanup(scaffold)
>>> m.WriteFile('out_scaffold_cleanup.cdx')


        """
        return _ChemScript14.StructureData_ScaffoldCleanup(self, scaffold)
    def ConvertTo3DStructure(self, addHydrogen = True):
        """
Convert the structure to 3D.
NOTE: The quality of the structure may vary for complicated ring systems.


        """
        return _ChemScript14.StructureData_ConvertTo3DStructure(self, addHydrogen)
    def JoinFragments(self, structure):
        """
Add StructureData "m" to this StructureData
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> m1 = StructureData.LoadData('C=O')
>>> m.JoinFragments(m1)
>>> print(m.Formula())
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> s = StructureData.LoadData('CCC.CO')
>>> r.AppendStep(s)
## Create a reactant with 3 fragments.
>>> r = StructureData.LoadData('O=Cl(=O)([O-])=O')
>>> r1 = StructureData.LoadData('CC1=CC(C)=[O+]C(C)=C1')
>>> r2 = StructureData.LoadData('NCCO')
>>> r.JoinFragments(r1)
>>> r.JoinFragments(r2)
## Create a product with 2 fragments
>>> p1 = StructureData.LoadData('CC1=[N+](C(C)=CC(C)=C1)CCO')
>>> p2 = StructureData.LoadData('O=Cl(=O)([O-])=O')
>>> p = StructureData.MergeFragments([p1,p2])
>>> print (r.Formula())
>>> print (p.Formula())
## Create the reaction.
>>> rxn = ReactionData.CreateReaction(r,p)
>>> print (rxn.Formula())
>>> print (rxn.Smiles)


        """
        return _ChemScript14.StructureData_JoinFragments(self, structure)
    def Neutralize(self):
        """
Adds and removes protons so as to neutralize charged acidic and basic atoms


        """
        return _ChemScript14.StructureData_Neutralize(self)
    def ConvertToDelocBondRep(self):
        """
Python Example:
>>> m = StructureData.LoadData('benzene')
>>> m.List()
>>> m.ConvertToDelocBondRep()
>>> m.List()
>>> m.ConvertToFixedBondRep()
>>> m.List()


        """
        return _ChemScript14.StructureData_ConvertToDelocBondRep(self)
    def ConvertToFixedBondRep(self, dekekMode = DekekMode_Default, timeout_ms = 5000):
        """
Python Example:
>>> m = StructureData.LoadData('benzene')
>>> m.List()
>>> m.ConvertToDelocBondRep()
>>> m.List()
>>> m.ConvertToFixedBondRep()
>>> m.List()


        """
        return _ChemScript14.StructureData_ConvertToFixedBondRep(self, dekekMode, timeout_ms)
    def Overlay(self, target, timeout = 0):
        """
Adjust the position and orientation of the structure in order to achieve
the best possible overlay of the structure onto the target (or scaffold).
This is a "rigid-body" overlay.  During this procedure, the internal
geometry of the structure is not changed.
If the overlay results in a flip of the structure, then the bond graphical
stereochemistry is adjusted so that the atom stereochemistry will not be
changed by the overlay procedure.
This procedure can be used for 2D or 3D structures.
Python Example:
>>> m = StructureData.LoadFile('m.cdx')
>>> target = StructureData.LoadFile('target.cdx')
>>> m.Overlay(target)
>>> m.WriteFile('out_overlay.cdx')


        """
        return _ChemScript14.StructureData_Overlay(self, target, timeout)
    def GeometricCenter(self):
        """
Returns the unweighted geometric center of all atoms
Python Example:
>>> m = StructureData.LoadData('CCC(CO)C')
>>> m.ConvertTo3DStructure()
>>> print(m.GeometricCenter())


        """
        return _ChemScript14.StructureData_GeometricCenter(self)
    def MoveCenterToOrigin(self):
        """
Center the structure around the origin
Python Example:
>>> m = StructureData.LoadData('CCC(CO)C')
>>> m.ConvertTo3DStructure()
>>> print m.GeometricCenter()
>>> m.MoveCenterToOrigin()
>>> print(m.GeometricCenter())


        """
        return _ChemScript14.StructureData_MoveCenterToOrigin(self)
    def Rotate(self, axis, degree):
        """
Rotate all atoms about vector "axis" at a angle of "degree"
Python Example:
>>> m = StructureData.LoadData('benzene')
>>> m.List(True, True, True)
>>> axis = Point(1, 0, 0)
>>> m.Rotate(axis, 90)
>>> m.List(True, True, True)


        """
        return _ChemScript14.StructureData_Rotate(self, axis, degree)
    def SplitFragments(self):
        """
Split fragments into a list of separate StructureData objects
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> m2 = StructureData.LoadData('C=O')
>>> m.JoinFragments(m2)
>>> mols = m.SplitFragments()
>>> for mol in mols:
>>>      print(mol.Formula())


        """
        return _ChemScript14.StructureData_SplitFragments(self)
    def Topology(self):
        """
Get Topology object of this mol.  You can use Topology object to analyze molecular topology.
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> top = m.Topology()
>>> print(top.WienerIndex)


        """
        return _ChemScript14.StructureData_Topology(self)
    def ChemicalName(self, html = False):
        """
Return the chemical name.  It equals WriteData('name').
Python Example:
>>> m = StructureData.LoadData('CCC=O')
>>> m.ChemicalName()      # returns plain text
>>> m.ChemicalName(True)  # returns HTML text


        """
        return _ChemScript14.StructureData_ChemicalName(self, html)
    __swig_getmethods__["MergeFragments"] = lambda x: _ChemScript14.StructureData_MergeFragments
    
    @staticmethod
    def MergeFragments(structures):
        """
Merge a mol array into a new StructureData
Python Example:
>>> list = [StructureData.LoadData('CC'), StructureData.LoadData('CCC'), StructureData.LoadData('CCCC')];
>>> mol = StructureData.MergeFragments(list);


        """
        return _ChemScript14.StructureData_MergeFragments(structures)
            
    def RingInfo(self):
        """
Get a RingInfo object about this StructureData.
This deprecated method was not present since ChemScript.NET v12.


        """
        return _ChemScript14.StructureData_RingInfo(self)
    def BondedAtomsOf(self, a):
        """
Get bonded atoms of an Atom
Python Example:
>>> m = ChemScript14.StructureData.LoadData('C[C@@H](Br)CO[C@@H](C)Cl')
>>> a = m.Atoms[1]
>>> for atom in m.BondedAtomsOf(a):
>>>     print(atom.Name)


        """
        return _ChemScript14.StructureData_BondedAtomsOf(self, a)
    def BondedBondsOf(self, a):
        """
Get bonded bonds of an Atom
Python Example:
>>> m = ChemScript14.StructureData.LoadData('C[C@@H](Br)CO[C@@H](C)Cl')
>>> a = m.Atoms[1]
>>> for bond in m.BondedBondsOf(a):
...     print(bond.Name)


        """
        return _ChemScript14.StructureData_BondedBondsOf(self, a)
    def DetectAtomStereoCIP(self):
        """
Detect atoms' CIP stereochemistry.
Python Example:
>>> m = StructureData.LoadData('C[C@@H](Br)CO[C@@H](C)Cl')
>>> dict = m.DetectAtomStereoCIP()
>>> if (dict != None):
...    for a in dict.keys():
...       r = a.Name + "=>" + dict[a].__repr__()
...       print(r)


        """
        return _ChemScript14.StructureData_DetectAtomStereoCIP(self)
    def DetectBondStereoCIP(self):
        """
Detect bonds' CIP stereochemistry.
Python Example:
>>> m = StructureData.LoadData('C/C=C\C')
>>> dict = m.DetectBondStereoCIP()
>>> if (dict != None):
...    for b in dict.keys():
...       r = b.Name + "=>" + dict[b].__repr__()
...       print(r)


        """
        return _ChemScript14.StructureData_DetectBondStereoCIP(self)
    def AmbiguousStereoAtoms(self):
        """
Get AmbiguousStereoAtoms.


        """
        return _ChemScript14.StructureData_AmbiguousStereoAtoms(self)
    def ToString(self): return _ChemScript14.StructureData_ToString(self)
    def NormalizeStructure(self, opts = None, version = 0):
        """
Convert differently drawn representations of the same structure into
a single normalized form.
Python Example:
>>> m = StructureData.LoadFile(r'structures.cdx')
>>> op = NormOptions()
>>> op.RemoveLabel = True
>>> m.NormalizeStructure(op)


        """
        return _ChemScript14.StructureData_NormalizeStructure(self, opts, version)
    __swig_getmethods__["Atoms"] = _ChemScript14.StructureData_Atoms_get
    if _newclass:Atoms = _swig_property(_ChemScript14.StructureData_Atoms_get, doc=
        """
Get a list of all the atoms.  It has an alias call "Atoms".
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> for a in m.Atoms:
...    print(a.Name)


        """
    )
    __swig_getmethods__["Bonds"] = _ChemScript14.StructureData_Bonds_get
    if _newclass:Bonds = _swig_property(_ChemScript14.StructureData_Bonds_get, doc=
        """
Get a list of all the bonds.
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> for b in m.Bonds:
...    print(b.Name)


        """
    )
    __swig_getmethods__["HasCoordinates"] = _ChemScript14.StructureData_HasCoordinates_get
    if _newclass:HasCoordinates = _swig_property(_ChemScript14.StructureData_HasCoordinates_get, doc=
        """
Test whether the atoms have unique coordinates.
This function returns false if all atoms have the same coordinates


        """
    )
    __swig_getmethods__["HasZCoordinates"] = _ChemScript14.StructureData_HasZCoordinates_get
    if _newclass:HasZCoordinates = _swig_property(_ChemScript14.StructureData_HasZCoordinates_get, doc=
        """
Test whether all atoms' Z coordinates are 0. 


        """
    )
    __swig_getmethods__["AverageMass"] = _ChemScript14.StructureData_AverageMass_get
    if _newclass:AverageMass = _swig_property(_ChemScript14.StructureData_AverageMass_get, doc=
        """
Get the average mass
Python Example:
>>> m = StructureData.LoadData('CCC=O')
>>> m.AverageMass()


        """
    )
    __swig_getmethods__["ExactMass"] = _ChemScript14.StructureData_ExactMass_get
    if _newclass:ExactMass = _swig_property(_ChemScript14.StructureData_ExactMass_get, doc=
        """
Get the exact mass
Python Example:
>>> m = StructureData.LoadData('CCC=O')
>>> m.ExactMass()


        """
    )
    __swig_getmethods__["Weight"] = _ChemScript14.StructureData_Weight_get
    if _newclass:Weight = _swig_property(_ChemScript14.StructureData_Weight_get, doc=
        """
Get the mol weight
Python Example:
>>> m = StructureData.LoadData('CCC=O')
>>> m.Weight()


        """
    )
    __swig_getmethods__["PartitionCoefficient"] = _ChemScript14.StructureData_PartitionCoefficient_get
    if _newclass:PartitionCoefficient = _swig_property(_ChemScript14.StructureData_PartitionCoefficient_get, doc=
        """
Compute partition coefficient (Log P) using ClogP


        """
    )
    __swig_getmethods__["Refractivity"] = _ChemScript14.StructureData_Refractivity_get
    if _newclass:Refractivity = _swig_property(_ChemScript14.StructureData_Refractivity_get, doc=
        """
Compute StructureData refractivity using ClogP


        """
    )
    __swig_getmethods__["HasCharges"] = _ChemScript14.StructureData_HasCharges_get
    if _newclass:HasCharges = _swig_property(_ChemScript14.StructureData_HasCharges_get, doc=
        """
HasCharges


        """
    )
    __swig_getmethods__["TotalCharge"] = _ChemScript14.StructureData_TotalCharge_get
    if _newclass:TotalCharge = _swig_property(_ChemScript14.StructureData_TotalCharge_get, doc=
        """
Get the total charge of the StructureData
Python Example:
>>> m = StructureData.LoadData('CCC=O')
>>> m.TotalCharge()


        """
    )
    __swig_getmethods__["TotalNegativeCharges"] = _ChemScript14.StructureData_TotalNegativeCharges_get
    if _newclass:TotalNegativeCharges = _swig_property(_ChemScript14.StructureData_TotalNegativeCharges_get, doc=
        """
Get the total negative charges of the StructureData


        """
    )
    __swig_getmethods__["TotalPositiveCharges"] = _ChemScript14.StructureData_TotalPositiveCharges_get
    if _newclass:TotalPositiveCharges = _swig_property(_ChemScript14.StructureData_TotalPositiveCharges_get, doc=
        """
Get the total positive charges of the StructureData


        """
    )
    __swig_getmethods__["LonePairAtoms"] = _ChemScript14.StructureData_LonePairAtoms_get
    if _newclass:LonePairAtoms = _swig_property(_ChemScript14.StructureData_LonePairAtoms_get, doc=
        """
Returns the atoms with lone pairs to donate.  Excludes cations.


        """
    )
    __swig_getmethods__["AtomsWithVacantPiOrbitals"] = _ChemScript14.StructureData_AtomsWithVacantPiOrbitals_get
    if _newclass:AtomsWithVacantPiOrbitals = _swig_property(_ChemScript14.StructureData_AtomsWithVacantPiOrbitals_get, doc=
        """
Returns the atoms with vacant low-energy orbitals that might readily accept an electron pair.  Excludes anions.


        """
    )
    __swig_getmethods__["HydrogenAcceptors"] = _ChemScript14.StructureData_HydrogenAcceptors_get
    if _newclass:HydrogenAcceptors = _swig_property(_ChemScript14.StructureData_HydrogenAcceptors_get, doc=
        """
Get hydrogen-bond acceptor atoms as a list
A hydrogen-bond acceptor atom is defined as an O, N or F atom that is not a cation,
and is not an sp3 atom in an ester or amide.
Examples of acceptors:
MeCHO  MeOH		MeC(=O)Me  R3N  R2NH	MeS(-)  HO(-)
Examples of non-acceptors:
MeSH	B(-)F4			HCl      MeC(=S)OH   MeCl


        """
    )
    __swig_getmethods__["HydrogenDonors"] = _ChemScript14.StructureData_HydrogenDonors_get
    if _newclass:HydrogenDonors = _swig_property(_ChemScript14.StructureData_HydrogenDonors_get, doc=
        """
Get hydrogen-bond donor atoms as a list
A hydrogen-bond donor atom is defined as an O,N,S or F atom bearing one or more
hydrogen atoms, and that is not negatively charged.
Examples of donors:	
--OH  --NHR  --SH	==O(+)H


        """
    )
    __swig_getmethods__["ElectronDonatingAtoms"] = _ChemScript14.StructureData_ElectronDonatingAtoms_get
    if _newclass:ElectronDonatingAtoms = _swig_property(_ChemScript14.StructureData_ElectronDonatingAtoms_get, doc=
        """
Get the central atoms in electron-donating groups as a list
1. --M					where M is an element more electropositive than hydrogen.
Principal instances include:
--MgX
--SiR3
Alkyl is also electron donating to another carbon, and especially if the latter is
unsaturated.  (Unfortunately, we don't know in advance if that is the case.)
2. --X(-)				Anions
For example:
--O(-)			oxide
--N(-)			amide
--S(-)
3. --Y					where Y is an sp3-like non-halogen with a lone pair to donate.
Principal instances include:
--OCH3			methoxy
--NH2			amino
4. --C(C2)R			isopropyl or t-butyl groups are e-donating.


        """
    )
    __swig_getmethods__["ElectronWithdrawingAtoms"] = _ChemScript14.StructureData_ElectronWithdrawingAtoms_get
    if _newclass:ElectronWithdrawingAtoms = _swig_property(_ChemScript14.StructureData_ElectronWithdrawingAtoms_get, doc=
        """
Get the central atoms in electron-withdrawing groups as a list
1. --X=Y				where X is an element more electronegative than hydrogen,
and Y is an element more electronegative than hydrogen (inc. C).
Principal instances include:
--C=[N,O]		Carbon multiply bonded to an electronegative element.
--N=[N,O]		Nitrogen multiply bonded to an electronegative element (Eg. NO2).
--S=O			Sulfur multiply bonded to an electronegative element.
--Arom			Aromatic systems are electron-withdrawing.
2. --CX2R				Sp3 carbon substituted by two or more electronegative elements.
Principal instances include:
--CF2H			Fluorinated carbons.
--C(OMe)2		Ketals/acetals.
--C(NMe)2
3. --X(+)				Cations
Examples being:
--NR3(+)		ammonium
--OR2(+)		oxonium
--SR2(+)


        """
    )
    __swig_getmethods__["MOverZ"] = _ChemScript14.StructureData_MOverZ_get
    if _newclass:MOverZ = _swig_property(_ChemScript14.StructureData_MOverZ_get, doc=
        """
Get the mol m/z report
Python Example:
>>> m = StructureData.LoadData('CCC=O')
>>> m.MOverZ()


        """
    )
    __swig_getmethods__["ElementalAnalysis"] = _ChemScript14.StructureData_ElementalAnalysis_get
    if _newclass:ElementalAnalysis = _swig_property(_ChemScript14.StructureData_ElementalAnalysis_get, doc=
        """
Get the mol elemental analysis
Python Example:
>>> m = StructureData.LoadData('CCC=O')
>>> m.ElementalAnalysis()


        """
    )
    __swig_getmethods__["Inchi"] = _ChemScript14.StructureData_Inchi_get
    if _newclass:Inchi = _swig_property(_ChemScript14.StructureData_Inchi_get, doc=
        """
Return the InChI string.
See http://www.iupac.org/inchi/ for more information
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> print(m.Inchi)


        """
    )
    __swig_destroy__ = _ChemScript14.delete_StructureData
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s (%s)>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(), self.Name)


StructureData_swigregister = _ChemScript14.StructureData_swigregister
StructureData_swigregister(StructureData)


StructureData_LoadFile = _ChemScript14.StructureData_LoadFile


StructureData_LoadData = _ChemScript14.StructureData_LoadData


StructureData_MostCommonStructure = _ChemScript14.StructureData_MostCommonStructure


StructureData_MergeFragments = _ChemScript14.StructureData_MergeFragments

class SDFileReaderList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, SDFileReaderList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, SDFileReaderList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.SDFileReaderList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.SDFileReaderList___nonzero__(self)
    def __bool__(self): return _ChemScript14.SDFileReaderList___bool__(self)
    def __len__(self): return _ChemScript14.SDFileReaderList___len__(self)
    def pop(self): return _ChemScript14.SDFileReaderList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.SDFileReaderList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.SDFileReaderList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.SDFileReaderList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.SDFileReaderList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.SDFileReaderList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.SDFileReaderList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.SDFileReaderList_append(self, *args)
    def empty(self): return _ChemScript14.SDFileReaderList_empty(self)
    def size(self): return _ChemScript14.SDFileReaderList_size(self)
    def clear(self): return _ChemScript14.SDFileReaderList_clear(self)
    def swap(self, *args): return _ChemScript14.SDFileReaderList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.SDFileReaderList_get_allocator(self)
    def begin(self): return _ChemScript14.SDFileReaderList_begin(self)
    def end(self): return _ChemScript14.SDFileReaderList_end(self)
    def rbegin(self): return _ChemScript14.SDFileReaderList_rbegin(self)
    def rend(self): return _ChemScript14.SDFileReaderList_rend(self)
    def pop_back(self): return _ChemScript14.SDFileReaderList_pop_back(self)
    def erase(self, *args): return _ChemScript14.SDFileReaderList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_SDFileReaderList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.SDFileReaderList_push_back(self, *args)
    def front(self): return _ChemScript14.SDFileReaderList_front(self)
    def back(self): return _ChemScript14.SDFileReaderList_back(self)
    def assign(self, *args): return _ChemScript14.SDFileReaderList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.SDFileReaderList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.SDFileReaderList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.SDFileReaderList_reserve(self, *args)
    def capacity(self): return _ChemScript14.SDFileReaderList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_SDFileReaderList
    __del__ = lambda self : None;
SDFileReaderList_swigregister = _ChemScript14.SDFileReaderList_swigregister
SDFileReaderList_swigregister(SDFileReaderList)

class SDFileReader(ChemScriptBase):
    """
class for reading MDL SD file
    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, SDFileReader, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, SDFileReader, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    __swig_getmethods__["OpenFile"] = lambda x: _ChemScript14.SDFileReader_OpenFile
    
    @staticmethod
    def OpenFile(filename):
        """
Entry of creating SDFileReader.  Usage:
Python Example:
>>> sd = SDFileReader.OpenFile('c:/my.sdf')
>>> if sd = None: pass
>>> sd.ResetReading()
>>> m = sd.ReadNext()
>>> while not sd.Eof():
...     m = sd.ReadNext()
...     if m == None:
...         print "Jump to the next structure."
...         continue
...     print m.Formula()
...     items = m.GetDataItems()
...     for item in items.keys():
...         print(item, '->', m[item])
...     m = sd.ReadNext()


        """
        return _ChemScript14.SDFileReader_OpenFile(filename)
            
    def Eof(self):
        """
Check if reaching the end of the file


        """
        return _ChemScript14.SDFileReader_Eof(self)
    def ReadNext(self):
        """
Read next StructureData


        """
        return _ChemScript14.SDFileReader_ReadNext(self)
    def Current(self):
        """
get the structure of the last ReadNext()


        """
        return _ChemScript14.SDFileReader_Current(self)
    def ResetReading(self):
        """
Reset reading, so next ReadNext() call will get the first StructureData


        """
        return _ChemScript14.SDFileReader_ResetReading(self)
    def Close(self):
        """
Close


        """
        return _ChemScript14.SDFileReader_Close(self)
    __swig_getmethods__["Count"] = _ChemScript14.SDFileReader_Count_get
    if _newclass:Count = _swig_property(_ChemScript14.SDFileReader_Count_get, doc=
        """
Get the number of structures pending of reading in the file
Count is READONLY.


        """
    )
    __swig_getmethods__["PercentComplete"] = _ChemScript14.SDFileReader_PercentComplete_get
    if _newclass:PercentComplete = _swig_property(_ChemScript14.SDFileReader_PercentComplete_get, doc=
        """
Get the read percentage of the file
PercentComplete is READONLY.


        """
    )
    __swig_getmethods__["NumberOfRecordsRead"] = _ChemScript14.SDFileReader_NumberOfRecordsRead_get
    if _newclass:NumberOfRecordsRead = _swig_property(_ChemScript14.SDFileReader_NumberOfRecordsRead_get, doc=
        """
Get the number of molecules read from the file
NumberOfRecordsRead is READONLY.


        """
    )
    __swig_getmethods__["LastReadMimeType"] = _ChemScript14.SDFileReader_LastReadMimeType_get
    if _newclass:LastReadMimeType = _swig_property(_ChemScript14.SDFileReader_LastReadMimeType_get, doc=
        """
Get the mime type of last read record.
Return empty string if no record read or the mime type is unknown


        """
    )
    __swig_destroy__ = _ChemScript14.delete_SDFileReader
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)


SDFileReader_swigregister = _ChemScript14.SDFileReader_swigregister
SDFileReader_swigregister(SDFileReader)


SDFileReader_OpenFile = _ChemScript14.SDFileReader_OpenFile

class ReactionDataList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, ReactionDataList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, ReactionDataList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.ReactionDataList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.ReactionDataList___nonzero__(self)
    def __bool__(self): return _ChemScript14.ReactionDataList___bool__(self)
    def __len__(self): return _ChemScript14.ReactionDataList___len__(self)
    def pop(self): return _ChemScript14.ReactionDataList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.ReactionDataList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.ReactionDataList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.ReactionDataList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.ReactionDataList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.ReactionDataList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.ReactionDataList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.ReactionDataList_append(self, *args)
    def empty(self): return _ChemScript14.ReactionDataList_empty(self)
    def size(self): return _ChemScript14.ReactionDataList_size(self)
    def clear(self): return _ChemScript14.ReactionDataList_clear(self)
    def swap(self, *args): return _ChemScript14.ReactionDataList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.ReactionDataList_get_allocator(self)
    def begin(self): return _ChemScript14.ReactionDataList_begin(self)
    def end(self): return _ChemScript14.ReactionDataList_end(self)
    def rbegin(self): return _ChemScript14.ReactionDataList_rbegin(self)
    def rend(self): return _ChemScript14.ReactionDataList_rend(self)
    def pop_back(self): return _ChemScript14.ReactionDataList_pop_back(self)
    def erase(self, *args): return _ChemScript14.ReactionDataList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_ReactionDataList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.ReactionDataList_push_back(self, *args)
    def front(self): return _ChemScript14.ReactionDataList_front(self)
    def back(self): return _ChemScript14.ReactionDataList_back(self)
    def assign(self, *args): return _ChemScript14.ReactionDataList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.ReactionDataList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.ReactionDataList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.ReactionDataList_reserve(self, *args)
    def capacity(self): return _ChemScript14.ReactionDataList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_ReactionDataList
    __del__ = lambda self : None;
ReactionDataList_swigregister = _ChemScript14.ReactionDataList_swigregister
ReactionDataList_swigregister(ReactionDataList)

class ReactionData(ChemicalData):
    """
Class of manipulating chemical reactions.
    """
    __swig_setmethods__ = {}
    for _s in [ChemicalData]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, ReactionData, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemicalData]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, ReactionData, name)
    __repr__ = _swig_repr
    def __init__(self): 
        this = _ChemScript14.new_ReactionData()
        try: self.this.append(this)
        except: self.this = this
    __swig_getmethods__["LoadFile"] = lambda x: _ChemScript14.ReactionData_LoadFile
    
    @staticmethod
    def LoadFile(filePath, mimeType =""):
        return _ChemScript14.ReactionData_LoadFile(filePath, mimeType)
            
    __swig_getmethods__["LoadData"] = lambda x: _ChemScript14.ReactionData_LoadData
    
    @staticmethod
    def LoadData(data, mimeType = ""):
        return _ChemScript14.ReactionData_LoadData(data, mimeType)
            
    def ReadFile(self, filePath, mimeType =""):
        """
Loads a file into this StructureData or ReactionData object.
If *format* parameter is set, the load will be faster.  Otherwise, it will guess the type and a result mime type will be returned.
*format* can be a full mime type, or the second part of a mime type (e.g. "cdx" short for "chemical/x-cdx").
Call StructureData.MimeTypes() to list all supported file formats.
Python Example:
>>> m = StructureData()
>>> m.ReadFile('benzene.cdx')
>>> m.ReadFile('benzene.cdx', 'cdx')


        """
        return _ChemScript14.ReactionData_ReadFile(self, filePath, mimeType)
    def ReadData(self, data, mimeType =""):
        """
Reads string data into this StructureData or ReactionData object.
If *format* parameter is set, the load will be faster.  Otherwise, it will guess the type and a result mime type will be returned.
*format* can be a full mime type, or the second part of a mime type (e.g. "cdx" short for "chemical/x-cdx").
Call StructureData.MimeTypes() to list all supported file formats.
Python Example:
>>> m = StructureData()
>>> m.ReadData('CCCC')
>>> m.ReadData('CCCC', 'smiles')
>>> m.ReadData('benzene', 'name')


        """
        return _ChemScript14.ReactionData_ReadData(self, data, mimeType)
    def Clear(self):
        """
Remove everything from this object
Python Example:
>>> s = StructureData.LoadData('CCC')
>>> s.Clear()
>>> print(s.IsEmpty)


        """
        return _ChemScript14.ReactionData_Clear(self)
    def Clone(self):
        """
Get a clone of this mol
Python Example:
>>> m = StructureData.LoadData('CCC')
>>> m1 = m.Clone()
>>> print(m.CanonicalCode() == m1.CanonicalCode())


        """
        return _ChemScript14.ReactionData_Clone(self)
    def AppendStep(self, s):
        """
Append a new step.  For example,  A -> B ( -> C)
If the new products is composed with two StructureData, use StructureData.JoinFragments() to create a new StructureData first.
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> s = StructureData.LoadData('CCC.CO')
>>> r.AppendStep(s)


        """
        return _ChemScript14.ReactionData_AppendStep(self, s)
    def Layout(self):
        """
Layout the reaction to make it look nicer.


        """
        return _ChemScript14.ReactionData_Layout(self)
    def Transform(self, s):
        """
Use reaction template to transform this *m* to get another new StructureData.
To get the new reaction, call ReactionData.Create(m, new_m)
Python Example:
>>> r = ReactionData.LoadData('CC=C>>CCCO')
>>> m = StructureData.LoadData('CCCC=C')
>>> print(r.Transform(m))


        """
        return _ChemScript14.ReactionData_Transform(self, s)
    def PerceiveReactionCenters(self):
        """
Perceive reaction centers; Status can then be found in Bond.ReactionStatus.
Python Example:
>>> r = ReactionData.LoadData('OCC1C=CC=CC1>>C2C=CCCC2')
Open reaction successfully: chemical/x-smiles
>>> m = r.Reactants
>>> for b in m[0].Bonds:
...    print(b.ReactionStatus)
>>> r.PerceiveReactionCenters()
>>> m = r.Reactants
>>> for b in m[0].Bonds:
...    print(b.ReactionStatus)


        """
        return _ChemScript14.ReactionData_PerceiveReactionCenters(self)
    __swig_getmethods__["CreateReaction"] = lambda x: _ChemScript14.ReactionData_CreateReaction
    
    @staticmethod
    def CreateReaction(reactants, products):
        """
Create a reaction.
"reactants" and "products" may each contain more than one fragment.
Python Example:
>>> s = StructureData.LoadData('CCC=C')
>>> s1 = StructureData.LoadData('CCC.C=O')
>>> print(ReactionData.CreateReaction(s, s1))


        """
        return _ChemScript14.ReactionData_CreateReaction(reactants, products)
            
    def ReactionAtomMap(self, timeout_ms = 0, cleanmap = False):
        """
Atom-By-Atom Map reactants to products
Python Example:
>>> r = StructureData.LoadData("CCCO>>CCCCCO")
>>> atomMap = r.ReactionAtomMap()
>>> for atom in atomMap.keys():
...    r = atom.Name + '->' + atomMap[atom].Name
...    print(r)


        """
        return _ChemScript14.ReactionData_ReactionAtomMap(self, timeout_ms, cleanmap)
    def ReactionBondMap(self, timeout_ms = 0, cleanmap = False):
        """
Bond-By-Bond Map reactants to products
Python Example:
>>> r = StructureData.LoadData("CCCO>>CCCCCO")
>>> bondMap = r.ReactionBondMap()
>>> for bond in bondMap.keys():
...    r = bond.Name + '->' + bondMap[bond].Name
...    print(r)


        """
        return _ChemScript14.ReactionData_ReactionBondMap(self, timeout_ms, cleanmap)
    def ToString(self): return _ChemScript14.ReactionData_ToString(self)
    __swig_getmethods__["Reactants"] = _ChemScript14.ReactionData_Reactants_get
    if _newclass:Reactants = _swig_property(_ChemScript14.ReactionData_Reactants_get, doc=
        """
Get reactants as StructureData list.
A reactant is a component that does not participate as a product in any step.
For single-step reactions, this function returns the 'obvious' reactants.
For multi-step reactions, this function returns the reactants of the first step.
For convergent reactions, this function returns a combined list of
all reactants in all initiating steps.
For cyclic reactions, this function returns an empty list.
The reactants returned by this function are references to those in the original
reaction.  Changes to the items returned by this function will be reflected in
the original reaction, although changes to the list itself (adding or removing entire
members of the list) will not be reflected in the original reaction.
The three functions Reactants(), Products(), and Intermediates() produce non-overlapping lists of Mols.
Python Example:
A -> B returns A
A -> B -> C returns A
A -> B + C -> D -> E returns A
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> print(r.Reactants())
Reactants is READONLY.


        """
    )
    __swig_getmethods__["Products"] = _ChemScript14.ReactionData_Products_get
    if _newclass:Products = _swig_property(_ChemScript14.ReactionData_Products_get, doc=
        """
Get products as StructureData list.
A product is a component that does not participate as a reactant in any step.
For single-step reactions, this function returns the 'obvious' products.
For multi-step reactions, this function returns the products of the last step.
For convergent reactions, this function returns a combined list of
all products in all terminating steps.
For cyclic reactions, this function returns an empty list.
The products returned by this function are references to those in the original
reaction.  Changes to the items returned by this function will be reflected in
the original reaction, although changes to the list itself (adding or removing entire
members of the list) will not be reflected in the original reaction.
The three functions Reactants(), Products(), and Intermediates() produce non-overlapping lists of Mols.
Python Example:
A -> B returns B
A -> B -> C returns C
A -> B + C -> D -> E returns E
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> print(r.Products())
Products is READONLY.


        """
    )
    __swig_getmethods__["Components"] = _ChemScript14.ReactionData_Components_get
    if _newclass:Components = _swig_property(_ChemScript14.ReactionData_Components_get, doc=
        """
Get all components of the reaction as StructureData list.
The components returned by this function are references to those in the original
reaction.  Changes to the items returned by this function will be reflected in
the original reaction, although changes to the list itself (adding or removing entire
members of the list) will not be reflected in the original reaction.
Python Example:
A -> B returns A, B
A -> B -> C returns A, B, C
A -> B + C -> D -> E returns A, B, C, D, E
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> print(r.Components())
Components is READONLY.


        """
    )
    __swig_getmethods__["Intermediates"] = _ChemScript14.ReactionData_Intermediates_get
    if _newclass:Intermediates = _swig_property(_ChemScript14.ReactionData_Intermediates_get, doc=
        """
Get intermediates as StructureData list.
An intermediate is a component that participates as a product in one step and as a reactant in another.
For single-step reactions, this function returns an empty list.
For multi-step reactions and convergent reactions, this function returns a combined list of
everything that is not an initiating or terminating molecule.
For cyclic reactions, this function returns every component in the reaction.
The intermediates returned by this function are references to those in the original
reaction.  Changes to the items returned by this function will be reflected in
the original reaction, although changes to the list itself (adding or removing entire
members of the list) will not be reflected in the original reaction.
The three functions Reactants(), Products(), and Intermediates() produce non-overlapping lists of Mols.
Python Example:
A -> B returns None
A -> B -> C returns B
A -> B + C -> D -> E returns B, C and D
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> m = StructureData.LoadData('CCC.CO')
>>> r.AppendStep(m)
>>> print(r.Intermediates())
Intermediates is READONLY.


        """
    )
    __swig_getmethods__["Steps"] = _ChemScript14.ReactionData_Steps_get
    if _newclass:Steps = _swig_property(_ChemScript14.ReactionData_Steps_get, doc=
        """
Get multi-step reaction as a list of single-step ReactionStep objects.
For example, A -> B -> C  returns  A -> B, B -> C, for a total of 2 steps.
Python Example:
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> m = StructureData.LoadData('CCC.CO')
>>> r.AppendStep(m)
>>> print(r.Steps())
Steps is READONLY.


        """
    )
    __swig_destroy__ = _ChemScript14.delete_ReactionData
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s >" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


ReactionData_swigregister = _ChemScript14.ReactionData_swigregister
ReactionData_swigregister(ReactionData)


ReactionData_LoadFile = _ChemScript14.ReactionData_LoadFile


ReactionData_LoadData = _ChemScript14.ReactionData_LoadData


ReactionData_CreateReaction = _ChemScript14.ReactionData_CreateReaction

class ReactionStepList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, ReactionStepList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, ReactionStepList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.ReactionStepList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.ReactionStepList___nonzero__(self)
    def __bool__(self): return _ChemScript14.ReactionStepList___bool__(self)
    def __len__(self): return _ChemScript14.ReactionStepList___len__(self)
    def pop(self): return _ChemScript14.ReactionStepList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.ReactionStepList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.ReactionStepList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.ReactionStepList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.ReactionStepList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.ReactionStepList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.ReactionStepList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.ReactionStepList_append(self, *args)
    def empty(self): return _ChemScript14.ReactionStepList_empty(self)
    def size(self): return _ChemScript14.ReactionStepList_size(self)
    def clear(self): return _ChemScript14.ReactionStepList_clear(self)
    def swap(self, *args): return _ChemScript14.ReactionStepList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.ReactionStepList_get_allocator(self)
    def begin(self): return _ChemScript14.ReactionStepList_begin(self)
    def end(self): return _ChemScript14.ReactionStepList_end(self)
    def rbegin(self): return _ChemScript14.ReactionStepList_rbegin(self)
    def rend(self): return _ChemScript14.ReactionStepList_rend(self)
    def pop_back(self): return _ChemScript14.ReactionStepList_pop_back(self)
    def erase(self, *args): return _ChemScript14.ReactionStepList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_ReactionStepList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.ReactionStepList_push_back(self, *args)
    def front(self): return _ChemScript14.ReactionStepList_front(self)
    def back(self): return _ChemScript14.ReactionStepList_back(self)
    def assign(self, *args): return _ChemScript14.ReactionStepList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.ReactionStepList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.ReactionStepList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.ReactionStepList_reserve(self, *args)
    def capacity(self): return _ChemScript14.ReactionStepList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_ReactionStepList
    __del__ = lambda self : None;
    def __repr__(self):
        r = ""
        for j in self:
            r = r + "\r\n"
            r = r + j.__repr__()
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, r,)


ReactionStepList_swigregister = _ChemScript14.ReactionStepList_swigregister
ReactionStepList_swigregister(ReactionStepList)

class ReactionStep(ChemScriptBase):
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, ReactionStep, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, ReactionStep, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    def Formula(self, balanceReaction = True):
        """
Return the step's formula
Python Example:
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> print(r.Steps[0].Formula())
>>> print(r.Steps[0].Formula(False))


        """
        return _ChemScript14.ReactionStep_Formula(self, balanceReaction)
    def ToString(self): return _ChemScript14.ReactionStep_ToString(self)
    __swig_getmethods__["Reactants"] = _ChemScript14.ReactionStep_Reactants_get
    if _newclass:Reactants = _swig_property(_ChemScript14.ReactionStep_Reactants_get, doc=
        """
Get all reactants as a list
Reactants is READONLY.


        """
    )
    __swig_getmethods__["Products"] = _ChemScript14.ReactionStep_Products_get
    if _newclass:Products = _swig_property(_ChemScript14.ReactionStep_Products_get, doc=
        """
Get all products as a list
Products is READONLY.


        """
    )
    __swig_getmethods__["FormulaHTML"] = _ChemScript14.ReactionStep_FormulaHTML_get
    if _newclass:FormulaHTML = _swig_property(_ChemScript14.ReactionStep_FormulaHTML_get, doc=
        """
Return the step's formula with HTML markup
Python Example:
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> print(r.Steps[0].FormulaHTML)
FormulaHTML is READONLY.


        """
    )
    __swig_destroy__ = _ChemScript14.delete_ReactionStep
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s >" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


ReactionStep_swigregister = _ChemScript14.ReactionStep_swigregister
ReactionStep_swigregister(ReactionStep)

class PeriodicTableList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, PeriodicTableList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, PeriodicTableList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.PeriodicTableList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.PeriodicTableList___nonzero__(self)
    def __bool__(self): return _ChemScript14.PeriodicTableList___bool__(self)
    def __len__(self): return _ChemScript14.PeriodicTableList___len__(self)
    def pop(self): return _ChemScript14.PeriodicTableList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.PeriodicTableList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.PeriodicTableList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.PeriodicTableList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.PeriodicTableList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.PeriodicTableList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.PeriodicTableList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.PeriodicTableList_append(self, *args)
    def empty(self): return _ChemScript14.PeriodicTableList_empty(self)
    def size(self): return _ChemScript14.PeriodicTableList_size(self)
    def clear(self): return _ChemScript14.PeriodicTableList_clear(self)
    def swap(self, *args): return _ChemScript14.PeriodicTableList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.PeriodicTableList_get_allocator(self)
    def begin(self): return _ChemScript14.PeriodicTableList_begin(self)
    def end(self): return _ChemScript14.PeriodicTableList_end(self)
    def rbegin(self): return _ChemScript14.PeriodicTableList_rbegin(self)
    def rend(self): return _ChemScript14.PeriodicTableList_rend(self)
    def pop_back(self): return _ChemScript14.PeriodicTableList_pop_back(self)
    def erase(self, *args): return _ChemScript14.PeriodicTableList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_PeriodicTableList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.PeriodicTableList_push_back(self, *args)
    def front(self): return _ChemScript14.PeriodicTableList_front(self)
    def back(self): return _ChemScript14.PeriodicTableList_back(self)
    def assign(self, *args): return _ChemScript14.PeriodicTableList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.PeriodicTableList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.PeriodicTableList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.PeriodicTableList_reserve(self, *args)
    def capacity(self): return _ChemScript14.PeriodicTableList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_PeriodicTableList
    __del__ = lambda self : None;
PeriodicTableList_swigregister = _ChemScript14.PeriodicTableList_swigregister
PeriodicTableList_swigregister(PeriodicTableList)

class PeriodicTable(ChemScriptBase):
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, PeriodicTable, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, PeriodicTable, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    __swig_getmethods__["ElementCount"] = lambda x: _ChemScript14.PeriodicTable_ElementCount
    
    @staticmethod
    def ElementCount():
        """
Get the count of Element


        """
        return _ChemScript14.PeriodicTable_ElementCount()
            
    __swig_getmethods__["GetElement"] = lambda x: _ChemScript14.PeriodicTable_GetElement
    
    @staticmethod
    def GetElement(atomicNo):
        """
Get Element with the atomic No


        """
        return _ChemScript14.PeriodicTable_GetElement(atomicNo)

    @staticmethod
    def GetElement(symbol):
        """
Get Element with the symbol


        """
        return _ChemScript14.PeriodicTable_GetElement(symbol)
            
    __swig_destroy__ = _ChemScript14.delete_PeriodicTable
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)


PeriodicTable_swigregister = _ChemScript14.PeriodicTable_swigregister
PeriodicTable_swigregister(PeriodicTable)


PeriodicTable_ElementCount = _ChemScript14.PeriodicTable_ElementCount


PeriodicTable_GetElement = _ChemScript14.PeriodicTable_GetElement

class VectorList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, VectorList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, VectorList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.VectorList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.VectorList___nonzero__(self)
    def __bool__(self): return _ChemScript14.VectorList___bool__(self)
    def __len__(self): return _ChemScript14.VectorList___len__(self)
    def pop(self): return _ChemScript14.VectorList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.VectorList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.VectorList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.VectorList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.VectorList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.VectorList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.VectorList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.VectorList_append(self, *args)
    def empty(self): return _ChemScript14.VectorList_empty(self)
    def size(self): return _ChemScript14.VectorList_size(self)
    def clear(self): return _ChemScript14.VectorList_clear(self)
    def swap(self, *args): return _ChemScript14.VectorList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.VectorList_get_allocator(self)
    def begin(self): return _ChemScript14.VectorList_begin(self)
    def end(self): return _ChemScript14.VectorList_end(self)
    def rbegin(self): return _ChemScript14.VectorList_rbegin(self)
    def rend(self): return _ChemScript14.VectorList_rend(self)
    def pop_back(self): return _ChemScript14.VectorList_pop_back(self)
    def erase(self, *args): return _ChemScript14.VectorList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_VectorList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.VectorList_push_back(self, *args)
    def front(self): return _ChemScript14.VectorList_front(self)
    def back(self): return _ChemScript14.VectorList_back(self)
    def assign(self, *args): return _ChemScript14.VectorList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.VectorList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.VectorList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.VectorList_reserve(self, *args)
    def capacity(self): return _ChemScript14.VectorList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_VectorList
    __del__ = lambda self : None;
VectorList_swigregister = _ChemScript14.VectorList_swigregister
VectorList_swigregister(VectorList)

class Vector(XYZ):
    __swig_setmethods__ = {}
    for _s in [XYZ]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, Vector, name, value)
    __swig_getmethods__ = {}
    for _s in [XYZ]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, Vector, name)
    __repr__ = _swig_repr
    def __init__(self, p): 
        """
Copy constructor


        """
        this = _ChemScript14.new_Vector(p)
        try: self.this.append(this)
        except: self.this = this
    def __init__(self, x = 0, y = 0, z = 0): 
        """
Constructor.  Arguments x, y and z are optional, and the default of values are 0


        """
        this = _ChemScript14.new_Vector(x, y, z)
        try: self.this.append(this)
        except: self.this = this
    def Normalize(self):
        """
Normalize - make its length 1.0 ( |v| == 1.0 )


        """
        return _ChemScript14.Vector_Normalize(self)
    def DotProduct(self, p):
        """
Compute the dot product of two vectors: myself . p


        """
        return _ChemScript14.Vector_DotProduct(self, p)
    def CrossProduct(self, p):
        """
Compute the cross product of two vectors: myself x p


        """
        return _ChemScript14.Vector_CrossProduct(self, p)
    __swig_getmethods__["Angle"] = lambda x: _ChemScript14.Vector_Angle
    
    @staticmethod
    def Angle(v1, v2):
        """
Compute the angle defined by two vectors (in degrees)


        """
        return _ChemScript14.Vector_Angle(v1, v2)
            
    __swig_getmethods__["NormalVector"] = lambda x: _ChemScript14.Vector_NormalVector
    
    @staticmethod
    def NormalVector(p1, p2, p3):
        """
Compute a normalized perpendicular vector to a plane.  The plane id defined by p1--p2--p3


        """
        return _ChemScript14.Vector_NormalVector(p1, p2, p3)
            
    def ToPoint(self):
        """
Create a Point using this vector from the origin


        """
        return _ChemScript14.Vector_ToPoint(self)
    def ToString(self): return _ChemScript14.Vector_ToString(self)
    __swig_getmethods__["Length"] = _ChemScript14.Vector_Length_get
    if _newclass:Length = _swig_property(_ChemScript14.Vector_Length_get, doc=
        """
Compute the vector length ( |v| )


        """
    )
    __swig_destroy__ = _ChemScript14.delete_Vector
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


Vector_swigregister = _ChemScript14.Vector_swigregister
Vector_swigregister(Vector)


Vector_Angle = _ChemScript14.Vector_Angle


Vector_NormalVector = _ChemScript14.Vector_NormalVector

class ElementList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, ElementList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, ElementList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.ElementList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.ElementList___nonzero__(self)
    def __bool__(self): return _ChemScript14.ElementList___bool__(self)
    def __len__(self): return _ChemScript14.ElementList___len__(self)
    def pop(self): return _ChemScript14.ElementList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.ElementList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.ElementList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.ElementList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.ElementList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.ElementList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.ElementList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.ElementList_append(self, *args)
    def empty(self): return _ChemScript14.ElementList_empty(self)
    def size(self): return _ChemScript14.ElementList_size(self)
    def clear(self): return _ChemScript14.ElementList_clear(self)
    def swap(self, *args): return _ChemScript14.ElementList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.ElementList_get_allocator(self)
    def begin(self): return _ChemScript14.ElementList_begin(self)
    def end(self): return _ChemScript14.ElementList_end(self)
    def rbegin(self): return _ChemScript14.ElementList_rbegin(self)
    def rend(self): return _ChemScript14.ElementList_rend(self)
    def pop_back(self): return _ChemScript14.ElementList_pop_back(self)
    def erase(self, *args): return _ChemScript14.ElementList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_ElementList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.ElementList_push_back(self, *args)
    def front(self): return _ChemScript14.ElementList_front(self)
    def back(self): return _ChemScript14.ElementList_back(self)
    def assign(self, *args): return _ChemScript14.ElementList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.ElementList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.ElementList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.ElementList_reserve(self, *args)
    def capacity(self): return _ChemScript14.ElementList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_ElementList
    __del__ = lambda self : None;
ElementList_swigregister = _ChemScript14.ElementList_swigregister
ElementList_swigregister(ElementList)

class Element(_object):
    """
Class of Element. 


Users cannot create Element object directly.  
Use PeriodicTable.GetElement() to get an Element object.


    """
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Element, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Element, name)
    __repr__ = _swig_repr
    def Isotopes(self):
        """
Get Isotopes of Element


        """
        return _ChemScript14.Element_Isotopes(self)
    def ToString(self): return _ChemScript14.Element_ToString(self)
    __swig_getmethods__["AverageMass"] = _ChemScript14.Element_AverageMass_get
    if _newclass:AverageMass = _swig_property(_ChemScript14.Element_AverageMass_get, doc=
        """
Get AverageMass of Element, at natural abundance.


        """
    )
    __swig_getmethods__["ExactMass"] = _ChemScript14.Element_ExactMass_get
    if _newclass:ExactMass = _swig_property(_ChemScript14.Element_ExactMass_get, doc=
        """
Get ExactMass of Element


        """
    )
    __swig_getmethods__["CommonIsotope"] = _ChemScript14.Element_CommonIsotope_get
    if _newclass:CommonIsotope = _swig_property(_ChemScript14.Element_CommonIsotope_get, doc=
        """
Get CommonIsotope of Element


        """
    )
    __swig_getmethods__["AtomicNumber"] = _ChemScript14.Element_AtomicNumber_get
    if _newclass:AtomicNumber = _swig_property(_ChemScript14.Element_AtomicNumber_get, doc=
        """
Get AtomicNumber of Element


        """
    )
    __swig_getmethods__["IsotopeMassNumber"] = _ChemScript14.Element_IsotopeMassNumber_get
    if _newclass:IsotopeMassNumber = _swig_property(_ChemScript14.Element_IsotopeMassNumber_get, doc=
        """
Get IsotopeMassNumber of Element


        """
    )
    __swig_getmethods__["Symbol"] = _ChemScript14.Element_Symbol_get
    if _newclass:Symbol = _swig_property(_ChemScript14.Element_Symbol_get, doc=
        """
Get Symbol of Element


        """
    )
    __swig_getmethods__["FullName"] = _ChemScript14.Element_FullName_get
    if _newclass:FullName = _swig_property(_ChemScript14.Element_FullName_get, doc=
        """
Get FullName of Element


        """
    )
    __swig_getmethods__["Density"] = _ChemScript14.Element_Density_get
    if _newclass:Density = _swig_property(_ChemScript14.Element_Density_get, doc=
        """
Get Density of Element, unit: g/ml


        """
    )
    __swig_getmethods__["MP"] = _ChemScript14.Element_MP_get
    if _newclass:MP = _swig_property(_ChemScript14.Element_MP_get, doc=
        """
Get MP of Element, unit: Celsius


        """
    )
    __swig_getmethods__["BP"] = _ChemScript14.Element_BP_get
    if _newclass:BP = _swig_property(_ChemScript14.Element_BP_get, doc=
        """
Get BP of Element, unit: Celsius


        """
    )
    __swig_getmethods__["IP"] = _ChemScript14.Element_IP_get
    if _newclass:IP = _swig_property(_ChemScript14.Element_IP_get, doc=
        """
Get IP of Element, unit: kJ/mol


        """
    )
    __swig_getmethods__["Electronegativity"] = _ChemScript14.Element_Electronegativity_get
    if _newclass:Electronegativity = _swig_property(_ChemScript14.Element_Electronegativity_get, doc=
        """
Get Electronegativity of Element, unit is "Pauling"


        """
    )
    __swig_getmethods__["Radius"] = _ChemScript14.Element_Radius_get
    if _newclass:Radius = _swig_property(_ChemScript14.Element_Radius_get, doc=
        """
Get Radius of Element, unit: Angstroms


        """
    )
    __swig_getmethods__["DiscoveredBy"] = _ChemScript14.Element_DiscoveredBy_get
    if _newclass:DiscoveredBy = _swig_property(_ChemScript14.Element_DiscoveredBy_get, doc=
        """
Get DiscoveredBy of Element


        """
    )
    def __init__(self): 
        this = _ChemScript14.new_Element()
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _ChemScript14.delete_Element
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


Element_swigregister = _ChemScript14.Element_swigregister
Element_swigregister(Element)

class IsotopeList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, IsotopeList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, IsotopeList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.IsotopeList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.IsotopeList___nonzero__(self)
    def __bool__(self): return _ChemScript14.IsotopeList___bool__(self)
    def __len__(self): return _ChemScript14.IsotopeList___len__(self)
    def pop(self): return _ChemScript14.IsotopeList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.IsotopeList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.IsotopeList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.IsotopeList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.IsotopeList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.IsotopeList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.IsotopeList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.IsotopeList_append(self, *args)
    def empty(self): return _ChemScript14.IsotopeList_empty(self)
    def size(self): return _ChemScript14.IsotopeList_size(self)
    def clear(self): return _ChemScript14.IsotopeList_clear(self)
    def swap(self, *args): return _ChemScript14.IsotopeList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.IsotopeList_get_allocator(self)
    def begin(self): return _ChemScript14.IsotopeList_begin(self)
    def end(self): return _ChemScript14.IsotopeList_end(self)
    def rbegin(self): return _ChemScript14.IsotopeList_rbegin(self)
    def rend(self): return _ChemScript14.IsotopeList_rend(self)
    def pop_back(self): return _ChemScript14.IsotopeList_pop_back(self)
    def erase(self, *args): return _ChemScript14.IsotopeList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_IsotopeList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.IsotopeList_push_back(self, *args)
    def front(self): return _ChemScript14.IsotopeList_front(self)
    def back(self): return _ChemScript14.IsotopeList_back(self)
    def assign(self, *args): return _ChemScript14.IsotopeList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.IsotopeList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.IsotopeList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.IsotopeList_reserve(self, *args)
    def capacity(self): return _ChemScript14.IsotopeList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_IsotopeList
    __del__ = lambda self : None;
    def __repr__(self):
        r = ""
        b = 0
        for j in self:
            if b == 1 : 
                r = r + ", "
            r = r + j.__repr__()
            b = 1
        return "[%s]" % (r)


IsotopeList_swigregister = _ChemScript14.IsotopeList_swigregister
IsotopeList_swigregister(IsotopeList)

class Isotope(_object):
    """
Class of Isotope. 


Users cannot create Isotope object directly.  
Use Element.CommonIsotope() to get an Isotope object.
Or use Element.Isotopes() to get a list of Isotope objects.


    """
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Isotope, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Isotope, name)
    __repr__ = _swig_repr
    def ToString(self): return _ChemScript14.Isotope_ToString(self)
    __swig_getmethods__["MassNumber"] = _ChemScript14.Isotope_MassNumber_get
    if _newclass:MassNumber = _swig_property(_ChemScript14.Isotope_MassNumber_get)
    __swig_getmethods__["Mass"] = _ChemScript14.Isotope_Mass_get
    if _newclass:Mass = _swig_property(_ChemScript14.Isotope_Mass_get)
    __swig_getmethods__["AbundancePercent"] = _ChemScript14.Isotope_AbundancePercent_get
    if _newclass:AbundancePercent = _swig_property(_ChemScript14.Isotope_AbundancePercent_get)
    __swig_getmethods__["Symbol"] = _ChemScript14.Isotope_Symbol_get
    if _newclass:Symbol = _swig_property(_ChemScript14.Isotope_Symbol_get)
    def __init__(self): 
        this = _ChemScript14.new_Isotope()
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _ChemScript14.delete_Isotope
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)


Isotope_swigregister = _ChemScript14.Isotope_swigregister
Isotope_swigregister(Isotope)

class RingList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, RingList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, RingList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.RingList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.RingList___nonzero__(self)
    def __bool__(self): return _ChemScript14.RingList___bool__(self)
    def __len__(self): return _ChemScript14.RingList___len__(self)
    def pop(self): return _ChemScript14.RingList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.RingList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.RingList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.RingList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.RingList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.RingList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.RingList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.RingList_append(self, *args)
    def empty(self): return _ChemScript14.RingList_empty(self)
    def size(self): return _ChemScript14.RingList_size(self)
    def clear(self): return _ChemScript14.RingList_clear(self)
    def swap(self, *args): return _ChemScript14.RingList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.RingList_get_allocator(self)
    def begin(self): return _ChemScript14.RingList_begin(self)
    def end(self): return _ChemScript14.RingList_end(self)
    def rbegin(self): return _ChemScript14.RingList_rbegin(self)
    def rend(self): return _ChemScript14.RingList_rend(self)
    def pop_back(self): return _ChemScript14.RingList_pop_back(self)
    def erase(self, *args): return _ChemScript14.RingList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_RingList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.RingList_push_back(self, *args)
    def front(self): return _ChemScript14.RingList_front(self)
    def back(self): return _ChemScript14.RingList_back(self)
    def assign(self, *args): return _ChemScript14.RingList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.RingList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.RingList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.RingList_reserve(self, *args)
    def capacity(self): return _ChemScript14.RingList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_RingList
    __del__ = lambda self : None;
RingList_swigregister = _ChemScript14.RingList_swigregister
RingList_swigregister(RingList)

class Ring(ChemScriptBase):
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, Ring, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, Ring, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    def ToString(self): return _ChemScript14.Ring_ToString(self)
    __swig_getmethods__["Atoms"] = _ChemScript14.Ring_Atoms_get
    if _newclass:Atoms = _swig_property(_ChemScript14.Ring_Atoms_get, doc=
        """
Get all ring atoms as a list


        """
    )
    __swig_getmethods__["Bonds"] = _ChemScript14.Ring_Bonds_get
    if _newclass:Bonds = _swig_property(_ChemScript14.Ring_Bonds_get, doc=
        """
Get all ring bonds as a list


        """
    )
    __swig_destroy__ = _ChemScript14.delete_Ring
    __del__ = lambda self : None;
    def __getattr__(self, name):
        if name == "atoms":
            return self.GetAtoms();
        elif name == "bonds":
            return self.GetBonds();
        else:
            raise AttributeError(name)
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)
    def List(self, atom = True, bond = True, coordinates = False):
        """
 list atoms and/or bonds in this Ring
 >>> m = StructureData.LoadData('CC=CO')
 >>> m.List()
        """
        print (self)
        if (self.atoms == None or len(self.atoms) == 0):
            print (self, "is empty.")
        else:
            print ('atoms:')
            if (atom):
                for a in self.atoms:
                    coord = ''
                    if (coordinates):
                        p = a.GetCartesian();
                        coord = '(' + str(p.x) + ', ' + str(p.y) + ', ' + str(p.z) + ')'
                    print ('  ', a.Name, coord)
            print ('bonds:')
            if (bond):
                for b in self.bonds:
                    print ('  ', b.Name)


Ring_swigregister = _ChemScript14.Ring_swigregister
Ring_swigregister(Ring)

class RingInfoList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, RingInfoList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, RingInfoList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.RingInfoList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.RingInfoList___nonzero__(self)
    def __bool__(self): return _ChemScript14.RingInfoList___bool__(self)
    def __len__(self): return _ChemScript14.RingInfoList___len__(self)
    def pop(self): return _ChemScript14.RingInfoList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.RingInfoList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.RingInfoList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.RingInfoList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.RingInfoList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.RingInfoList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.RingInfoList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.RingInfoList_append(self, *args)
    def empty(self): return _ChemScript14.RingInfoList_empty(self)
    def size(self): return _ChemScript14.RingInfoList_size(self)
    def clear(self): return _ChemScript14.RingInfoList_clear(self)
    def swap(self, *args): return _ChemScript14.RingInfoList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.RingInfoList_get_allocator(self)
    def begin(self): return _ChemScript14.RingInfoList_begin(self)
    def end(self): return _ChemScript14.RingInfoList_end(self)
    def rbegin(self): return _ChemScript14.RingInfoList_rbegin(self)
    def rend(self): return _ChemScript14.RingInfoList_rend(self)
    def pop_back(self): return _ChemScript14.RingInfoList_pop_back(self)
    def erase(self, *args): return _ChemScript14.RingInfoList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_RingInfoList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.RingInfoList_push_back(self, *args)
    def front(self): return _ChemScript14.RingInfoList_front(self)
    def back(self): return _ChemScript14.RingInfoList_back(self)
    def assign(self, *args): return _ChemScript14.RingInfoList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.RingInfoList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.RingInfoList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.RingInfoList_reserve(self, *args)
    def capacity(self): return _ChemScript14.RingInfoList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_RingInfoList
    __del__ = lambda self : None;
RingInfoList_swigregister = _ChemScript14.RingInfoList_swigregister
RingInfoList_swigregister(RingInfoList)

class RingInfo(ChemScriptBase):
    """
Class of ring information of a StructureData
    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, RingInfo, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, RingInfo, name)
    __repr__ = _swig_repr
    def __init__(self, structure): 
        """
constructor


        """
        this = _ChemScript14.new_RingInfo(structure)
        try: self.this.append(this)
        except: self.this = this
    def FundamentalRings(self):
        """
get fundamental rings as a Ring list
Fundamental, or SSSR (smallest set of smallest rings).  Represents a linear
basis set, from which all other rings can be generated (by XOR'ing the bonds).


        """
        return _ChemScript14.RingInfo_FundamentalRings(self)
    def ExtendedRings(self):
        """
get extended rings as a Ring list
Extended, aka "kappa".  These are rings that could as validly have been selected
for the SSSR, and have the same size as the largest SSSR ring(s).  For example,	
Bicyclo[2.2.2]octane has three rings but is bicyclic.  Which two go into the	
SSSR is an arbitrary choice.  The third goes into the extended set.


        """
        return _ChemScript14.RingInfo_ExtendedRings(self)
    def BasicRings(self):
        """
get basic rings as a Ring list
"Basic" rings are the fundamental plus the extended.


        """
        return _ChemScript14.RingInfo_BasicRings(self)
    def NecklaceRings(self):
        """
get complex rings as a Ring list.
A necklace ring is a ring that bridges at least one ring less than half its
size.  We suppress the extended and composite rings of necklace rings of size
greater than fifteen (arbitrary)


        """
        return _ChemScript14.RingInfo_NecklaceRings(self)
    def BridgedRings(self):
        """
get bridged rings as a Ring list
Bridging rings are basic rings that share more than one bond with another basic ring.


        """
        return _ChemScript14.RingInfo_BridgedRings(self)
    def AromaticRings(self):
        """
get aromatic rings as a Ring list


        """
        return _ChemScript14.RingInfo_AromaticRings(self)
    def SpiroAtoms(self):
        """
get spiro atoms as an Atom list


        """
        return _ChemScript14.RingInfo_SpiroAtoms(self)
    def FusionAtoms(self):
        """
get fusion atoms as an Atom list


        """
        return _ChemScript14.RingInfo_FusionAtoms(self)
    def BridgeAtoms(self):
        """
get bridge atoms as an Atom list


        """
        return _ChemScript14.RingInfo_BridgeAtoms(self)
    def BridgeheadAtoms(self):
        """
get bridgehead atoms as an Atom list


        """
        return _ChemScript14.RingInfo_BridgeheadAtoms(self)
    def HydrogenAcceptorAtoms(self):
        """
get hydrogen-acceptor atoms as an Atom list


        """
        return _ChemScript14.RingInfo_HydrogenAcceptorAtoms(self)
    def HydrogenDonorAtoms(self):
        """
get hydrogen-donor atoms as an Atom list


        """
        return _ChemScript14.RingInfo_HydrogenDonorAtoms(self)
    def FusionBonds(self):
        """
get fusion bonds as a Bond list


        """
        return _ChemScript14.RingInfo_FusionBonds(self)
    def BridgeBonds(self):
        """
get bridge bonds as a Bond list


        """
        return _ChemScript14.RingInfo_BridgeBonds(self)
    def ToString(self): return _ChemScript14.RingInfo_ToString(self)
    __swig_getmethods__["AtomsWithVacantPiOrbitals"] = _ChemScript14.RingInfo_AtomsWithVacantPiOrbitals_get
    if _newclass:AtomsWithVacantPiOrbitals = _swig_property(_ChemScript14.RingInfo_AtomsWithVacantPiOrbitals_get, doc=
        """
get atoms with vacant Pi orbitals as an Atom list


        """
    )
    __swig_getmethods__["LonePairAtoms"] = _ChemScript14.RingInfo_LonePairAtoms_get
    if _newclass:LonePairAtoms = _swig_property(_ChemScript14.RingInfo_LonePairAtoms_get, doc=
        """
get lone pair atoms as an Atom list


        """
    )
    __swig_destroy__ = _ChemScript14.delete_RingInfo
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)


RingInfo_swigregister = _ChemScript14.RingInfo_swigregister
RingInfo_swigregister(RingInfo)

class SaltTableList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, SaltTableList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, SaltTableList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.SaltTableList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.SaltTableList___nonzero__(self)
    def __bool__(self): return _ChemScript14.SaltTableList___bool__(self)
    def __len__(self): return _ChemScript14.SaltTableList___len__(self)
    def pop(self): return _ChemScript14.SaltTableList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.SaltTableList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.SaltTableList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.SaltTableList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.SaltTableList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.SaltTableList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.SaltTableList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.SaltTableList_append(self, *args)
    def empty(self): return _ChemScript14.SaltTableList_empty(self)
    def size(self): return _ChemScript14.SaltTableList_size(self)
    def clear(self): return _ChemScript14.SaltTableList_clear(self)
    def swap(self, *args): return _ChemScript14.SaltTableList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.SaltTableList_get_allocator(self)
    def begin(self): return _ChemScript14.SaltTableList_begin(self)
    def end(self): return _ChemScript14.SaltTableList_end(self)
    def rbegin(self): return _ChemScript14.SaltTableList_rbegin(self)
    def rend(self): return _ChemScript14.SaltTableList_rend(self)
    def pop_back(self): return _ChemScript14.SaltTableList_pop_back(self)
    def erase(self, *args): return _ChemScript14.SaltTableList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_SaltTableList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.SaltTableList_push_back(self, *args)
    def front(self): return _ChemScript14.SaltTableList_front(self)
    def back(self): return _ChemScript14.SaltTableList_back(self)
    def assign(self, *args): return _ChemScript14.SaltTableList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.SaltTableList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.SaltTableList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.SaltTableList_reserve(self, *args)
    def capacity(self): return _ChemScript14.SaltTableList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_SaltTableList
    __del__ = lambda self : None;
SaltTableList_swigregister = _ChemScript14.SaltTableList_swigregister
SaltTableList_swigregister(SaltTableList)

class SaltTable(ChemScriptBase):
    """
Provide a customized way when do StructureData.SplitSalt().

    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, SaltTable, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, SaltTable, name)
    __repr__ = _swig_repr
    IIF_MustBeCharged = _ChemScript14.SaltTable_IIF_MustBeCharged
    IIF_MustBeNeutral = _ChemScript14.SaltTable_IIF_MustBeNeutral
    IIF_NoHeuristics = _ChemScript14.SaltTable_IIF_NoHeuristics
    IIF_OkToExhaustStructure = _ChemScript14.SaltTable_IIF_OkToExhaustStructure
    IIF_OkToExhaustComponent = _ChemScript14.SaltTable_IIF_OkToExhaustComponent
    IIF_IsotopesAreNotIncidental = _ChemScript14.SaltTable_IIF_IsotopesAreNotIncidental
    IIF_SkipSearchForRedundant = _ChemScript14.SaltTable_IIF_SkipSearchForRedundant
    IIF_CustomDoesNotTrumpInorganic = _ChemScript14.SaltTable_IIF_CustomDoesNotTrumpInorganic
    IIF_OrganicExcludes_C_H = _ChemScript14.SaltTable_IIF_OrganicExcludes_C_H
    IIF_OrganicExcludes_C_C = _ChemScript14.SaltTable_IIF_OrganicExcludes_C_C
    IIF_OrganicExcludes_C_X = _ChemScript14.SaltTable_IIF_OrganicExcludes_C_X
    IIF_DontKeepMetalBetaDiketonates = _ChemScript14.SaltTable_IIF_DontKeepMetalBetaDiketonates
    IIF_AssignToCustomIfBoth = _ChemScript14.SaltTable_IIF_AssignToCustomIfBoth
    IIF_InterestedInCategories = _ChemScript14.SaltTable_IIF_InterestedInCategories
    IIF_SpareSimpleAmines = _ChemScript14.SaltTable_IIF_SpareSimpleAmines
    IIF_SpareNeutralLoner = _ChemScript14.SaltTable_IIF_SpareNeutralLoner
    IIF_SpareCationicMetal = _ChemScript14.SaltTable_IIF_SpareCationicMetal
    IIF_Default = _ChemScript14.SaltTable_IIF_Default
    def __init__(self, fPrimeWithCommonOrganicFragments = False, IIF = 0): 
        this = _ChemScript14.new_SaltTable(fPrimeWithCommonOrganicFragments, IIF)
        try: self.this.append(this)
        except: self.this = this
    def RegisterFragment(self, fragment, asSolvent = False, fMustBeCharged = False, fMustBeNeutral = False):
        """
Registry a new salt/solvent fragment defined by a StructureData object


        """
        return _ChemScript14.SaltTable_RegisterFragment(self, fragment, asSolvent, fMustBeCharged, fMustBeNeutral)
    def ClearFragmentList(self):
        """
Clear all salt/solvent fragments registered on this salt table


        """
        return _ChemScript14.SaltTable_ClearFragmentList(self)
    def PrimeWithCommonOrganicFragments(self):
        """
Register the default salt/solvent fragments


        """
        return _ChemScript14.SaltTable_PrimeWithCommonOrganicFragments(self)
    def RegisterWithSmiles(self, smiles, asSolvent = False, fMustBeCharged = False, fMustBeNeutral = False):
        """
Registry a new salt/solvent fragment defined by a SMILES string


        """
        return _ChemScript14.SaltTable_RegisterWithSmiles(self, smiles, asSolvent, fMustBeCharged, fMustBeNeutral)
    def RegisterInchi(self, inchi, asSolvent = False, fMustBeCharged = False, fMustBeNeutral = False):
        """
Registry a new salt/solvent fragment defined by an InChI string


        """
        return _ChemScript14.SaltTable_RegisterInchi(self, inchi, asSolvent, fMustBeCharged, fMustBeNeutral)
    def RegisterWithSmilesFile(self, smilefile, asSolvent = False):
        """
Registry salt/solvent fragments defined by a SMILES file.
A sample salt table File:
---------------------------------------
# my salts
O=S(C1=CC=CC=C1)([O-])=O
O=C(CC(C(C)1C)CC2)C21CS(=O)([O-])=O
CCCCCC([O-])=O
# other salts
O=S(C1=CC=C(Cl)C=C1)([O-])=O
O=C(C1(CC2)C=CC2(C)CC1)[O-]
O=C([O-])CCC1CCCC1
---------------------------------------


        """
        return _ChemScript14.SaltTable_RegisterWithSmilesFile(self, smilefile, asSolvent)
    def Clear(self):
        """
Clear all salt/solvent fragments registered on this salt table


        """
        return _ChemScript14.SaltTable_Clear(self)
    def LoadDefault(self):
        """
Register the default salt/solvent fragments


        """
        return _ChemScript14.SaltTable_LoadDefault(self)
    def RemoveSaltsAndSolvents(self, m, options = 3):
        """
Remove salts and solvents, and returns the main structure
Python Example:
>>> m = StructureData.LoadData('CCCCCN.[Na+].[Na+].c1ccccc1.[O]')
Open molecule successfully: chemical/x-smiles
>>> st = SaltTable()
>>> m1 = st.RemoveSaltsAndSolvents(m)
>>> print(m1)
<ChemScript.MolPtr: C11H19N ()>


        """
        return _ChemScript14.SaltTable_RemoveSaltsAndSolvents(self, m, options)
    def SplitSaltsAndSolvents(self, m, options = 3):
        """
Split salts and solvents, and returns a List containing main structure, separated single salts and solvents
Python Example:
>>> m = StructureData.LoadData('CCCCCN.[Na+].[Na+].c1ccccc1.[O]')
Open molecule successfully: chemical/x-smiles
>>> st = SaltTable()
>>> st.RegisterWithSmiles("[Na+]", False)
True
>>> st.RegisterWithSmiles("c1ccccc1", True)
True
>>> st.RegisterWithSmiles("[O]", True)
True
>>> lst = st.SplitSaltsAndSolvents(m)
>>> print(lst)
[<ChemScript.MolPtr: C5H13N ()>, [<ChemScript.MolPtr: Na+ ()>, <ChemScript.MolPtr: Na+ ()>], [<ChemScript.MolPtr: C6H6 ()>, <ChemScript.MolPtr: O ()>]]


        """
        return _ChemScript14.SaltTable_SplitSaltsAndSolvents(self, m, options)
    def SplitSaltAndSolvent(self, structure, options =3):
        """
Split salts and solvents, and returns a Dict containing main structure, combined salt and solvent
Python Example:
>>> m = StructureData.LoadData('CCCCCN.[Na+].[Na+].c1ccccc1.[O]')
Open molecule successfully: chemical/x-smiles
>>> st = SaltTable()
>>> st.RegisterWithSmiles("[Na+]", False)
True
>>> st.RegisterWithSmiles("c1ccccc1", True)
True
>>> st.RegisterWithSmiles("[O]", True)
True
>>> dct = st.SplitSaltAndSolvent(m)
>>> dct
{<ChemScript.MolPtr: C5H13N ()>: 1, <ChemScript.MolPtr: Na+ ()>: 2, <ChemScript.MolPtr: C6H6O ()>: 1}
NOTE: in this example, the two [Na+]'s are returned as salts with repeating number 2;
c1ccccc1 and [O] are combined as a solvent with repeating number 1.


        """
        return _ChemScript14.SaltTable_SplitSaltAndSolvent(self, structure, options)
    def All(self):
        return _ChemScript14.SaltTable_All(self)
    def Salts(self):
        return _ChemScript14.SaltTable_Salts(self)
    def Solvents(self):
        return _ChemScript14.SaltTable_Solvents(self)
    def ListAll(self):
        return _ChemScript14.SaltTable_ListAll(self)
    def ListSalts(self):
        return _ChemScript14.SaltTable_ListSalts(self)
    def ListSolvents(self):
        return _ChemScript14.SaltTable_ListSolvents(self)
    __swig_destroy__ = _ChemScript14.delete_SaltTable
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)


SaltTable_swigregister = _ChemScript14.SaltTable_swigregister
SaltTable_swigregister(SaltTable)

class NormOptionsList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, NormOptionsList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, NormOptionsList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.NormOptionsList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.NormOptionsList___nonzero__(self)
    def __bool__(self): return _ChemScript14.NormOptionsList___bool__(self)
    def __len__(self): return _ChemScript14.NormOptionsList___len__(self)
    def pop(self): return _ChemScript14.NormOptionsList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.NormOptionsList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.NormOptionsList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.NormOptionsList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.NormOptionsList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.NormOptionsList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.NormOptionsList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.NormOptionsList_append(self, *args)
    def empty(self): return _ChemScript14.NormOptionsList_empty(self)
    def size(self): return _ChemScript14.NormOptionsList_size(self)
    def clear(self): return _ChemScript14.NormOptionsList_clear(self)
    def swap(self, *args): return _ChemScript14.NormOptionsList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.NormOptionsList_get_allocator(self)
    def begin(self): return _ChemScript14.NormOptionsList_begin(self)
    def end(self): return _ChemScript14.NormOptionsList_end(self)
    def rbegin(self): return _ChemScript14.NormOptionsList_rbegin(self)
    def rend(self): return _ChemScript14.NormOptionsList_rend(self)
    def pop_back(self): return _ChemScript14.NormOptionsList_pop_back(self)
    def erase(self, *args): return _ChemScript14.NormOptionsList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_NormOptionsList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.NormOptionsList_push_back(self, *args)
    def front(self): return _ChemScript14.NormOptionsList_front(self)
    def back(self): return _ChemScript14.NormOptionsList_back(self)
    def assign(self, *args): return _ChemScript14.NormOptionsList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.NormOptionsList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.NormOptionsList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.NormOptionsList_reserve(self, *args)
    def capacity(self): return _ChemScript14.NormOptionsList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_NormOptionsList
    __del__ = lambda self : None;
NormOptionsList_swigregister = _ChemScript14.NormOptionsList_swigregister
NormOptionsList_swigregister(NormOptionsList)

class NormOptions(ChemScriptBase):
    """
class of Normalization Options:


Option                    Meanings
----------------------------------------------------------------------------
RemoveRTable       : Delete an empty R-group table.
RemoveRxnCenters   : Strip reaction centers from non-reactions.
RemoveTextAtoms    : Remove textual pieces.  Alternatively, convert
: R-atoms with no substituents that are labeled to
: textual atoms.
ProvideMissingCoords  : Provide coordinates if missing.  Lack of coordinates
: interferes with perception of stereochemistry in,
: for example, benzene rings.
RemoveValence      : Strip the manual valence setting if it is
: unnecessary.  Cf. registration, when the override
: may be removed in all cases.
: Ex:    R4N+[V=4]  ->  R4N+
RemoveIsotopy      : Clear nonsensical isotopic abundance settings.
AnonList           : Convert an anonymous element list with one member
: to a regular substituent.
Delrep             : Ensure the bonds referenced by delreps have the
: "delocalized" type. Discard neutral, non-bonded
: delreps.
: Instead, convert the bonds they describe to the
: delocalized type.  Handles the trivial case of a
: delrep referencing no bonds.
RemoveNonGraphStereo  : Remove unnecessary external stereochemistry.
RemoveWedge        : Strip unnecessary graphical stereobonds about
: incapable tetrahedral atoms. For expediency, we
: throw in a different rule:
:    strip reaction stereo indicators from
:    non-reactions.
StripEitherDoubleBond : Strip the "Either" marking from Incapable double
: bonds.
StripEitherSingleBond : Strip the "Either" marking from Incapable single
: bonds.
RemoveLabel        : Link nodes represented with atom type "R" require
: no label. Remove unnecessary atom labels, including
: "R".
Thiazole           : Repair badly Dekekulized thiazoles. e.g.:
:    C1=S=CN=C1   ->   C1SC=NC=1
Dekekulize         : This is necessary for tautomeric searching.
Diazo_a            : Diazo: Convert C(-)-N(+)#N  ->  C=N(+)=N(-)
: Cf. other diazo conversion.
Diazo_b            : Diazo: Convert C=N#N  ->  C=N(+)=N(-)
: Cf. other diazo conversions.
NeutralDiazo_fg    : Convert neutral diazo to zwitterion.
: Cf. the other diazo treatment.
: C=N=N  -> C=N(+)=N(-) (diazo)
Isonitrile_fg      : Convert neutral isonitrile to zwitterion.
: C#N--R  -->  C(-)#N(+)--R
Azide              : Azide: Convert -N(-)-N(+)#N  to  -N=N(+)=N(-)
R3NO_b             : Convert R3N(=O)  to  R3N[+]-O[-], where R means one
: valence unit, not necessarily a substituent.
:    Examples:
:             Nitro groups drawn as R-N(=O)(=O)
:             Quinoline N-oxides drawn with
:                pentavalent N:  ...C=N(=O)-C
:             Also, remove erroneous label-H count
:                from H2N(R)=O  -> N(R)=O.
:             Alternatively, it might be
:                H2N(R)=O  ->  HN(R)-OH
MergeCharges       : Convert X(+)--Y(-) to X=Y, particularly S(+)--O(-)
: to S=O.
:    If a double bond is not appropriate, don't
:    increase the bond order.
:    	       B(+)-O(-)    ==>  B=O
CreateDelRep_1     : Convert a metal bonded to several adjacent,
: delocalized atoms, to a mu bond.
CreateDelRep_2     : Create a mu bond between a metal and a ring most of
: whose atoms are radicals.
:    In particular, all the atoms in the ring must be
:    radicals save those already bonded to the metal.
CreateDelRep_3     : Convert a metal bonded to a ring of saturated atoms.
CollapseZwitterion : Convert  R(+)--X(-)  to  R--X when R and X are both
: hypervalent.
:    Ex:    [F(-)]4B(+3)  ==>  F4B(-)
:    (CAS RN 676-88-0 in NCI).
XMinusToX_fg       : Convert --X(-) ==> --X, and in particular, R3B--X(-)
: to R3B(-)--X
FeaturelessHydrogens  : Strip featureless hydrogens (formerly: and convert
: "H" to "H-H").  Our only reason for stripping is to
: simplify the connection table, and speed ABAS
: minutely.
Dative             : Convert certain plain bonds to dative bonds.
DativeToDouble     : Convert certain Dative bonds to double, e.g. S->O
: and P->N.  The donor must be N, O or one of their
: congeners, approximately.  The recipient can be any
: element, provided both it and the donor can support
: the increase in bond order.
:    	{S,P}->{O,N,Se}
: Also, N-><chalc> when the nitrogen is bivalent.
MoveChargeFromCarbon  : MoveChargeFromCarbon:  Convert nitrone   R2C(+)-NR2
: to  R2C=N(+)R2
CleaveIntoSalts    : Li-I  ->  Li+ I-;   NaOAc  ->  Na+ OAc-
MergeMetalSalts    : Na+ OAc-  ->  NaOAc;   Li+ I-  ->  Li-I


    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, NormOptions, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, NormOptions, name)
    __repr__ = _swig_repr
    def __init__(self): 
        this = _ChemScript14.new_NormOptions()
        try: self.this.append(this)
        except: self.this = this
    def List(self):
        """
List all flags


        """
        return _ChemScript14.NormOptions_List(self)
    __swig_setmethods__["RemoveRTable"] = _ChemScript14.NormOptions_RemoveRTable_set
    __swig_getmethods__["RemoveRTable"] = _ChemScript14.NormOptions_RemoveRTable_get
    if _newclass:RemoveRTable = _swig_property(_ChemScript14.NormOptions_RemoveRTable_get, _ChemScript14.NormOptions_RemoveRTable_set)
    __swig_setmethods__["RemoveRxnCenters"] = _ChemScript14.NormOptions_RemoveRxnCenters_set
    __swig_getmethods__["RemoveRxnCenters"] = _ChemScript14.NormOptions_RemoveRxnCenters_get
    if _newclass:RemoveRxnCenters = _swig_property(_ChemScript14.NormOptions_RemoveRxnCenters_get, _ChemScript14.NormOptions_RemoveRxnCenters_set)
    __swig_setmethods__["RemoveTextAtoms"] = _ChemScript14.NormOptions_RemoveTextAtoms_set
    __swig_getmethods__["RemoveTextAtoms"] = _ChemScript14.NormOptions_RemoveTextAtoms_get
    if _newclass:RemoveTextAtoms = _swig_property(_ChemScript14.NormOptions_RemoveTextAtoms_get, _ChemScript14.NormOptions_RemoveTextAtoms_set)
    __swig_setmethods__["ProvideMissingCoords"] = _ChemScript14.NormOptions_ProvideMissingCoords_set
    __swig_getmethods__["ProvideMissingCoords"] = _ChemScript14.NormOptions_ProvideMissingCoords_get
    if _newclass:ProvideMissingCoords = _swig_property(_ChemScript14.NormOptions_ProvideMissingCoords_get, _ChemScript14.NormOptions_ProvideMissingCoords_set)
    __swig_setmethods__["RemoveValence"] = _ChemScript14.NormOptions_RemoveValence_set
    __swig_getmethods__["RemoveValence"] = _ChemScript14.NormOptions_RemoveValence_get
    if _newclass:RemoveValence = _swig_property(_ChemScript14.NormOptions_RemoveValence_get, _ChemScript14.NormOptions_RemoveValence_set)
    __swig_setmethods__["RemoveIsotopy"] = _ChemScript14.NormOptions_RemoveIsotopy_set
    __swig_getmethods__["RemoveIsotopy"] = _ChemScript14.NormOptions_RemoveIsotopy_get
    if _newclass:RemoveIsotopy = _swig_property(_ChemScript14.NormOptions_RemoveIsotopy_get, _ChemScript14.NormOptions_RemoveIsotopy_set)
    __swig_setmethods__["AnonList"] = _ChemScript14.NormOptions_AnonList_set
    __swig_getmethods__["AnonList"] = _ChemScript14.NormOptions_AnonList_get
    if _newclass:AnonList = _swig_property(_ChemScript14.NormOptions_AnonList_get, _ChemScript14.NormOptions_AnonList_set)
    __swig_setmethods__["Delrep"] = _ChemScript14.NormOptions_Delrep_set
    __swig_getmethods__["Delrep"] = _ChemScript14.NormOptions_Delrep_get
    if _newclass:Delrep = _swig_property(_ChemScript14.NormOptions_Delrep_get, _ChemScript14.NormOptions_Delrep_set)
    __swig_setmethods__["RemoveNonGraphStereo"] = _ChemScript14.NormOptions_RemoveNonGraphStereo_set
    __swig_getmethods__["RemoveNonGraphStereo"] = _ChemScript14.NormOptions_RemoveNonGraphStereo_get
    if _newclass:RemoveNonGraphStereo = _swig_property(_ChemScript14.NormOptions_RemoveNonGraphStereo_get, _ChemScript14.NormOptions_RemoveNonGraphStereo_set)
    __swig_setmethods__["RemoveWedge"] = _ChemScript14.NormOptions_RemoveWedge_set
    __swig_getmethods__["RemoveWedge"] = _ChemScript14.NormOptions_RemoveWedge_get
    if _newclass:RemoveWedge = _swig_property(_ChemScript14.NormOptions_RemoveWedge_get, _ChemScript14.NormOptions_RemoveWedge_set)
    __swig_setmethods__["StripEitherDoubleBond"] = _ChemScript14.NormOptions_StripEitherDoubleBond_set
    __swig_getmethods__["StripEitherDoubleBond"] = _ChemScript14.NormOptions_StripEitherDoubleBond_get
    if _newclass:StripEitherDoubleBond = _swig_property(_ChemScript14.NormOptions_StripEitherDoubleBond_get, _ChemScript14.NormOptions_StripEitherDoubleBond_set)
    __swig_setmethods__["StripEitherSingleBond"] = _ChemScript14.NormOptions_StripEitherSingleBond_set
    __swig_getmethods__["StripEitherSingleBond"] = _ChemScript14.NormOptions_StripEitherSingleBond_get
    if _newclass:StripEitherSingleBond = _swig_property(_ChemScript14.NormOptions_StripEitherSingleBond_get, _ChemScript14.NormOptions_StripEitherSingleBond_set)
    __swig_setmethods__["RemoveLabel"] = _ChemScript14.NormOptions_RemoveLabel_set
    __swig_getmethods__["RemoveLabel"] = _ChemScript14.NormOptions_RemoveLabel_get
    if _newclass:RemoveLabel = _swig_property(_ChemScript14.NormOptions_RemoveLabel_get, _ChemScript14.NormOptions_RemoveLabel_set)
    __swig_setmethods__["Thiazole"] = _ChemScript14.NormOptions_Thiazole_set
    __swig_getmethods__["Thiazole"] = _ChemScript14.NormOptions_Thiazole_get
    if _newclass:Thiazole = _swig_property(_ChemScript14.NormOptions_Thiazole_get, _ChemScript14.NormOptions_Thiazole_set)
    __swig_setmethods__["Dekekulize"] = _ChemScript14.NormOptions_Dekekulize_set
    __swig_getmethods__["Dekekulize"] = _ChemScript14.NormOptions_Dekekulize_get
    if _newclass:Dekekulize = _swig_property(_ChemScript14.NormOptions_Dekekulize_get, _ChemScript14.NormOptions_Dekekulize_set)
    __swig_setmethods__["Diazo_a"] = _ChemScript14.NormOptions_Diazo_a_set
    __swig_getmethods__["Diazo_a"] = _ChemScript14.NormOptions_Diazo_a_get
    if _newclass:Diazo_a = _swig_property(_ChemScript14.NormOptions_Diazo_a_get, _ChemScript14.NormOptions_Diazo_a_set)
    __swig_setmethods__["Diazo_b"] = _ChemScript14.NormOptions_Diazo_b_set
    __swig_getmethods__["Diazo_b"] = _ChemScript14.NormOptions_Diazo_b_get
    if _newclass:Diazo_b = _swig_property(_ChemScript14.NormOptions_Diazo_b_get, _ChemScript14.NormOptions_Diazo_b_set)
    __swig_setmethods__["NeutralDiazo_fg"] = _ChemScript14.NormOptions_NeutralDiazo_fg_set
    __swig_getmethods__["NeutralDiazo_fg"] = _ChemScript14.NormOptions_NeutralDiazo_fg_get
    if _newclass:NeutralDiazo_fg = _swig_property(_ChemScript14.NormOptions_NeutralDiazo_fg_get, _ChemScript14.NormOptions_NeutralDiazo_fg_set)
    __swig_setmethods__["Isonitrile_fg"] = _ChemScript14.NormOptions_Isonitrile_fg_set
    __swig_getmethods__["Isonitrile_fg"] = _ChemScript14.NormOptions_Isonitrile_fg_get
    if _newclass:Isonitrile_fg = _swig_property(_ChemScript14.NormOptions_Isonitrile_fg_get, _ChemScript14.NormOptions_Isonitrile_fg_set)
    __swig_setmethods__["Azide"] = _ChemScript14.NormOptions_Azide_set
    __swig_getmethods__["Azide"] = _ChemScript14.NormOptions_Azide_get
    if _newclass:Azide = _swig_property(_ChemScript14.NormOptions_Azide_get, _ChemScript14.NormOptions_Azide_set)
    __swig_setmethods__["R3NO_b"] = _ChemScript14.NormOptions_R3NO_b_set
    __swig_getmethods__["R3NO_b"] = _ChemScript14.NormOptions_R3NO_b_get
    if _newclass:R3NO_b = _swig_property(_ChemScript14.NormOptions_R3NO_b_get, _ChemScript14.NormOptions_R3NO_b_set)
    __swig_setmethods__["MergeCharges"] = _ChemScript14.NormOptions_MergeCharges_set
    __swig_getmethods__["MergeCharges"] = _ChemScript14.NormOptions_MergeCharges_get
    if _newclass:MergeCharges = _swig_property(_ChemScript14.NormOptions_MergeCharges_get, _ChemScript14.NormOptions_MergeCharges_set)
    __swig_setmethods__["CreatedDelRep_1"] = _ChemScript14.NormOptions_CreatedDelRep_1_set
    __swig_getmethods__["CreatedDelRep_1"] = _ChemScript14.NormOptions_CreatedDelRep_1_get
    if _newclass:CreatedDelRep_1 = _swig_property(_ChemScript14.NormOptions_CreatedDelRep_1_get, _ChemScript14.NormOptions_CreatedDelRep_1_set)
    __swig_setmethods__["CreatedDelRep_2"] = _ChemScript14.NormOptions_CreatedDelRep_2_set
    __swig_getmethods__["CreatedDelRep_2"] = _ChemScript14.NormOptions_CreatedDelRep_2_get
    if _newclass:CreatedDelRep_2 = _swig_property(_ChemScript14.NormOptions_CreatedDelRep_2_get, _ChemScript14.NormOptions_CreatedDelRep_2_set)
    __swig_setmethods__["CollapseZwitterion"] = _ChemScript14.NormOptions_CollapseZwitterion_set
    __swig_getmethods__["CollapseZwitterion"] = _ChemScript14.NormOptions_CollapseZwitterion_get
    if _newclass:CollapseZwitterion = _swig_property(_ChemScript14.NormOptions_CollapseZwitterion_get, _ChemScript14.NormOptions_CollapseZwitterion_set)
    __swig_setmethods__["XMinusToX_fg"] = _ChemScript14.NormOptions_XMinusToX_fg_set
    __swig_getmethods__["XMinusToX_fg"] = _ChemScript14.NormOptions_XMinusToX_fg_get
    if _newclass:XMinusToX_fg = _swig_property(_ChemScript14.NormOptions_XMinusToX_fg_get, _ChemScript14.NormOptions_XMinusToX_fg_set)
    __swig_setmethods__["FeaturelessHydrogens"] = _ChemScript14.NormOptions_FeaturelessHydrogens_set
    __swig_getmethods__["FeaturelessHydrogens"] = _ChemScript14.NormOptions_FeaturelessHydrogens_get
    if _newclass:FeaturelessHydrogens = _swig_property(_ChemScript14.NormOptions_FeaturelessHydrogens_get, _ChemScript14.NormOptions_FeaturelessHydrogens_set)
    __swig_setmethods__["Dative"] = _ChemScript14.NormOptions_Dative_set
    __swig_getmethods__["Dative"] = _ChemScript14.NormOptions_Dative_get
    if _newclass:Dative = _swig_property(_ChemScript14.NormOptions_Dative_get, _ChemScript14.NormOptions_Dative_set)
    __swig_setmethods__["DativeToDouble"] = _ChemScript14.NormOptions_DativeToDouble_set
    __swig_getmethods__["DativeToDouble"] = _ChemScript14.NormOptions_DativeToDouble_get
    if _newclass:DativeToDouble = _swig_property(_ChemScript14.NormOptions_DativeToDouble_get, _ChemScript14.NormOptions_DativeToDouble_set)
    __swig_setmethods__["MoveChargeFromCarbon"] = _ChemScript14.NormOptions_MoveChargeFromCarbon_set
    __swig_getmethods__["MoveChargeFromCarbon"] = _ChemScript14.NormOptions_MoveChargeFromCarbon_get
    if _newclass:MoveChargeFromCarbon = _swig_property(_ChemScript14.NormOptions_MoveChargeFromCarbon_get, _ChemScript14.NormOptions_MoveChargeFromCarbon_set)
    __swig_setmethods__["CleaveIntoSalts"] = _ChemScript14.NormOptions_CleaveIntoSalts_set
    __swig_getmethods__["CleaveIntoSalts"] = _ChemScript14.NormOptions_CleaveIntoSalts_get
    if _newclass:CleaveIntoSalts = _swig_property(_ChemScript14.NormOptions_CleaveIntoSalts_get, _ChemScript14.NormOptions_CleaveIntoSalts_set)
    __swig_setmethods__["MergeMetalSalts"] = _ChemScript14.NormOptions_MergeMetalSalts_set
    __swig_getmethods__["MergeMetalSalts"] = _ChemScript14.NormOptions_MergeMetalSalts_get
    if _newclass:MergeMetalSalts = _swig_property(_ChemScript14.NormOptions_MergeMetalSalts_get, _ChemScript14.NormOptions_MergeMetalSalts_set)
    def ToString(self):
        return _ChemScript14.NormOptions_ToString(self)
    __swig_destroy__ = _ChemScript14.delete_NormOptions
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


NormOptions_swigregister = _ChemScript14.NormOptions_swigregister
NormOptions_swigregister(NormOptions)

class SearchOptionsList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, SearchOptionsList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, SearchOptionsList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.SearchOptionsList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.SearchOptionsList___nonzero__(self)
    def __bool__(self): return _ChemScript14.SearchOptionsList___bool__(self)
    def __len__(self): return _ChemScript14.SearchOptionsList___len__(self)
    def pop(self): return _ChemScript14.SearchOptionsList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.SearchOptionsList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.SearchOptionsList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.SearchOptionsList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.SearchOptionsList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.SearchOptionsList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.SearchOptionsList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.SearchOptionsList_append(self, *args)
    def empty(self): return _ChemScript14.SearchOptionsList_empty(self)
    def size(self): return _ChemScript14.SearchOptionsList_size(self)
    def clear(self): return _ChemScript14.SearchOptionsList_clear(self)
    def swap(self, *args): return _ChemScript14.SearchOptionsList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.SearchOptionsList_get_allocator(self)
    def begin(self): return _ChemScript14.SearchOptionsList_begin(self)
    def end(self): return _ChemScript14.SearchOptionsList_end(self)
    def rbegin(self): return _ChemScript14.SearchOptionsList_rbegin(self)
    def rend(self): return _ChemScript14.SearchOptionsList_rend(self)
    def pop_back(self): return _ChemScript14.SearchOptionsList_pop_back(self)
    def erase(self, *args): return _ChemScript14.SearchOptionsList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_SearchOptionsList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.SearchOptionsList_push_back(self, *args)
    def front(self): return _ChemScript14.SearchOptionsList_front(self)
    def back(self): return _ChemScript14.SearchOptionsList_back(self)
    def assign(self, *args): return _ChemScript14.SearchOptionsList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.SearchOptionsList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.SearchOptionsList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.SearchOptionsList_reserve(self, *args)
    def capacity(self): return _ChemScript14.SearchOptionsList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_SearchOptionsList
    __del__ = lambda self : None;
SearchOptionsList_swigregister = _ChemScript14.SearchOptionsList_swigregister
SearchOptionsList_swigregister(SearchOptionsList)

class SearchOptions(ChemScriptBase):
    """
class of Atom-By-Atom Search Options:

 
Option                    Meanings
----------------------------------------------------------------------------
_3D                      : 3-D search mode.
absHitsRelative          : If set, in non-Identity/Rel.Tet.Ster mode, an
: abs.wedge hits a rel.wedge or hashed.  Does not
: affect other modes.
doubleBondStereo         : Includes the configuration of the double bond.
: The allowed values are: Same or Any.
: Same: match the target structure exactly.
R hits R,Incapable.  S hits S,Incapable.
: Any: match any configuration in the target.
Everything hits everything.
extranFragsOk            : Extraneous frags tolerated in an exact full str
: (mol or rxn) search.
extranFragsOkIfRxn       : Like the previous, but only applies when target is
: rxn.
findChargedHet           : Query's uncharged heteroatoms hits any charge.
findChargedCarbon        : Query's uncharged carbons hits any charge.
findIsotopes             : Unspecified isotopy hits specified isotopy
: (normally the case).
findRadicals             : Unspecified radical hits radical/carbene.
fragsCanOverlap          : If True, different frags in the query can map to
: the same atoms in the target.
fullStruct               : True iff Full str searching; False if SS.
genericsNotGeneric       : Causes query attributes to be compared literally.
: Includes: atom type (A,R,Q,M,L,EDG,Alkyl...); 
: wild/flex charge; var bond order; rxn ctr type.
identityMode             : An exact comparison is done with the search.
ignoreCounterionsInQuery : Strip counterions/co-solvents from query before
: search.
implHMatchesSimple       : An implicit H in the query may not be mapped to
: a charged, isotopic, etc. hydrogen in the target; 
: it matches a simple H only, implicit or explicit.
looseDelocalization      : Query is tweaked so delocalized circles only
: require unsaturated carbons.
plusSigns                : Plus signs in reactions imply adjacent query
: fragments reside in different target fragments.
relativeTetStereo        : T if relative tet stereo search mode.
tautomeric               : Tautomeric search mode.
tetrahedralStereo        : Includes the tetrahedral stereocenter.
: The allowed values are: Same, Identity, Either or Any.
: Same: match the target exactly.
R hits R,Incapable.  S hits S,Incapable.
: Identity: Each type hits only itself.
R hits only R, Unspecified only 
Unspecified, etc.
: Either: match same or opposite configuration at
the center of the target.
R and S both hit R, S, or Incapable.
: Any: match any target. Everything hits everything.
useRxnCenters            : For a reaction query, limit the generated hits
: by matching the reaction centers between the
: query and target.
maxHits                  : Limit the max hits.
timeout                  : Time out for each single search, in milliseconds.

*
    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, SearchOptions, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, SearchOptions, name)
    __repr__ = _swig_repr
    def __init__(self): 
        this = _ChemScript14.new_SearchOptions()
        try: self.this.append(this)
        except: self.this = this
    def List(self): return _ChemScript14.SearchOptions_List(self)
    __swig_setmethods__["_3D"] = _ChemScript14.SearchOptions__3D_set
    __swig_getmethods__["_3D"] = _ChemScript14.SearchOptions__3D_get
    if _newclass:_3D = _swig_property(_ChemScript14.SearchOptions__3D_get, _ChemScript14.SearchOptions__3D_set)
    __swig_setmethods__["absHitsRelative"] = _ChemScript14.SearchOptions_absHitsRelative_set
    __swig_getmethods__["absHitsRelative"] = _ChemScript14.SearchOptions_absHitsRelative_get
    if _newclass:absHitsRelative = _swig_property(_ChemScript14.SearchOptions_absHitsRelative_get, _ChemScript14.SearchOptions_absHitsRelative_set)
    __swig_setmethods__["extranFragsOk"] = _ChemScript14.SearchOptions_extranFragsOk_set
    __swig_getmethods__["extranFragsOk"] = _ChemScript14.SearchOptions_extranFragsOk_get
    if _newclass:extranFragsOk = _swig_property(_ChemScript14.SearchOptions_extranFragsOk_get, _ChemScript14.SearchOptions_extranFragsOk_set)
    __swig_setmethods__["extranFragsOkIfRxn"] = _ChemScript14.SearchOptions_extranFragsOkIfRxn_set
    __swig_getmethods__["extranFragsOkIfRxn"] = _ChemScript14.SearchOptions_extranFragsOkIfRxn_get
    if _newclass:extranFragsOkIfRxn = _swig_property(_ChemScript14.SearchOptions_extranFragsOkIfRxn_get, _ChemScript14.SearchOptions_extranFragsOkIfRxn_set)
    __swig_setmethods__["findChargedHet"] = _ChemScript14.SearchOptions_findChargedHet_set
    __swig_getmethods__["findChargedHet"] = _ChemScript14.SearchOptions_findChargedHet_get
    if _newclass:findChargedHet = _swig_property(_ChemScript14.SearchOptions_findChargedHet_get, _ChemScript14.SearchOptions_findChargedHet_set)
    __swig_setmethods__["findChargedCarbon"] = _ChemScript14.SearchOptions_findChargedCarbon_set
    __swig_getmethods__["findChargedCarbon"] = _ChemScript14.SearchOptions_findChargedCarbon_get
    if _newclass:findChargedCarbon = _swig_property(_ChemScript14.SearchOptions_findChargedCarbon_get, _ChemScript14.SearchOptions_findChargedCarbon_set)
    __swig_setmethods__["findIsotopes"] = _ChemScript14.SearchOptions_findIsotopes_set
    __swig_getmethods__["findIsotopes"] = _ChemScript14.SearchOptions_findIsotopes_get
    if _newclass:findIsotopes = _swig_property(_ChemScript14.SearchOptions_findIsotopes_get, _ChemScript14.SearchOptions_findIsotopes_set)
    __swig_setmethods__["findRadicals"] = _ChemScript14.SearchOptions_findRadicals_set
    __swig_getmethods__["findRadicals"] = _ChemScript14.SearchOptions_findRadicals_get
    if _newclass:findRadicals = _swig_property(_ChemScript14.SearchOptions_findRadicals_get, _ChemScript14.SearchOptions_findRadicals_set)
    __swig_setmethods__["fragsCanOverlap"] = _ChemScript14.SearchOptions_fragsCanOverlap_set
    __swig_getmethods__["fragsCanOverlap"] = _ChemScript14.SearchOptions_fragsCanOverlap_get
    if _newclass:fragsCanOverlap = _swig_property(_ChemScript14.SearchOptions_fragsCanOverlap_get, _ChemScript14.SearchOptions_fragsCanOverlap_set)
    __swig_setmethods__["fullStruct"] = _ChemScript14.SearchOptions_fullStruct_set
    __swig_getmethods__["fullStruct"] = _ChemScript14.SearchOptions_fullStruct_get
    if _newclass:fullStruct = _swig_property(_ChemScript14.SearchOptions_fullStruct_get, _ChemScript14.SearchOptions_fullStruct_set)
    __swig_setmethods__["genericsNotGeneric"] = _ChemScript14.SearchOptions_genericsNotGeneric_set
    __swig_getmethods__["genericsNotGeneric"] = _ChemScript14.SearchOptions_genericsNotGeneric_get
    if _newclass:genericsNotGeneric = _swig_property(_ChemScript14.SearchOptions_genericsNotGeneric_get, _ChemScript14.SearchOptions_genericsNotGeneric_set)
    __swig_setmethods__["identityMode"] = _ChemScript14.SearchOptions_identityMode_set
    __swig_getmethods__["identityMode"] = _ChemScript14.SearchOptions_identityMode_get
    if _newclass:identityMode = _swig_property(_ChemScript14.SearchOptions_identityMode_get, _ChemScript14.SearchOptions_identityMode_set)
    __swig_setmethods__["ignoreCounterionsInQuery"] = _ChemScript14.SearchOptions_ignoreCounterionsInQuery_set
    __swig_getmethods__["ignoreCounterionsInQuery"] = _ChemScript14.SearchOptions_ignoreCounterionsInQuery_get
    if _newclass:ignoreCounterionsInQuery = _swig_property(_ChemScript14.SearchOptions_ignoreCounterionsInQuery_get, _ChemScript14.SearchOptions_ignoreCounterionsInQuery_set)
    __swig_setmethods__["implHMatchesSimple"] = _ChemScript14.SearchOptions_implHMatchesSimple_set
    __swig_getmethods__["implHMatchesSimple"] = _ChemScript14.SearchOptions_implHMatchesSimple_get
    if _newclass:implHMatchesSimple = _swig_property(_ChemScript14.SearchOptions_implHMatchesSimple_get, _ChemScript14.SearchOptions_implHMatchesSimple_set)
    __swig_setmethods__["looseDelocalization"] = _ChemScript14.SearchOptions_looseDelocalization_set
    __swig_getmethods__["looseDelocalization"] = _ChemScript14.SearchOptions_looseDelocalization_get
    if _newclass:looseDelocalization = _swig_property(_ChemScript14.SearchOptions_looseDelocalization_get, _ChemScript14.SearchOptions_looseDelocalization_set)
    __swig_setmethods__["plusSigns"] = _ChemScript14.SearchOptions_plusSigns_set
    __swig_getmethods__["plusSigns"] = _ChemScript14.SearchOptions_plusSigns_get
    if _newclass:plusSigns = _swig_property(_ChemScript14.SearchOptions_plusSigns_get, _ChemScript14.SearchOptions_plusSigns_set)
    __swig_setmethods__["relativeTetStereo"] = _ChemScript14.SearchOptions_relativeTetStereo_set
    __swig_getmethods__["relativeTetStereo"] = _ChemScript14.SearchOptions_relativeTetStereo_get
    if _newclass:relativeTetStereo = _swig_property(_ChemScript14.SearchOptions_relativeTetStereo_get, _ChemScript14.SearchOptions_relativeTetStereo_set)
    __swig_setmethods__["tautomeric"] = _ChemScript14.SearchOptions_tautomeric_set
    __swig_getmethods__["tautomeric"] = _ChemScript14.SearchOptions_tautomeric_get
    if _newclass:tautomeric = _swig_property(_ChemScript14.SearchOptions_tautomeric_get, _ChemScript14.SearchOptions_tautomeric_set)
    __swig_setmethods__["useRxnCenters"] = _ChemScript14.SearchOptions_useRxnCenters_set
    __swig_getmethods__["useRxnCenters"] = _ChemScript14.SearchOptions_useRxnCenters_get
    if _newclass:useRxnCenters = _swig_property(_ChemScript14.SearchOptions_useRxnCenters_get, _ChemScript14.SearchOptions_useRxnCenters_set)
    __swig_setmethods__["maxHits"] = _ChemScript14.SearchOptions_maxHits_set
    __swig_getmethods__["maxHits"] = _ChemScript14.SearchOptions_maxHits_get
    if _newclass:maxHits = _swig_property(_ChemScript14.SearchOptions_maxHits_get, _ChemScript14.SearchOptions_maxHits_set)
    __swig_setmethods__["timeout"] = _ChemScript14.SearchOptions_timeout_set
    __swig_getmethods__["timeout"] = _ChemScript14.SearchOptions_timeout_get
    if _newclass:timeout = _swig_property(_ChemScript14.SearchOptions_timeout_get, _ChemScript14.SearchOptions_timeout_set)
    __swig_destroy__ = _ChemScript14.delete_SearchOptions
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)


SearchOptions_swigregister = _ChemScript14.SearchOptions_swigregister
SearchOptions_swigregister(SearchOptions)

class SearchQueryList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, SearchQueryList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, SearchQueryList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.SearchQueryList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.SearchQueryList___nonzero__(self)
    def __bool__(self): return _ChemScript14.SearchQueryList___bool__(self)
    def __len__(self): return _ChemScript14.SearchQueryList___len__(self)
    def pop(self): return _ChemScript14.SearchQueryList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.SearchQueryList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.SearchQueryList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.SearchQueryList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.SearchQueryList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.SearchQueryList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.SearchQueryList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.SearchQueryList_append(self, *args)
    def empty(self): return _ChemScript14.SearchQueryList_empty(self)
    def size(self): return _ChemScript14.SearchQueryList_size(self)
    def clear(self): return _ChemScript14.SearchQueryList_clear(self)
    def swap(self, *args): return _ChemScript14.SearchQueryList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.SearchQueryList_get_allocator(self)
    def begin(self): return _ChemScript14.SearchQueryList_begin(self)
    def end(self): return _ChemScript14.SearchQueryList_end(self)
    def rbegin(self): return _ChemScript14.SearchQueryList_rbegin(self)
    def rend(self): return _ChemScript14.SearchQueryList_rend(self)
    def pop_back(self): return _ChemScript14.SearchQueryList_pop_back(self)
    def erase(self, *args): return _ChemScript14.SearchQueryList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_SearchQueryList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.SearchQueryList_push_back(self, *args)
    def front(self): return _ChemScript14.SearchQueryList_front(self)
    def back(self): return _ChemScript14.SearchQueryList_back(self)
    def assign(self, *args): return _ChemScript14.SearchQueryList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.SearchQueryList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.SearchQueryList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.SearchQueryList_reserve(self, *args)
    def capacity(self): return _ChemScript14.SearchQueryList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_SearchQueryList
    __del__ = lambda self : None;
SearchQueryList_swigregister = _ChemScript14.SearchQueryList_swigregister
SearchQueryList_swigregister(SearchQueryList)

class SearchQuery(ChemScriptBase):
    """
class of SearchQuery


List all atom-by-atom map from this StructureData to "target" StructureData.
If any hit found, it returns true, else return false.
Python Example:
>>> large = StructureData.LoadData('C1CCCCC1C')
>>> small = StructureData.LoadData('C1CCCCC1')
>>> searchquery = small.CreateSearchQuery();
>>> if searchquery.AtomByAtomSearch(large, SearchQuery.kSearchAtomByAtomMapAll):
...     for i in range(searchquery.GetAtomMapCount()):
...         print "map:", i
...         map = searchquery.GetAtomByAtomMap(i)
...         for aa in map.keys():
...             r = aa.Name + ' -> ' + map[aa].Name
...             print(r)


    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, SearchQuery, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, SearchQuery, name)
    __repr__ = _swig_repr
    kSearchAtomByAtomMapNone = _ChemScript14.SearchQuery_kSearchAtomByAtomMapNone
    kSearchAtomByAtomMapOne = _ChemScript14.SearchQuery_kSearchAtomByAtomMapOne
    kSearchAtomByAtomMapAll = _ChemScript14.SearchQuery_kSearchAtomByAtomMapAll
    def __init__(self, mol, opt = None): 
        this = _ChemScript14.new_SearchQuery(mol, opt)
        try: self.this.append(this)
        except: self.this = this
    def AtomByAtomSearch(self, target, needAtomMap = kSearchAtomByAtomMapNone):
        """
AtomByAtomSearch


        """
        return _ChemScript14.SearchQuery_AtomByAtomSearch(self, target, needAtomMap)
    def GetAtomByAtomMap(self, i):
        """
Get Atom By AtomMap with the Atom No


        """
        return _ChemScript14.SearchQuery_GetAtomByAtomMap(self, i)
    __swig_getmethods__["AtomMapCount"] = _ChemScript14.SearchQuery_AtomMapCount_get
    if _newclass:AtomMapCount = _swig_property(_ChemScript14.SearchQuery_AtomMapCount_get)
    __swig_destroy__ = _ChemScript14.delete_SearchQuery
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


SearchQuery_swigregister = _ChemScript14.SearchQuery_swigregister
SearchQuery_swigregister(SearchQuery)

class RDFileReaderList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, RDFileReaderList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, RDFileReaderList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.RDFileReaderList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.RDFileReaderList___nonzero__(self)
    def __bool__(self): return _ChemScript14.RDFileReaderList___bool__(self)
    def __len__(self): return _ChemScript14.RDFileReaderList___len__(self)
    def pop(self): return _ChemScript14.RDFileReaderList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.RDFileReaderList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.RDFileReaderList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.RDFileReaderList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.RDFileReaderList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.RDFileReaderList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.RDFileReaderList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.RDFileReaderList_append(self, *args)
    def empty(self): return _ChemScript14.RDFileReaderList_empty(self)
    def size(self): return _ChemScript14.RDFileReaderList_size(self)
    def clear(self): return _ChemScript14.RDFileReaderList_clear(self)
    def swap(self, *args): return _ChemScript14.RDFileReaderList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.RDFileReaderList_get_allocator(self)
    def begin(self): return _ChemScript14.RDFileReaderList_begin(self)
    def end(self): return _ChemScript14.RDFileReaderList_end(self)
    def rbegin(self): return _ChemScript14.RDFileReaderList_rbegin(self)
    def rend(self): return _ChemScript14.RDFileReaderList_rend(self)
    def pop_back(self): return _ChemScript14.RDFileReaderList_pop_back(self)
    def erase(self, *args): return _ChemScript14.RDFileReaderList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_RDFileReaderList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.RDFileReaderList_push_back(self, *args)
    def front(self): return _ChemScript14.RDFileReaderList_front(self)
    def back(self): return _ChemScript14.RDFileReaderList_back(self)
    def assign(self, *args): return _ChemScript14.RDFileReaderList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.RDFileReaderList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.RDFileReaderList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.RDFileReaderList_reserve(self, *args)
    def capacity(self): return _ChemScript14.RDFileReaderList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_RDFileReaderList
    __del__ = lambda self : None;
RDFileReaderList_swigregister = _ChemScript14.RDFileReaderList_swigregister
RDFileReaderList_swigregister(RDFileReaderList)

class RDFileReader(ChemScriptBase):
    """
class for reading MDL SD file
    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, RDFileReader, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, RDFileReader, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    __swig_getmethods__["OpenFile"] = lambda x: _ChemScript14.RDFileReader_OpenFile
    
    @staticmethod
    def OpenFile(filename):
        """
Entry of creating RDFileReader.  Usage:
Python Example:
>>> rd = RDFileReader.OpenFile('c:/my.sdf')
>>> if rd = None: pass
>>> rd.ResetReading()
>>> m = rd.ReadNext()
>>> while not rd.Eof():
...     m = rd.ReadNext()
...     if m == None:
...         print("Jump to the next structure.")
...         continue
...     print(m.Formula())
...     items = m.GetDataItems()
...     for item in items.keys():
...         print(item, '->', m[item])
...     m = rd.ReadNext()


        """
        return _ChemScript14.RDFileReader_OpenFile(filename)
            
    def Eof(self):
        """
Check if reaching the end of the file


        """
        return _ChemScript14.RDFileReader_Eof(self)
    def ReadNext(self):
        """
Read next ReactionData


        """
        return _ChemScript14.RDFileReader_ReadNext(self)
    def Current(self):
        """
get the structure of the last ReadNext()


        """
        return _ChemScript14.RDFileReader_Current(self)
    def ResetReading(self):
        """
Reset reading, so next ReadNext() call will get the first ReactionData


        """
        return _ChemScript14.RDFileReader_ResetReading(self)
    def Close(self):
        """
Close


        """
        return _ChemScript14.RDFileReader_Close(self)
    __swig_getmethods__["Count"] = _ChemScript14.RDFileReader_Count_get
    if _newclass:Count = _swig_property(_ChemScript14.RDFileReader_Count_get, doc=
        """
Get the number of reactions pending of reading in the file


        """
    )
    __swig_getmethods__["PercentComplete"] = _ChemScript14.RDFileReader_PercentComplete_get
    if _newclass:PercentComplete = _swig_property(_ChemScript14.RDFileReader_PercentComplete_get, doc=
        """
Get the read percentage of the file


        """
    )
    __swig_getmethods__["NumberOfRecordsRead"] = _ChemScript14.RDFileReader_NumberOfRecordsRead_get
    if _newclass:NumberOfRecordsRead = _swig_property(_ChemScript14.RDFileReader_NumberOfRecordsRead_get, doc=
        """
Get the number of reactions read from the file


        """
    )
    __swig_destroy__ = _ChemScript14.delete_RDFileReader
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)


RDFileReader_swigregister = _ChemScript14.RDFileReader_swigregister
RDFileReader_swigregister(RDFileReader)


RDFileReader_OpenFile = _ChemScript14.RDFileReader_OpenFile

class SDFileWriterList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, SDFileWriterList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, SDFileWriterList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.SDFileWriterList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.SDFileWriterList___nonzero__(self)
    def __bool__(self): return _ChemScript14.SDFileWriterList___bool__(self)
    def __len__(self): return _ChemScript14.SDFileWriterList___len__(self)
    def pop(self): return _ChemScript14.SDFileWriterList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.SDFileWriterList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.SDFileWriterList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.SDFileWriterList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.SDFileWriterList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.SDFileWriterList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.SDFileWriterList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.SDFileWriterList_append(self, *args)
    def empty(self): return _ChemScript14.SDFileWriterList_empty(self)
    def size(self): return _ChemScript14.SDFileWriterList_size(self)
    def clear(self): return _ChemScript14.SDFileWriterList_clear(self)
    def swap(self, *args): return _ChemScript14.SDFileWriterList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.SDFileWriterList_get_allocator(self)
    def begin(self): return _ChemScript14.SDFileWriterList_begin(self)
    def end(self): return _ChemScript14.SDFileWriterList_end(self)
    def rbegin(self): return _ChemScript14.SDFileWriterList_rbegin(self)
    def rend(self): return _ChemScript14.SDFileWriterList_rend(self)
    def pop_back(self): return _ChemScript14.SDFileWriterList_pop_back(self)
    def erase(self, *args): return _ChemScript14.SDFileWriterList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_SDFileWriterList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.SDFileWriterList_push_back(self, *args)
    def front(self): return _ChemScript14.SDFileWriterList_front(self)
    def back(self): return _ChemScript14.SDFileWriterList_back(self)
    def assign(self, *args): return _ChemScript14.SDFileWriterList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.SDFileWriterList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.SDFileWriterList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.SDFileWriterList_reserve(self, *args)
    def capacity(self): return _ChemScript14.SDFileWriterList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_SDFileWriterList
    __del__ = lambda self : None;
SDFileWriterList_swigregister = _ChemScript14.SDFileWriterList_swigregister
SDFileWriterList_swigregister(SDFileWriterList)

class SDFileWriter(ChemScriptBase):
    """
SDFileWriter class


Users cannot create SDFileWriter objects directly.  Use SDFileWriter.OpenFile()
to create an SDFileWriter.


class for writing MDL SD file
    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, SDFileWriter, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, SDFileWriter, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    __swig_getmethods__["OpenFile"] = lambda x: _ChemScript14.SDFileWriter_OpenFile
    
    @staticmethod
    def OpenFile(filename, mode = Create, mimeType = ""):
        """
Constructor of SDFileWriter.
You can explicitly set mode to Append if you want to append to existing file.
It is set to Create by default.
Python Example:
>>> sd = SDFileWriter.OpenFile('c:/my.sdf', OverWrite, "chemical/x-mdl-molfile-v3000")
>>> m = StructureData.LoadData('CCC')
>>> m['atomcount'] = '3'
>>> sd.WriteStructure(m)
>>> m = StructureData.LoadData('C1CCCCC1')
>>> m['atomcount'] = '6'
>>> sd.WriteStructure(m)
>>> sd.Close()


        """
        return _ChemScript14.SDFileWriter_OpenFile(filename, mode, mimeType)
            
    def WriteStructure(self, structureData, mimeType = ""):
        """
Write a Structure
mimeType - default value is empty string which will write structure into v2000 format
This mimeType will overwrite the OpenFile option.
Python Example:
>>> sd = SDFileWriter.OpenFile('c:/my.sdf', False)
>>> m = StructureData.LoadData('CCC')
>>> m.SetDataItem('atomcount', '3')
>>> sd.WriteStructure(m,  "chemical/x-mdl-molfile-v3000")
>>> sd.Close()


        """
        return _ChemScript14.SDFileWriter_WriteStructure(self, structureData, mimeType)
    def WriteStructures(self, molecules, mimeType = ""):
        """
Write many Structures in one time.
Return the number of molecules (StructureData) written.
mimeType - default value is empty string which will write structure into v2000 format
This mimeType will overwrite the OpenFile option.
Python Example:
>>> sd = SDFileWriter.OpenFile('c:/my.sdf', False)
>>> m1 = StructureData.LoadData('CCC')
>>> m.SetDataItem('atomcount', '3')
>>> m2 = StructureData.LoadData('CCCCC')
>>> m.SetDataItem('atomcount', '5')
>>> molecules = [m1, m2]
>>> sd.WriteStructures(molecules, "chemical/x-mdl-molfile-v3000")
>>> sd.Close()


        """
        return _ChemScript14.SDFileWriter_WriteStructures(self, molecules, mimeType)
    def Close(self):
        """
Close


        """
        return _ChemScript14.SDFileWriter_Close(self)
    __swig_destroy__ = _ChemScript14.delete_SDFileWriter
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)


SDFileWriter_swigregister = _ChemScript14.SDFileWriter_swigregister
SDFileWriter_swigregister(SDFileWriter)


SDFileWriter_OpenFile = _ChemScript14.SDFileWriter_OpenFile

class RDFileWriterList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, RDFileWriterList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, RDFileWriterList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.RDFileWriterList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.RDFileWriterList___nonzero__(self)
    def __bool__(self): return _ChemScript14.RDFileWriterList___bool__(self)
    def __len__(self): return _ChemScript14.RDFileWriterList___len__(self)
    def pop(self): return _ChemScript14.RDFileWriterList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.RDFileWriterList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.RDFileWriterList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.RDFileWriterList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.RDFileWriterList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.RDFileWriterList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.RDFileWriterList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.RDFileWriterList_append(self, *args)
    def empty(self): return _ChemScript14.RDFileWriterList_empty(self)
    def size(self): return _ChemScript14.RDFileWriterList_size(self)
    def clear(self): return _ChemScript14.RDFileWriterList_clear(self)
    def swap(self, *args): return _ChemScript14.RDFileWriterList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.RDFileWriterList_get_allocator(self)
    def begin(self): return _ChemScript14.RDFileWriterList_begin(self)
    def end(self): return _ChemScript14.RDFileWriterList_end(self)
    def rbegin(self): return _ChemScript14.RDFileWriterList_rbegin(self)
    def rend(self): return _ChemScript14.RDFileWriterList_rend(self)
    def pop_back(self): return _ChemScript14.RDFileWriterList_pop_back(self)
    def erase(self, *args): return _ChemScript14.RDFileWriterList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_RDFileWriterList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.RDFileWriterList_push_back(self, *args)
    def front(self): return _ChemScript14.RDFileWriterList_front(self)
    def back(self): return _ChemScript14.RDFileWriterList_back(self)
    def assign(self, *args): return _ChemScript14.RDFileWriterList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.RDFileWriterList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.RDFileWriterList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.RDFileWriterList_reserve(self, *args)
    def capacity(self): return _ChemScript14.RDFileWriterList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_RDFileWriterList
    __del__ = lambda self : None;
RDFileWriterList_swigregister = _ChemScript14.RDFileWriterList_swigregister
RDFileWriterList_swigregister(RDFileWriterList)

class RDFileWriter(ChemScriptBase):
    """
SDFileWriter class


Users cannot create RDFileWriter objects directly.  Use RDFileWriter.OpenFile()
to create an RDFileWriter.


class for writing MDL RD file
    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, RDFileWriter, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, RDFileWriter, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    __swig_getmethods__["OpenFile"] = lambda x: _ChemScript14.RDFileWriter_OpenFile
    
    @staticmethod
    def OpenFile(filename, mode = Create):
        """
Entry of RDFileWriter. 
You can explicitly set mode to Append if you want to append to existing file.
It is set to Create by default.
Python Example:
>>> rd = RDFileWriter.OpenFile('c:/my.rdf', OverWrite)
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> rd.WriteReaction(r)
>>> rd.Close()


        """
        return _ChemScript14.RDFileWriter_OpenFile(filename, mode)
            
    def WriteReaction(self, reactionData, mimeType = "chemical/x-mdl-rxn"):
        """
Write a Reaction
Python Example:
>>> rd = RDFileWriter.OpenFile('c:/my.rdf', False)
>>> r = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> rd.WriteReaction(r)
>>> rd.Close()


        """
        return _ChemScript14.RDFileWriter_WriteReaction(self, reactionData, mimeType)
    def WriteReactions(self, reactions, mimeType = "chemical/x-mdl-rxn"):
        """
Write many Reactions in one time
Return the number of reactions (ReactionData) written.
Python Example:
>>> rd = RDFileWriter.OpenFile('c:/my.rdf', False)
>>> r1 = ReactionData.LoadData('CCC=C>>CCC.CN')
>>> r2 = ReactionData.LoadData('C1CCC=CC1>>CCCCCC')
>>> reactions = [r1, r2]
>>> rd.WriteReactions(reactions)
>>> rd.Close()


        """
        return _ChemScript14.RDFileWriter_WriteReactions(self, reactions, mimeType)
    def Close(self):
        """
Close


        """
        return _ChemScript14.RDFileWriter_Close(self)
    __swig_destroy__ = _ChemScript14.delete_RDFileWriter
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)


RDFileWriter_swigregister = _ChemScript14.RDFileWriter_swigregister
RDFileWriter_swigregister(RDFileWriter)


RDFileWriter_OpenFile = _ChemScript14.RDFileWriter_OpenFile

class CombiChemList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CombiChemList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CombiChemList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.CombiChemList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.CombiChemList___nonzero__(self)
    def __bool__(self): return _ChemScript14.CombiChemList___bool__(self)
    def __len__(self): return _ChemScript14.CombiChemList___len__(self)
    def pop(self): return _ChemScript14.CombiChemList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.CombiChemList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.CombiChemList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.CombiChemList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.CombiChemList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.CombiChemList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.CombiChemList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.CombiChemList_append(self, *args)
    def empty(self): return _ChemScript14.CombiChemList_empty(self)
    def size(self): return _ChemScript14.CombiChemList_size(self)
    def clear(self): return _ChemScript14.CombiChemList_clear(self)
    def swap(self, *args): return _ChemScript14.CombiChemList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.CombiChemList_get_allocator(self)
    def begin(self): return _ChemScript14.CombiChemList_begin(self)
    def end(self): return _ChemScript14.CombiChemList_end(self)
    def rbegin(self): return _ChemScript14.CombiChemList_rbegin(self)
    def rend(self): return _ChemScript14.CombiChemList_rend(self)
    def pop_back(self): return _ChemScript14.CombiChemList_pop_back(self)
    def erase(self, *args): return _ChemScript14.CombiChemList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_CombiChemList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.CombiChemList_push_back(self, *args)
    def front(self): return _ChemScript14.CombiChemList_front(self)
    def back(self): return _ChemScript14.CombiChemList_back(self)
    def assign(self, *args): return _ChemScript14.CombiChemList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.CombiChemList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.CombiChemList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.CombiChemList_reserve(self, *args)
    def capacity(self): return _ChemScript14.CombiChemList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_CombiChemList
    __del__ = lambda self : None;
CombiChemList_swigregister = _ChemScript14.CombiChemList_swigregister
CombiChemList_swigregister(CombiChemList)

class CombiChem(ChemScriptBase):
    """
CombiChem is a utility class that provides functionality for
combinatorial chemisty enumeration.  
A generic reaction is provided for the enumeration during construction.  
Candidate structures can be associated with each of the reactants, and
the results can then be enumerated using this class.
Python Example:
Usage 1:
>>> r = ReactionData.LoadFile('genericRxn.cdx')
>>> combi = CombiChem(r)
>>> m = StructureData.LoadFile('m.cdx')
>>> combi.SetCandidate(m, 0)
>>> combi.BeginEnum()
>>> s = combi.EnumNext()
Usage 2:
>>> r = ReactionData.LoadFile('genericRxn.cdx')
>>> combi = CombiChem(r)
>>> combi.SetCandidates(molArray, 0)
>>> resultArray = combi.Permutations()


    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, CombiChem, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, CombiChem, name)
    __repr__ = _swig_repr
    def __init__(self, reaction): 
        this = _ChemScript14.new_CombiChem(reaction)
        try: self.this.append(this)
        except: self.this = this
    def GenericReaction(self):
        """
Get the generic reaction.


        """
        return _ChemScript14.CombiChem_GenericReaction(self)
    def GenericComponents(self):
        """
Get a list of the indices of all the components of the reaction
for which candidates may be set.


        """
        return _ChemScript14.CombiChem_GenericComponents(self)
    def SetCandidate(self, structure, reactantIndex):
        """
Add another candidate structure to be associated with the specified
generic reactant.


        """
        return _ChemScript14.CombiChem_SetCandidate(self, structure, reactantIndex)
    def SetCandidates(self, structures, reactantIndex):
        """
Add a list of candidate structures to be associated with the specified
generic reactants.


        """
        return _ChemScript14.CombiChem_SetCandidates(self, structures, reactantIndex)
    def NumberOfCandidates(self, componentIndex):
        """
Get the number of candidates for a given component.


        """
        return _ChemScript14.CombiChem_NumberOfCandidates(self, componentIndex)
    def ReactiveOrientations(self, componentIndex, candidateIndex):
        """
Get reactive orientations for a given candidate for a given component.


        """
        return _ChemScript14.CombiChem_ReactiveOrientations(self, componentIndex, candidateIndex)
    def DeleteReactiveOrientation(self, componentIndex, candidateIndex, orientationIndex):
        """
Remove given reactive orientation from consideration in the enumeration.


        """
        return _ChemScript14.CombiChem_DeleteReactiveOrientation(self, componentIndex, candidateIndex, orientationIndex)
    def Permutations(self):
        """
Get a list of the all of the reaction permutations.


        """
        return _ChemScript14.CombiChem_Permutations(self)
    def PermutationCandidateIndices(self, permutationIndex):
        """
Get the indices of the candidates contributing to the given reaction permutation.
This array parallels GenericComponents.


        """
        return _ChemScript14.CombiChem_PermutationCandidateIndices(self, permutationIndex)
    def BeginEnum(self):
        """
Begin the manual enumeration process - this should be followed by
calls to EnumNext() to enumerate the perumatations one by one.


        """
        return _ChemScript14.CombiChem_BeginEnum(self)
    def EnumNext(self):
        """
Enumerate the next permutation during the manual enumeration process.
This returns null when the enumeration is finished.
BeginEnum() must be called before the first call of EnumNext().


        """
        return _ChemScript14.CombiChem_EnumNext(self)
    __swig_getmethods__["NumberOfPermutations"] = _ChemScript14.CombiChem_NumberOfPermutations_get
    if _newclass:NumberOfPermutations = _swig_property(_ChemScript14.CombiChem_NumberOfPermutations_get, doc=
        """
Get the number of reaction permutations.
NumberOfPermutations is READONLY.


        """
    )
    __swig_destroy__ = _ChemScript14.delete_CombiChem
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, self.ToString(),)


CombiChem_swigregister = _ChemScript14.CombiChem_swigregister
CombiChem_swigregister(CombiChem)

class LargestCommonSubstructureList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, LargestCommonSubstructureList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, LargestCommonSubstructureList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.LargestCommonSubstructureList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.LargestCommonSubstructureList___nonzero__(self)
    def __bool__(self): return _ChemScript14.LargestCommonSubstructureList___bool__(self)
    def __len__(self): return _ChemScript14.LargestCommonSubstructureList___len__(self)
    def pop(self): return _ChemScript14.LargestCommonSubstructureList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.LargestCommonSubstructureList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.LargestCommonSubstructureList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.LargestCommonSubstructureList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.LargestCommonSubstructureList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.LargestCommonSubstructureList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.LargestCommonSubstructureList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.LargestCommonSubstructureList_append(self, *args)
    def empty(self): return _ChemScript14.LargestCommonSubstructureList_empty(self)
    def size(self): return _ChemScript14.LargestCommonSubstructureList_size(self)
    def clear(self): return _ChemScript14.LargestCommonSubstructureList_clear(self)
    def swap(self, *args): return _ChemScript14.LargestCommonSubstructureList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.LargestCommonSubstructureList_get_allocator(self)
    def begin(self): return _ChemScript14.LargestCommonSubstructureList_begin(self)
    def end(self): return _ChemScript14.LargestCommonSubstructureList_end(self)
    def rbegin(self): return _ChemScript14.LargestCommonSubstructureList_rbegin(self)
    def rend(self): return _ChemScript14.LargestCommonSubstructureList_rend(self)
    def pop_back(self): return _ChemScript14.LargestCommonSubstructureList_pop_back(self)
    def erase(self, *args): return _ChemScript14.LargestCommonSubstructureList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_LargestCommonSubstructureList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.LargestCommonSubstructureList_push_back(self, *args)
    def front(self): return _ChemScript14.LargestCommonSubstructureList_front(self)
    def back(self): return _ChemScript14.LargestCommonSubstructureList_back(self)
    def assign(self, *args): return _ChemScript14.LargestCommonSubstructureList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.LargestCommonSubstructureList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.LargestCommonSubstructureList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.LargestCommonSubstructureList_reserve(self, *args)
    def capacity(self): return _ChemScript14.LargestCommonSubstructureList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_LargestCommonSubstructureList
    __del__ = lambda self : None;
LargestCommonSubstructureList_swigregister = _ChemScript14.LargestCommonSubstructureList_swigregister
LargestCommonSubstructureList_swigregister(LargestCommonSubstructureList)

class LargestCommonSubstructure(ChemScriptBase):
    """
Class of most common structure


You cannot create LargestCommonSubstructure object directly.  
LargestCommonSubstructure.Compute(...) returns an LargestCommonSubstructure object


    """
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, LargestCommonSubstructure, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, LargestCommonSubstructure, name)
    def __init__(self, *args, **kwargs): raise AttributeError("No constructor defined")
    __repr__ = _swig_repr
    def CommonSubstructure(self):
        """
Get most common structure as a separated StructureData


        """
        return _ChemScript14.LargestCommonSubstructure_CommonSubstructure(self)
    def AtomMapM1(self):
        """
Get StructureData's atom dict to structure1


        """
        return _ChemScript14.LargestCommonSubstructure_AtomMapM1(self)
    def AtomMapM2(self):
        """
Get StructureData's atom dict to structure2


        """
        return _ChemScript14.LargestCommonSubstructure_AtomMapM2(self)
    def BondMapM1(self):
        """
Get StructureData's bond dict to structure1


        """
        return _ChemScript14.LargestCommonSubstructure_BondMapM1(self)
    def BondMapM2(self):
        """
Get StructureData's bond dict to structure2


        """
        return _ChemScript14.LargestCommonSubstructure_BondMapM2(self)
    __swig_getmethods__["Compute"] = lambda x: _ChemScript14.LargestCommonSubstructure_Compute
    
    @staticmethod
    def Compute(structure1, structure2, timeout = 0):
        """
Find the maximum common sub-graph between structure1 and structure2
Python Example:
>>> structure1 = StructureData.LoadData("C1(C)CCCC1CCO")
>>> structure2 = StructureData.LoadData("C1CCCC1C")
>>> common = LargestCommonSubstructure.Compute(structure1, structure2)
>>> atommap1 = common.AtomMapM1()
>>> bondmap1 = common.BondMapM1()
>>> atommap2 = common.AtomMapM2()
>>> bondmap2 = common.BondMapM2()
>>> for a in atommap1.keys():
...     r = a.Name + '->' + atommap1[a].Name + '->' + atommap2[a].Name
...     print(r)
>>> for b in bondmap1.keys():
...     r = b.Name + '->' + bondmap1[b].Name + '->' + bondmap2[b].Name
...     print(r)


        """
        return _ChemScript14.LargestCommonSubstructure_Compute(structure1, structure2, timeout)
            
    __swig_destroy__ = _ChemScript14.delete_LargestCommonSubstructure
    __del__ = lambda self : None;
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__,)


LargestCommonSubstructure_swigregister = _ChemScript14.LargestCommonSubstructure_swigregister
LargestCommonSubstructure_swigregister(LargestCommonSubstructure)


LargestCommonSubstructure_Compute = _ChemScript14.LargestCommonSubstructure_Compute

class EnvironmentList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, EnvironmentList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, EnvironmentList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.EnvironmentList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.EnvironmentList___nonzero__(self)
    def __bool__(self): return _ChemScript14.EnvironmentList___bool__(self)
    def __len__(self): return _ChemScript14.EnvironmentList___len__(self)
    def pop(self): return _ChemScript14.EnvironmentList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.EnvironmentList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.EnvironmentList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.EnvironmentList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.EnvironmentList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.EnvironmentList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.EnvironmentList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.EnvironmentList_append(self, *args)
    def empty(self): return _ChemScript14.EnvironmentList_empty(self)
    def size(self): return _ChemScript14.EnvironmentList_size(self)
    def clear(self): return _ChemScript14.EnvironmentList_clear(self)
    def swap(self, *args): return _ChemScript14.EnvironmentList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.EnvironmentList_get_allocator(self)
    def begin(self): return _ChemScript14.EnvironmentList_begin(self)
    def end(self): return _ChemScript14.EnvironmentList_end(self)
    def rbegin(self): return _ChemScript14.EnvironmentList_rbegin(self)
    def rend(self): return _ChemScript14.EnvironmentList_rend(self)
    def pop_back(self): return _ChemScript14.EnvironmentList_pop_back(self)
    def erase(self, *args): return _ChemScript14.EnvironmentList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_EnvironmentList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.EnvironmentList_push_back(self, *args)
    def front(self): return _ChemScript14.EnvironmentList_front(self)
    def back(self): return _ChemScript14.EnvironmentList_back(self)
    def assign(self, *args): return _ChemScript14.EnvironmentList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.EnvironmentList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.EnvironmentList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.EnvironmentList_reserve(self, *args)
    def capacity(self): return _ChemScript14.EnvironmentList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_EnvironmentList
    __del__ = lambda self : None;
EnvironmentList_swigregister = _ChemScript14.EnvironmentList_swigregister
EnvironmentList_swigregister(EnvironmentList)

class NameToStructureOptions(_object):
    """
Class of NameToStructureOptions. 


This class is used to set the options which are used by NameToStruct, such as "stop words" flag
Python Example:
>>> Environment.GetNameToStructureOptions().SetTreatingStopwords(False)


    """
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, NameToStructureOptions, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, NameToStructureOptions, name)
    __repr__ = _swig_repr
    def __init__(self): 
        this = _ChemScript14.new_NameToStructureOptions()
        try: self.this.append(this)
        except: self.this = this
    def GetTreatingStopwords(self):
        return _ChemScript14.NameToStructureOptions_GetTreatingStopwords(self)
    def SetTreatingStopwords(self, treatingStopwords):
        return _ChemScript14.NameToStructureOptions_SetTreatingStopwords(self, treatingStopwords)
    __swig_destroy__ = _ChemScript14.delete_NameToStructureOptions
    __del__ = lambda self : None;
NameToStructureOptions_swigregister = _ChemScript14.NameToStructureOptions_swigregister
NameToStructureOptions_swigregister(NameToStructureOptions)

class Environment(ChemScriptBase):
    __swig_setmethods__ = {}
    for _s in [ChemScriptBase]: __swig_setmethods__.update(getattr(_s,'__swig_setmethods__',{}))
    __setattr__ = lambda self, name, value: _swig_setattr(self, Environment, name, value)
    __swig_getmethods__ = {}
    for _s in [ChemScriptBase]: __swig_getmethods__.update(getattr(_s,'__swig_getmethods__',{}))
    __getattr__ = lambda self, name: _swig_getattr(self, Environment, name)
    __repr__ = _swig_repr
    __swig_getmethods__["SetThrowExceptions"] = lambda x: _ChemScript14.Environment_SetThrowExceptions
    
    @staticmethod
    def SetThrowExceptions(f):
        """
Python example:
>>> Environment.SetThrowExceptions(True)
>>> try:
...     m = StructureData()
...     m.ReadFile('notExistingFile.ext')
... except Exception, e:
...     print(e)

*
        """
        return _ChemScript14.Environment_SetThrowExceptions(f)
            
    __swig_getmethods__["GetThrowExceptions"] = lambda x: _ChemScript14.Environment_GetThrowExceptions
    
    @staticmethod
    def GetThrowExceptions():
        """
Python example:
>>> Environment.GetThrowExceptions()

*
        """
        return _ChemScript14.Environment_GetThrowExceptions()
            
    __swig_getmethods__["SetVerbosity"] = lambda x: _ChemScript14.Environment_SetVerbosity
    
    @staticmethod
    def SetVerbosity(f):
        """
Python example:
>>> Environment.SetVerbosity(True)

*
        """
        return _ChemScript14.Environment_SetVerbosity(f)
            
    __swig_getmethods__["GetVerbosity"] = lambda x: _ChemScript14.Environment_GetVerbosity
    
    @staticmethod
    def GetVerbosity():
        """
Python example:
>>> Environment.GetVerbosity()

*
        """
        return _ChemScript14.Environment_GetVerbosity()
            
    __swig_getmethods__["SetC3dItemsFolder"] = lambda x: _ChemScript14.Environment_SetC3dItemsFolder
    
    @staticmethod
    def SetC3dItemsFolder(path):
        """
Set "C3D Items" folder path.  2D->3D and MM2 need use this

        """
        return _ChemScript14.Environment_SetC3dItemsFolder(path)
            
    __swig_getmethods__["SetN2SDataFile"] = lambda x: _ChemScript14.Environment_SetN2SDataFile
    
    @staticmethod
    def SetN2SDataFile(datafile):
        """
Set NameToStructure data file path

        """
        return _ChemScript14.Environment_SetN2SDataFile(datafile)
            
    __swig_getmethods__["SetS2NDataFile"] = lambda x: _ChemScript14.Environment_SetS2NDataFile
    
    @staticmethod
    def SetS2NDataFile(datafile):
        """
Set StructureToName data file path 

        """
        return _ChemScript14.Environment_SetS2NDataFile(datafile)
            
    __swig_getmethods__["Activate"] = lambda x: _ChemScript14.Environment_Activate
    
    @staticmethod
    def Activate():
        """
Activate ChemScript

        """
        return _ChemScript14.Environment_Activate()
            
    __swig_getmethods__["SetDisableInterpretationOfPerspectiveStereochemistry"] = lambda x: _ChemScript14.Environment_SetDisableInterpretationOfPerspectiveStereochemistry
    
    @staticmethod
    def SetDisableInterpretationOfPerspectiveStereochemistry(disable):
        """
When TRUE, this property disables the interpretation of perspective in 2D diagrams as an indicator of 3D
stereochemistry. The default value is FALSE; i.e. perspective in a 2D diagram by default will be interpreted as an
indicator of 3D stereochemistry.


        """
        return _ChemScript14.Environment_SetDisableInterpretationOfPerspectiveStereochemistry(disable)
            
    __swig_getmethods__["GetDisableInterpretationOfPerspectiveStereochemistry"] = lambda x: _ChemScript14.Environment_GetDisableInterpretationOfPerspectiveStereochemistry
    
    @staticmethod
    def GetDisableInterpretationOfPerspectiveStereochemistry():
        """
When TRUE, this property disables the interpretation of perspective in 2D diagrams as an indicator of 3D
stereochemistry. The default value is FALSE; i.e. perspective in a 2D diagram by default will be interpreted as an
indicator of 3D stereochemistry.


        """
        return _ChemScript14.Environment_GetDisableInterpretationOfPerspectiveStereochemistry()
            
    __swig_getmethods__["Version"] = lambda x: _ChemScript14.Environment_Version
    
    @staticmethod
    def Version():
        """
Get ChemScript version string

        """
        return _ChemScript14.Environment_Version()
            
    __swig_getmethods__["SetNameToStructureOptions"] = lambda x: _ChemScript14.Environment_SetNameToStructureOptions
    
    @staticmethod
    def SetNameToStructureOptions(opt):
        """
Set name to structure options
Default is true

        """
        return _ChemScript14.Environment_SetNameToStructureOptions(opt)
            
    __swig_getmethods__["GetNameToStructureOptions"] = lambda x: _ChemScript14.Environment_GetNameToStructureOptions
    
    @staticmethod
    def GetNameToStructureOptions():
        """
Get name to structure options

        """
        return _ChemScript14.Environment_GetNameToStructureOptions()
            
    __swig_destroy__ = _ChemScript14.delete_Environment
    __del__ = lambda self : None;
    def __init__(self): 
        this = _ChemScript14.new_Environment()
        try: self.this.append(this)
        except: self.this = this
    def __repr__(self):
        return "<%s.%s>" % (self.__class__.__module__, self.__class__.__name__)


Environment_swigregister = _ChemScript14.Environment_swigregister
Environment_swigregister(Environment)


Environment_SetThrowExceptions = _ChemScript14.Environment_SetThrowExceptions


Environment_GetThrowExceptions = _ChemScript14.Environment_GetThrowExceptions


Environment_SetVerbosity = _ChemScript14.Environment_SetVerbosity


Environment_GetVerbosity = _ChemScript14.Environment_GetVerbosity


Environment_SetC3dItemsFolder = _ChemScript14.Environment_SetC3dItemsFolder


Environment_SetN2SDataFile = _ChemScript14.Environment_SetN2SDataFile


Environment_SetS2NDataFile = _ChemScript14.Environment_SetS2NDataFile


Environment_Activate = _ChemScript14.Environment_Activate


Environment_SetDisableInterpretationOfPerspectiveStereochemistry = _ChemScript14.Environment_SetDisableInterpretationOfPerspectiveStereochemistry


Environment_GetDisableInterpretationOfPerspectiveStereochemistry = _ChemScript14.Environment_GetDisableInterpretationOfPerspectiveStereochemistry


Environment_Version = _ChemScript14.Environment_Version


Environment_SetNameToStructureOptions = _ChemScript14.Environment_SetNameToStructureOptions


Environment_GetNameToStructureOptions = _ChemScript14.Environment_GetNameToStructureOptions

class Dictionary_String_String(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Dictionary_String_String, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Dictionary_String_String, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.Dictionary_String_String_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.Dictionary_String_String___nonzero__(self)
    def __bool__(self): return _ChemScript14.Dictionary_String_String___bool__(self)
    def __len__(self): return _ChemScript14.Dictionary_String_String___len__(self)
    def __iter__(self): return self.key_iterator()
    def iterkeys(self): return self.key_iterator()
    def itervalues(self): return self.value_iterator()
    def iteritems(self): return self.iterator()
    def __getitem__(self, *args): return _ChemScript14.Dictionary_String_String___getitem__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.Dictionary_String_String___delitem__(self, *args)
    def has_key(self, *args): return _ChemScript14.Dictionary_String_String_has_key(self, *args)
    def keys(self): return _ChemScript14.Dictionary_String_String_keys(self)
    def values(self): return _ChemScript14.Dictionary_String_String_values(self)
    def items(self): return _ChemScript14.Dictionary_String_String_items(self)
    def __contains__(self, *args): return _ChemScript14.Dictionary_String_String___contains__(self, *args)
    def key_iterator(self): return _ChemScript14.Dictionary_String_String_key_iterator(self)
    def value_iterator(self): return _ChemScript14.Dictionary_String_String_value_iterator(self)
    def __setitem__(self, *args): return _ChemScript14.Dictionary_String_String___setitem__(self, *args)
    def asdict(self): return _ChemScript14.Dictionary_String_String_asdict(self)
    def __init__(self, *args): 
        this = _ChemScript14.new_Dictionary_String_String(*args)
        try: self.this.append(this)
        except: self.this = this
    def empty(self): return _ChemScript14.Dictionary_String_String_empty(self)
    def size(self): return _ChemScript14.Dictionary_String_String_size(self)
    def clear(self): return _ChemScript14.Dictionary_String_String_clear(self)
    def swap(self, *args): return _ChemScript14.Dictionary_String_String_swap(self, *args)
    def get_allocator(self): return _ChemScript14.Dictionary_String_String_get_allocator(self)
    def begin(self): return _ChemScript14.Dictionary_String_String_begin(self)
    def end(self): return _ChemScript14.Dictionary_String_String_end(self)
    def rbegin(self): return _ChemScript14.Dictionary_String_String_rbegin(self)
    def rend(self): return _ChemScript14.Dictionary_String_String_rend(self)
    def count(self, *args): return _ChemScript14.Dictionary_String_String_count(self, *args)
    def erase(self, *args): return _ChemScript14.Dictionary_String_String_erase(self, *args)
    def find(self, *args): return _ChemScript14.Dictionary_String_String_find(self, *args)
    def lower_bound(self, *args): return _ChemScript14.Dictionary_String_String_lower_bound(self, *args)
    def upper_bound(self, *args): return _ChemScript14.Dictionary_String_String_upper_bound(self, *args)
    __swig_destroy__ = _ChemScript14.delete_Dictionary_String_String
    __del__ = lambda self : None;
    def __repr__(self):
        r = "\r\n"
        for k, v in self.iteritems():
            r = r + k + " -> " + v + " \r\n"
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, r,)


Dictionary_String_String_swigregister = _ChemScript14.Dictionary_String_String_swigregister
Dictionary_String_String_swigregister(Dictionary_String_String)

class Dictionary_String_Double(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Dictionary_String_Double, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Dictionary_String_Double, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.Dictionary_String_Double_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.Dictionary_String_Double___nonzero__(self)
    def __bool__(self): return _ChemScript14.Dictionary_String_Double___bool__(self)
    def __len__(self): return _ChemScript14.Dictionary_String_Double___len__(self)
    def __iter__(self): return self.key_iterator()
    def iterkeys(self): return self.key_iterator()
    def itervalues(self): return self.value_iterator()
    def iteritems(self): return self.iterator()
    def __getitem__(self, *args): return _ChemScript14.Dictionary_String_Double___getitem__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.Dictionary_String_Double___delitem__(self, *args)
    def has_key(self, *args): return _ChemScript14.Dictionary_String_Double_has_key(self, *args)
    def keys(self): return _ChemScript14.Dictionary_String_Double_keys(self)
    def values(self): return _ChemScript14.Dictionary_String_Double_values(self)
    def items(self): return _ChemScript14.Dictionary_String_Double_items(self)
    def __contains__(self, *args): return _ChemScript14.Dictionary_String_Double___contains__(self, *args)
    def key_iterator(self): return _ChemScript14.Dictionary_String_Double_key_iterator(self)
    def value_iterator(self): return _ChemScript14.Dictionary_String_Double_value_iterator(self)
    def __setitem__(self, *args): return _ChemScript14.Dictionary_String_Double___setitem__(self, *args)
    def asdict(self): return _ChemScript14.Dictionary_String_Double_asdict(self)
    def __init__(self, *args): 
        this = _ChemScript14.new_Dictionary_String_Double(*args)
        try: self.this.append(this)
        except: self.this = this
    def empty(self): return _ChemScript14.Dictionary_String_Double_empty(self)
    def size(self): return _ChemScript14.Dictionary_String_Double_size(self)
    def clear(self): return _ChemScript14.Dictionary_String_Double_clear(self)
    def swap(self, *args): return _ChemScript14.Dictionary_String_Double_swap(self, *args)
    def get_allocator(self): return _ChemScript14.Dictionary_String_Double_get_allocator(self)
    def begin(self): return _ChemScript14.Dictionary_String_Double_begin(self)
    def end(self): return _ChemScript14.Dictionary_String_Double_end(self)
    def rbegin(self): return _ChemScript14.Dictionary_String_Double_rbegin(self)
    def rend(self): return _ChemScript14.Dictionary_String_Double_rend(self)
    def count(self, *args): return _ChemScript14.Dictionary_String_Double_count(self, *args)
    def erase(self, *args): return _ChemScript14.Dictionary_String_Double_erase(self, *args)
    def find(self, *args): return _ChemScript14.Dictionary_String_Double_find(self, *args)
    def lower_bound(self, *args): return _ChemScript14.Dictionary_String_Double_lower_bound(self, *args)
    def upper_bound(self, *args): return _ChemScript14.Dictionary_String_Double_upper_bound(self, *args)
    __swig_destroy__ = _ChemScript14.delete_Dictionary_String_Double
    __del__ = lambda self : None;
    def __repr__(self):
        r = "\r\n"
        for k, v in self.iteritems():
            r = r + k + " -> " + str(v) + " \r\n"
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, r,)


Dictionary_String_Double_swigregister = _ChemScript14.Dictionary_String_Double_swigregister
Dictionary_String_Double_swigregister(Dictionary_String_Double)

class Dictionary_Atom_String(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Dictionary_Atom_String, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Dictionary_Atom_String, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.Dictionary_Atom_String_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.Dictionary_Atom_String___nonzero__(self)
    def __bool__(self): return _ChemScript14.Dictionary_Atom_String___bool__(self)
    def __len__(self): return _ChemScript14.Dictionary_Atom_String___len__(self)
    def __iter__(self): return self.key_iterator()
    def iterkeys(self): return self.key_iterator()
    def itervalues(self): return self.value_iterator()
    def iteritems(self): return self.iterator()
    def __getitem__(self, *args): return _ChemScript14.Dictionary_Atom_String___getitem__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.Dictionary_Atom_String___delitem__(self, *args)
    def has_key(self, *args): return _ChemScript14.Dictionary_Atom_String_has_key(self, *args)
    def keys(self): return _ChemScript14.Dictionary_Atom_String_keys(self)
    def values(self): return _ChemScript14.Dictionary_Atom_String_values(self)
    def items(self): return _ChemScript14.Dictionary_Atom_String_items(self)
    def __contains__(self, *args): return _ChemScript14.Dictionary_Atom_String___contains__(self, *args)
    def key_iterator(self): return _ChemScript14.Dictionary_Atom_String_key_iterator(self)
    def value_iterator(self): return _ChemScript14.Dictionary_Atom_String_value_iterator(self)
    def __setitem__(self, *args): return _ChemScript14.Dictionary_Atom_String___setitem__(self, *args)
    def asdict(self): return _ChemScript14.Dictionary_Atom_String_asdict(self)
    def __init__(self, *args): 
        this = _ChemScript14.new_Dictionary_Atom_String(*args)
        try: self.this.append(this)
        except: self.this = this
    def empty(self): return _ChemScript14.Dictionary_Atom_String_empty(self)
    def size(self): return _ChemScript14.Dictionary_Atom_String_size(self)
    def clear(self): return _ChemScript14.Dictionary_Atom_String_clear(self)
    def swap(self, *args): return _ChemScript14.Dictionary_Atom_String_swap(self, *args)
    def get_allocator(self): return _ChemScript14.Dictionary_Atom_String_get_allocator(self)
    def begin(self): return _ChemScript14.Dictionary_Atom_String_begin(self)
    def end(self): return _ChemScript14.Dictionary_Atom_String_end(self)
    def rbegin(self): return _ChemScript14.Dictionary_Atom_String_rbegin(self)
    def rend(self): return _ChemScript14.Dictionary_Atom_String_rend(self)
    def count(self, *args): return _ChemScript14.Dictionary_Atom_String_count(self, *args)
    def erase(self, *args): return _ChemScript14.Dictionary_Atom_String_erase(self, *args)
    def find(self, *args): return _ChemScript14.Dictionary_Atom_String_find(self, *args)
    def lower_bound(self, *args): return _ChemScript14.Dictionary_Atom_String_lower_bound(self, *args)
    def upper_bound(self, *args): return _ChemScript14.Dictionary_Atom_String_upper_bound(self, *args)
    __swig_destroy__ = _ChemScript14.delete_Dictionary_Atom_String
    __del__ = lambda self : None;
    def __repr__(self):
        r = "\r\n"
        for k, v in self.iteritems():
            r = r + k.ToString() + " -> " + v + " \r\n"
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, r,)


Dictionary_Atom_String_swigregister = _ChemScript14.Dictionary_Atom_String_swigregister
Dictionary_Atom_String_swigregister(Dictionary_Atom_String)

class Dictionary_Bond_String(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Dictionary_Bond_String, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Dictionary_Bond_String, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.Dictionary_Bond_String_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.Dictionary_Bond_String___nonzero__(self)
    def __bool__(self): return _ChemScript14.Dictionary_Bond_String___bool__(self)
    def __len__(self): return _ChemScript14.Dictionary_Bond_String___len__(self)
    def __iter__(self): return self.key_iterator()
    def iterkeys(self): return self.key_iterator()
    def itervalues(self): return self.value_iterator()
    def iteritems(self): return self.iterator()
    def __getitem__(self, *args): return _ChemScript14.Dictionary_Bond_String___getitem__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.Dictionary_Bond_String___delitem__(self, *args)
    def has_key(self, *args): return _ChemScript14.Dictionary_Bond_String_has_key(self, *args)
    def keys(self): return _ChemScript14.Dictionary_Bond_String_keys(self)
    def values(self): return _ChemScript14.Dictionary_Bond_String_values(self)
    def items(self): return _ChemScript14.Dictionary_Bond_String_items(self)
    def __contains__(self, *args): return _ChemScript14.Dictionary_Bond_String___contains__(self, *args)
    def key_iterator(self): return _ChemScript14.Dictionary_Bond_String_key_iterator(self)
    def value_iterator(self): return _ChemScript14.Dictionary_Bond_String_value_iterator(self)
    def __setitem__(self, *args): return _ChemScript14.Dictionary_Bond_String___setitem__(self, *args)
    def asdict(self): return _ChemScript14.Dictionary_Bond_String_asdict(self)
    def __init__(self, *args): 
        this = _ChemScript14.new_Dictionary_Bond_String(*args)
        try: self.this.append(this)
        except: self.this = this
    def empty(self): return _ChemScript14.Dictionary_Bond_String_empty(self)
    def size(self): return _ChemScript14.Dictionary_Bond_String_size(self)
    def clear(self): return _ChemScript14.Dictionary_Bond_String_clear(self)
    def swap(self, *args): return _ChemScript14.Dictionary_Bond_String_swap(self, *args)
    def get_allocator(self): return _ChemScript14.Dictionary_Bond_String_get_allocator(self)
    def begin(self): return _ChemScript14.Dictionary_Bond_String_begin(self)
    def end(self): return _ChemScript14.Dictionary_Bond_String_end(self)
    def rbegin(self): return _ChemScript14.Dictionary_Bond_String_rbegin(self)
    def rend(self): return _ChemScript14.Dictionary_Bond_String_rend(self)
    def count(self, *args): return _ChemScript14.Dictionary_Bond_String_count(self, *args)
    def erase(self, *args): return _ChemScript14.Dictionary_Bond_String_erase(self, *args)
    def find(self, *args): return _ChemScript14.Dictionary_Bond_String_find(self, *args)
    def lower_bound(self, *args): return _ChemScript14.Dictionary_Bond_String_lower_bound(self, *args)
    def upper_bound(self, *args): return _ChemScript14.Dictionary_Bond_String_upper_bound(self, *args)
    __swig_destroy__ = _ChemScript14.delete_Dictionary_Bond_String
    __del__ = lambda self : None;
    def __repr__(self):
        r = "\r\n"
        for k, v in self.iteritems():
            r = r + k.ToString() + " -> " + v + " \r\n"
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, r,)


Dictionary_Bond_String_swigregister = _ChemScript14.Dictionary_Bond_String_swigregister
Dictionary_Bond_String_swigregister(Dictionary_Bond_String)

class Dictionary_StructureData_int(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, Dictionary_StructureData_int, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, Dictionary_StructureData_int, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.Dictionary_StructureData_int_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.Dictionary_StructureData_int___nonzero__(self)
    def __bool__(self): return _ChemScript14.Dictionary_StructureData_int___bool__(self)
    def __len__(self): return _ChemScript14.Dictionary_StructureData_int___len__(self)
    def __iter__(self): return self.key_iterator()
    def iterkeys(self): return self.key_iterator()
    def itervalues(self): return self.value_iterator()
    def iteritems(self): return self.iterator()
    def __getitem__(self, *args): return _ChemScript14.Dictionary_StructureData_int___getitem__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.Dictionary_StructureData_int___delitem__(self, *args)
    def has_key(self, *args): return _ChemScript14.Dictionary_StructureData_int_has_key(self, *args)
    def keys(self): return _ChemScript14.Dictionary_StructureData_int_keys(self)
    def values(self): return _ChemScript14.Dictionary_StructureData_int_values(self)
    def items(self): return _ChemScript14.Dictionary_StructureData_int_items(self)
    def __contains__(self, *args): return _ChemScript14.Dictionary_StructureData_int___contains__(self, *args)
    def key_iterator(self): return _ChemScript14.Dictionary_StructureData_int_key_iterator(self)
    def value_iterator(self): return _ChemScript14.Dictionary_StructureData_int_value_iterator(self)
    def __setitem__(self, *args): return _ChemScript14.Dictionary_StructureData_int___setitem__(self, *args)
    def asdict(self): return _ChemScript14.Dictionary_StructureData_int_asdict(self)
    def __init__(self, *args): 
        this = _ChemScript14.new_Dictionary_StructureData_int(*args)
        try: self.this.append(this)
        except: self.this = this
    def empty(self): return _ChemScript14.Dictionary_StructureData_int_empty(self)
    def size(self): return _ChemScript14.Dictionary_StructureData_int_size(self)
    def clear(self): return _ChemScript14.Dictionary_StructureData_int_clear(self)
    def swap(self, *args): return _ChemScript14.Dictionary_StructureData_int_swap(self, *args)
    def get_allocator(self): return _ChemScript14.Dictionary_StructureData_int_get_allocator(self)
    def begin(self): return _ChemScript14.Dictionary_StructureData_int_begin(self)
    def end(self): return _ChemScript14.Dictionary_StructureData_int_end(self)
    def rbegin(self): return _ChemScript14.Dictionary_StructureData_int_rbegin(self)
    def rend(self): return _ChemScript14.Dictionary_StructureData_int_rend(self)
    def count(self, *args): return _ChemScript14.Dictionary_StructureData_int_count(self, *args)
    def erase(self, *args): return _ChemScript14.Dictionary_StructureData_int_erase(self, *args)
    def find(self, *args): return _ChemScript14.Dictionary_StructureData_int_find(self, *args)
    def lower_bound(self, *args): return _ChemScript14.Dictionary_StructureData_int_lower_bound(self, *args)
    def upper_bound(self, *args): return _ChemScript14.Dictionary_StructureData_int_upper_bound(self, *args)
    __swig_destroy__ = _ChemScript14.delete_Dictionary_StructureData_int
    __del__ = lambda self : None;
    def __repr__(self):
        r = "\r\n"
        for k, v in self.iteritems():
            r = r + k.ToString() + " -> " + str(v) + " \r\n"
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, r,)


Dictionary_StructureData_int_swigregister = _ChemScript14.Dictionary_StructureData_int_swigregister
Dictionary_StructureData_int_swigregister(Dictionary_StructureData_int)

class IntVector(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, IntVector, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, IntVector, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.IntVector_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.IntVector___nonzero__(self)
    def __bool__(self): return _ChemScript14.IntVector___bool__(self)
    def __len__(self): return _ChemScript14.IntVector___len__(self)
    def pop(self): return _ChemScript14.IntVector_pop(self)
    def __getslice__(self, *args): return _ChemScript14.IntVector___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.IntVector___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.IntVector___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.IntVector___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.IntVector___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.IntVector___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.IntVector_append(self, *args)
    def empty(self): return _ChemScript14.IntVector_empty(self)
    def size(self): return _ChemScript14.IntVector_size(self)
    def clear(self): return _ChemScript14.IntVector_clear(self)
    def swap(self, *args): return _ChemScript14.IntVector_swap(self, *args)
    def get_allocator(self): return _ChemScript14.IntVector_get_allocator(self)
    def begin(self): return _ChemScript14.IntVector_begin(self)
    def end(self): return _ChemScript14.IntVector_end(self)
    def rbegin(self): return _ChemScript14.IntVector_rbegin(self)
    def rend(self): return _ChemScript14.IntVector_rend(self)
    def pop_back(self): return _ChemScript14.IntVector_pop_back(self)
    def erase(self, *args): return _ChemScript14.IntVector_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_IntVector(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.IntVector_push_back(self, *args)
    def front(self): return _ChemScript14.IntVector_front(self)
    def back(self): return _ChemScript14.IntVector_back(self)
    def assign(self, *args): return _ChemScript14.IntVector_assign(self, *args)
    def resize(self, *args): return _ChemScript14.IntVector_resize(self, *args)
    def insert(self, *args): return _ChemScript14.IntVector_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.IntVector_reserve(self, *args)
    def capacity(self): return _ChemScript14.IntVector_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_IntVector
    __del__ = lambda self : None;
IntVector_swigregister = _ChemScript14.IntVector_swigregister
IntVector_swigregister(IntVector)

class DoubleList(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, DoubleList, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, DoubleList, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.DoubleList_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.DoubleList___nonzero__(self)
    def __bool__(self): return _ChemScript14.DoubleList___bool__(self)
    def __len__(self): return _ChemScript14.DoubleList___len__(self)
    def pop(self): return _ChemScript14.DoubleList_pop(self)
    def __getslice__(self, *args): return _ChemScript14.DoubleList___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.DoubleList___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.DoubleList___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.DoubleList___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.DoubleList___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.DoubleList___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.DoubleList_append(self, *args)
    def empty(self): return _ChemScript14.DoubleList_empty(self)
    def size(self): return _ChemScript14.DoubleList_size(self)
    def clear(self): return _ChemScript14.DoubleList_clear(self)
    def swap(self, *args): return _ChemScript14.DoubleList_swap(self, *args)
    def get_allocator(self): return _ChemScript14.DoubleList_get_allocator(self)
    def begin(self): return _ChemScript14.DoubleList_begin(self)
    def end(self): return _ChemScript14.DoubleList_end(self)
    def rbegin(self): return _ChemScript14.DoubleList_rbegin(self)
    def rend(self): return _ChemScript14.DoubleList_rend(self)
    def pop_back(self): return _ChemScript14.DoubleList_pop_back(self)
    def erase(self, *args): return _ChemScript14.DoubleList_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_DoubleList(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.DoubleList_push_back(self, *args)
    def front(self): return _ChemScript14.DoubleList_front(self)
    def back(self): return _ChemScript14.DoubleList_back(self)
    def assign(self, *args): return _ChemScript14.DoubleList_assign(self, *args)
    def resize(self, *args): return _ChemScript14.DoubleList_resize(self, *args)
    def insert(self, *args): return _ChemScript14.DoubleList_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.DoubleList_reserve(self, *args)
    def capacity(self): return _ChemScript14.DoubleList_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_DoubleList
    __del__ = lambda self : None;
    def __repr__(self):
        r = ""
        b = 0
        for j in self:
            if b == 1 : 
                r = r + ", "
            r = r + str(j)
            b = 1
        return "[%s]" % (r)


DoubleList_swigregister = _ChemScript14.DoubleList_swigregister
DoubleList_swigregister(DoubleList)

class StringVector(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, StringVector, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, StringVector, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.StringVector_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.StringVector___nonzero__(self)
    def __bool__(self): return _ChemScript14.StringVector___bool__(self)
    def __len__(self): return _ChemScript14.StringVector___len__(self)
    def pop(self): return _ChemScript14.StringVector_pop(self)
    def __getslice__(self, *args): return _ChemScript14.StringVector___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.StringVector___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.StringVector___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.StringVector___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.StringVector___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.StringVector___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.StringVector_append(self, *args)
    def empty(self): return _ChemScript14.StringVector_empty(self)
    def size(self): return _ChemScript14.StringVector_size(self)
    def clear(self): return _ChemScript14.StringVector_clear(self)
    def swap(self, *args): return _ChemScript14.StringVector_swap(self, *args)
    def get_allocator(self): return _ChemScript14.StringVector_get_allocator(self)
    def begin(self): return _ChemScript14.StringVector_begin(self)
    def end(self): return _ChemScript14.StringVector_end(self)
    def rbegin(self): return _ChemScript14.StringVector_rbegin(self)
    def rend(self): return _ChemScript14.StringVector_rend(self)
    def pop_back(self): return _ChemScript14.StringVector_pop_back(self)
    def erase(self, *args): return _ChemScript14.StringVector_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_StringVector(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.StringVector_push_back(self, *args)
    def front(self): return _ChemScript14.StringVector_front(self)
    def back(self): return _ChemScript14.StringVector_back(self)
    def assign(self, *args): return _ChemScript14.StringVector_assign(self, *args)
    def resize(self, *args): return _ChemScript14.StringVector_resize(self, *args)
    def insert(self, *args): return _ChemScript14.StringVector_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.StringVector_reserve(self, *args)
    def capacity(self): return _ChemScript14.StringVector_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_StringVector
    __del__ = lambda self : None;
    def __repr__(self):
        r = ""
        b = 0
        for j in self:
            if b == 1 : 
                r = r + ", "
            r = r + str(j)
            b = 1
        return "[%s]" % (r)


StringVector_swigregister = _ChemScript14.StringVector_swigregister
StringVector_swigregister(StringVector)

class VectorOfStructVector(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, VectorOfStructVector, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, VectorOfStructVector, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.VectorOfStructVector_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.VectorOfStructVector___nonzero__(self)
    def __bool__(self): return _ChemScript14.VectorOfStructVector___bool__(self)
    def __len__(self): return _ChemScript14.VectorOfStructVector___len__(self)
    def pop(self): return _ChemScript14.VectorOfStructVector_pop(self)
    def __getslice__(self, *args): return _ChemScript14.VectorOfStructVector___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.VectorOfStructVector___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.VectorOfStructVector___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.VectorOfStructVector___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.VectorOfStructVector___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.VectorOfStructVector___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.VectorOfStructVector_append(self, *args)
    def empty(self): return _ChemScript14.VectorOfStructVector_empty(self)
    def size(self): return _ChemScript14.VectorOfStructVector_size(self)
    def clear(self): return _ChemScript14.VectorOfStructVector_clear(self)
    def swap(self, *args): return _ChemScript14.VectorOfStructVector_swap(self, *args)
    def get_allocator(self): return _ChemScript14.VectorOfStructVector_get_allocator(self)
    def begin(self): return _ChemScript14.VectorOfStructVector_begin(self)
    def end(self): return _ChemScript14.VectorOfStructVector_end(self)
    def rbegin(self): return _ChemScript14.VectorOfStructVector_rbegin(self)
    def rend(self): return _ChemScript14.VectorOfStructVector_rend(self)
    def pop_back(self): return _ChemScript14.VectorOfStructVector_pop_back(self)
    def erase(self, *args): return _ChemScript14.VectorOfStructVector_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_VectorOfStructVector(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.VectorOfStructVector_push_back(self, *args)
    def front(self): return _ChemScript14.VectorOfStructVector_front(self)
    def back(self): return _ChemScript14.VectorOfStructVector_back(self)
    def assign(self, *args): return _ChemScript14.VectorOfStructVector_assign(self, *args)
    def resize(self, *args): return _ChemScript14.VectorOfStructVector_resize(self, *args)
    def insert(self, *args): return _ChemScript14.VectorOfStructVector_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.VectorOfStructVector_reserve(self, *args)
    def capacity(self): return _ChemScript14.VectorOfStructVector_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_VectorOfStructVector
    __del__ = lambda self : None;
    def __repr__(self):
        r = ""
        for j in self:
            r = r + "\r\n"
            r = r + j.__repr__()
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, r,)


VectorOfStructVector_swigregister = _ChemScript14.VectorOfStructVector_swigregister
VectorOfStructVector_swigregister(VectorOfStructVector)

class VectorIntVector(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, VectorIntVector, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, VectorIntVector, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.VectorIntVector_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.VectorIntVector___nonzero__(self)
    def __bool__(self): return _ChemScript14.VectorIntVector___bool__(self)
    def __len__(self): return _ChemScript14.VectorIntVector___len__(self)
    def pop(self): return _ChemScript14.VectorIntVector_pop(self)
    def __getslice__(self, *args): return _ChemScript14.VectorIntVector___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.VectorIntVector___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.VectorIntVector___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.VectorIntVector___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.VectorIntVector___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.VectorIntVector___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.VectorIntVector_append(self, *args)
    def empty(self): return _ChemScript14.VectorIntVector_empty(self)
    def size(self): return _ChemScript14.VectorIntVector_size(self)
    def clear(self): return _ChemScript14.VectorIntVector_clear(self)
    def swap(self, *args): return _ChemScript14.VectorIntVector_swap(self, *args)
    def get_allocator(self): return _ChemScript14.VectorIntVector_get_allocator(self)
    def begin(self): return _ChemScript14.VectorIntVector_begin(self)
    def end(self): return _ChemScript14.VectorIntVector_end(self)
    def rbegin(self): return _ChemScript14.VectorIntVector_rbegin(self)
    def rend(self): return _ChemScript14.VectorIntVector_rend(self)
    def pop_back(self): return _ChemScript14.VectorIntVector_pop_back(self)
    def erase(self, *args): return _ChemScript14.VectorIntVector_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_VectorIntVector(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.VectorIntVector_push_back(self, *args)
    def front(self): return _ChemScript14.VectorIntVector_front(self)
    def back(self): return _ChemScript14.VectorIntVector_back(self)
    def assign(self, *args): return _ChemScript14.VectorIntVector_assign(self, *args)
    def resize(self, *args): return _ChemScript14.VectorIntVector_resize(self, *args)
    def insert(self, *args): return _ChemScript14.VectorIntVector_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.VectorIntVector_reserve(self, *args)
    def capacity(self): return _ChemScript14.VectorIntVector_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_VectorIntVector
    __del__ = lambda self : None;
VectorIntVector_swigregister = _ChemScript14.VectorIntVector_swigregister
VectorIntVector_swigregister(VectorIntVector)

class AtomAtomMap(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, AtomAtomMap, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, AtomAtomMap, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.AtomAtomMap_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.AtomAtomMap___nonzero__(self)
    def __bool__(self): return _ChemScript14.AtomAtomMap___bool__(self)
    def __len__(self): return _ChemScript14.AtomAtomMap___len__(self)
    def __iter__(self): return self.key_iterator()
    def iterkeys(self): return self.key_iterator()
    def itervalues(self): return self.value_iterator()
    def iteritems(self): return self.iterator()
    def __getitem__(self, *args): return _ChemScript14.AtomAtomMap___getitem__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.AtomAtomMap___delitem__(self, *args)
    def has_key(self, *args): return _ChemScript14.AtomAtomMap_has_key(self, *args)
    def keys(self): return _ChemScript14.AtomAtomMap_keys(self)
    def values(self): return _ChemScript14.AtomAtomMap_values(self)
    def items(self): return _ChemScript14.AtomAtomMap_items(self)
    def __contains__(self, *args): return _ChemScript14.AtomAtomMap___contains__(self, *args)
    def key_iterator(self): return _ChemScript14.AtomAtomMap_key_iterator(self)
    def value_iterator(self): return _ChemScript14.AtomAtomMap_value_iterator(self)
    def __setitem__(self, *args): return _ChemScript14.AtomAtomMap___setitem__(self, *args)
    def asdict(self): return _ChemScript14.AtomAtomMap_asdict(self)
    def __init__(self, *args): 
        this = _ChemScript14.new_AtomAtomMap(*args)
        try: self.this.append(this)
        except: self.this = this
    def empty(self): return _ChemScript14.AtomAtomMap_empty(self)
    def size(self): return _ChemScript14.AtomAtomMap_size(self)
    def clear(self): return _ChemScript14.AtomAtomMap_clear(self)
    def swap(self, *args): return _ChemScript14.AtomAtomMap_swap(self, *args)
    def get_allocator(self): return _ChemScript14.AtomAtomMap_get_allocator(self)
    def begin(self): return _ChemScript14.AtomAtomMap_begin(self)
    def end(self): return _ChemScript14.AtomAtomMap_end(self)
    def rbegin(self): return _ChemScript14.AtomAtomMap_rbegin(self)
    def rend(self): return _ChemScript14.AtomAtomMap_rend(self)
    def count(self, *args): return _ChemScript14.AtomAtomMap_count(self, *args)
    def erase(self, *args): return _ChemScript14.AtomAtomMap_erase(self, *args)
    def find(self, *args): return _ChemScript14.AtomAtomMap_find(self, *args)
    def lower_bound(self, *args): return _ChemScript14.AtomAtomMap_lower_bound(self, *args)
    def upper_bound(self, *args): return _ChemScript14.AtomAtomMap_upper_bound(self, *args)
    __swig_destroy__ = _ChemScript14.delete_AtomAtomMap
    __del__ = lambda self : None;
    def __repr__(self):
        r = "\r\n"
        for k, v in self.iteritems():
            r = r + k.Name + " -> " + v.Name + " \r\n"
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, r,)


AtomAtomMap_swigregister = _ChemScript14.AtomAtomMap_swigregister
AtomAtomMap_swigregister(AtomAtomMap)

class AtomsMapVector(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, AtomsMapVector, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, AtomsMapVector, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.AtomsMapVector_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.AtomsMapVector___nonzero__(self)
    def __bool__(self): return _ChemScript14.AtomsMapVector___bool__(self)
    def __len__(self): return _ChemScript14.AtomsMapVector___len__(self)
    def pop(self): return _ChemScript14.AtomsMapVector_pop(self)
    def __getslice__(self, *args): return _ChemScript14.AtomsMapVector___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.AtomsMapVector___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.AtomsMapVector___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.AtomsMapVector___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.AtomsMapVector___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.AtomsMapVector___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.AtomsMapVector_append(self, *args)
    def empty(self): return _ChemScript14.AtomsMapVector_empty(self)
    def size(self): return _ChemScript14.AtomsMapVector_size(self)
    def clear(self): return _ChemScript14.AtomsMapVector_clear(self)
    def swap(self, *args): return _ChemScript14.AtomsMapVector_swap(self, *args)
    def get_allocator(self): return _ChemScript14.AtomsMapVector_get_allocator(self)
    def begin(self): return _ChemScript14.AtomsMapVector_begin(self)
    def end(self): return _ChemScript14.AtomsMapVector_end(self)
    def rbegin(self): return _ChemScript14.AtomsMapVector_rbegin(self)
    def rend(self): return _ChemScript14.AtomsMapVector_rend(self)
    def pop_back(self): return _ChemScript14.AtomsMapVector_pop_back(self)
    def erase(self, *args): return _ChemScript14.AtomsMapVector_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_AtomsMapVector(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.AtomsMapVector_push_back(self, *args)
    def front(self): return _ChemScript14.AtomsMapVector_front(self)
    def back(self): return _ChemScript14.AtomsMapVector_back(self)
    def assign(self, *args): return _ChemScript14.AtomsMapVector_assign(self, *args)
    def resize(self, *args): return _ChemScript14.AtomsMapVector_resize(self, *args)
    def insert(self, *args): return _ChemScript14.AtomsMapVector_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.AtomsMapVector_reserve(self, *args)
    def capacity(self): return _ChemScript14.AtomsMapVector_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_AtomsMapVector
    __del__ = lambda self : None;
    def __repr__(self):
        r = ""
        for j in self:
            r1 = "\r\n"
            r1 = r1 + j.__repr__()
            r = r + r1
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, r,)


AtomsMapVector_swigregister = _ChemScript14.AtomsMapVector_swigregister
AtomsMapVector_swigregister(AtomsMapVector)

class BondBondMap(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, BondBondMap, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, BondBondMap, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.BondBondMap_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.BondBondMap___nonzero__(self)
    def __bool__(self): return _ChemScript14.BondBondMap___bool__(self)
    def __len__(self): return _ChemScript14.BondBondMap___len__(self)
    def __iter__(self): return self.key_iterator()
    def iterkeys(self): return self.key_iterator()
    def itervalues(self): return self.value_iterator()
    def iteritems(self): return self.iterator()
    def __getitem__(self, *args): return _ChemScript14.BondBondMap___getitem__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.BondBondMap___delitem__(self, *args)
    def has_key(self, *args): return _ChemScript14.BondBondMap_has_key(self, *args)
    def keys(self): return _ChemScript14.BondBondMap_keys(self)
    def values(self): return _ChemScript14.BondBondMap_values(self)
    def items(self): return _ChemScript14.BondBondMap_items(self)
    def __contains__(self, *args): return _ChemScript14.BondBondMap___contains__(self, *args)
    def key_iterator(self): return _ChemScript14.BondBondMap_key_iterator(self)
    def value_iterator(self): return _ChemScript14.BondBondMap_value_iterator(self)
    def __setitem__(self, *args): return _ChemScript14.BondBondMap___setitem__(self, *args)
    def asdict(self): return _ChemScript14.BondBondMap_asdict(self)
    def __init__(self, *args): 
        this = _ChemScript14.new_BondBondMap(*args)
        try: self.this.append(this)
        except: self.this = this
    def empty(self): return _ChemScript14.BondBondMap_empty(self)
    def size(self): return _ChemScript14.BondBondMap_size(self)
    def clear(self): return _ChemScript14.BondBondMap_clear(self)
    def swap(self, *args): return _ChemScript14.BondBondMap_swap(self, *args)
    def get_allocator(self): return _ChemScript14.BondBondMap_get_allocator(self)
    def begin(self): return _ChemScript14.BondBondMap_begin(self)
    def end(self): return _ChemScript14.BondBondMap_end(self)
    def rbegin(self): return _ChemScript14.BondBondMap_rbegin(self)
    def rend(self): return _ChemScript14.BondBondMap_rend(self)
    def count(self, *args): return _ChemScript14.BondBondMap_count(self, *args)
    def erase(self, *args): return _ChemScript14.BondBondMap_erase(self, *args)
    def find(self, *args): return _ChemScript14.BondBondMap_find(self, *args)
    def lower_bound(self, *args): return _ChemScript14.BondBondMap_lower_bound(self, *args)
    def upper_bound(self, *args): return _ChemScript14.BondBondMap_upper_bound(self, *args)
    __swig_destroy__ = _ChemScript14.delete_BondBondMap
    __del__ = lambda self : None;
    def __repr__(self):
        r = "\r\n"
        for k, v in self.iteritems():
            r = r + k.Name + " -> " + v.Name + " \r\n"
        return "<%s.%s: %s>" % (self.__class__.__module__, self.__class__.__name__, r,)


BondBondMap_swigregister = _ChemScript14.BondBondMap_swigregister
BondBondMap_swigregister(BondBondMap)

class BondsMapVector(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, BondsMapVector, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, BondsMapVector, name)
    __repr__ = _swig_repr
    def iterator(self): return _ChemScript14.BondsMapVector_iterator(self)
    def __iter__(self): return self.iterator()
    def __nonzero__(self): return _ChemScript14.BondsMapVector___nonzero__(self)
    def __bool__(self): return _ChemScript14.BondsMapVector___bool__(self)
    def __len__(self): return _ChemScript14.BondsMapVector___len__(self)
    def pop(self): return _ChemScript14.BondsMapVector_pop(self)
    def __getslice__(self, *args): return _ChemScript14.BondsMapVector___getslice__(self, *args)
    def __setslice__(self, *args): return _ChemScript14.BondsMapVector___setslice__(self, *args)
    def __delslice__(self, *args): return _ChemScript14.BondsMapVector___delslice__(self, *args)
    def __delitem__(self, *args): return _ChemScript14.BondsMapVector___delitem__(self, *args)
    def __getitem__(self, *args): return _ChemScript14.BondsMapVector___getitem__(self, *args)
    def __setitem__(self, *args): return _ChemScript14.BondsMapVector___setitem__(self, *args)
    def append(self, *args): return _ChemScript14.BondsMapVector_append(self, *args)
    def empty(self): return _ChemScript14.BondsMapVector_empty(self)
    def size(self): return _ChemScript14.BondsMapVector_size(self)
    def clear(self): return _ChemScript14.BondsMapVector_clear(self)
    def swap(self, *args): return _ChemScript14.BondsMapVector_swap(self, *args)
    def get_allocator(self): return _ChemScript14.BondsMapVector_get_allocator(self)
    def begin(self): return _ChemScript14.BondsMapVector_begin(self)
    def end(self): return _ChemScript14.BondsMapVector_end(self)
    def rbegin(self): return _ChemScript14.BondsMapVector_rbegin(self)
    def rend(self): return _ChemScript14.BondsMapVector_rend(self)
    def pop_back(self): return _ChemScript14.BondsMapVector_pop_back(self)
    def erase(self, *args): return _ChemScript14.BondsMapVector_erase(self, *args)
    def __init__(self, *args): 
        this = _ChemScript14.new_BondsMapVector(*args)
        try: self.this.append(this)
        except: self.this = this
    def push_back(self, *args): return _ChemScript14.BondsMapVector_push_back(self, *args)
    def front(self): return _ChemScript14.BondsMapVector_front(self)
    def back(self): return _ChemScript14.BondsMapVector_back(self)
    def assign(self, *args): return _ChemScript14.BondsMapVector_assign(self, *args)
    def resize(self, *args): return _ChemScript14.BondsMapVector_resize(self, *args)
    def insert(self, *args): return _ChemScript14.BondsMapVector_insert(self, *args)
    def reserve(self, *args): return _ChemScript14.BondsMapVector_reserve(self, *args)
    def capacity(self): return _ChemScript14.BondsMapVector_capacity(self)
    __swig_destroy__ = _ChemScript14.delete_BondsMapVector
    __del__ = lambda self : None;
BondsMapVector_swigregister = _ChemScript14.BondsMapVector_swigregister
BondsMapVector_swigregister(BondsMapVector)

# This file is compatible with both classic and new-style classes.




# do some extra thing after loading the library
Env = Environment
